import { l as logger } from "./assets/preload-helper-B5H8K-py.js";
import { s as storage, p as pubkyAPISDK } from "./assets/pubky-api-sdk-BFuMTLWs.js";
import { a as annotationStorage } from "./assets/annotations-dRpHBGXv.js";
logger.info("Background", "Service worker initialized");
chrome.runtime.onInstalled.addListener((details) => {
  logger.info("Background", "Extension installed/updated", { reason: details.reason });
  if (details.reason === "install") {
    logger.info("Background", "First time installation - showing welcome");
    chrome.alarms.create("sync-pending-content", { periodInMinutes: 15 });
    logger.info("Background", "Sync alarm created");
  } else if (details.reason === "update") {
    logger.info("Background", "Extension updated", {
      previousVersion: details.previousVersion
    });
    chrome.alarms.get("sync-pending-content", (alarm) => {
      if (!alarm) {
        chrome.alarms.create("sync-pending-content", { periodInMinutes: 15 });
        logger.info("Background", "Sync alarm recreated after update");
      }
    });
  }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  logger.debug("Background", "Message received", { message, sender: sender.id });
  if (message.type === "OPEN_SIDE_PANEL") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      var _a;
      if ((_a = tabs[0]) == null ? void 0 : _a.id) {
        chrome.sidePanel.open({ tabId: tabs[0].id });
        logger.info("Background", "Side panel opened", { tabId: tabs[0].id });
      }
    });
    sendResponse({ success: true });
  }
  if (message.type === "CREATE_ANNOTATION") {
    handleCreateAnnotation(message.annotation).then((result) => {
      sendResponse(result);
    }).catch((error) => {
      logger.error("Background", "Failed to handle annotation creation", error);
      sendResponse({ success: false, error: error.message });
    });
    return true;
  }
  if (message.type === "GET_ANNOTATIONS") {
    handleGetAnnotations(message.url).then((annotations) => {
      sendResponse({ annotations });
    }).catch((error) => {
      logger.error("Background", "Failed to get annotations", error);
      sendResponse({ annotations: [] });
    });
    return true;
  }
  if (message.type === "SHOW_ANNOTATION") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      var _a;
      if ((_a = tabs[0]) == null ? void 0 : _a.id) {
        chrome.sidePanel.open({ tabId: tabs[0].id });
        setTimeout(() => {
          chrome.runtime.sendMessage({
            type: "SCROLL_TO_ANNOTATION",
            annotationId: message.annotationId
          });
        }, 500);
      }
    });
    sendResponse({ success: true });
  }
  if (message.type === "OPEN_PUBKY_PROFILE") {
    openPubkyProfile(message.url);
    sendResponse({ success: true });
  }
  if (message.type === "SAVE_DRAWING") {
    const drawing = message.drawing || message;
    handleSaveDrawing(drawing.url, drawing.canvasData).then((result) => {
      sendResponse(result);
    }).catch((error) => {
      logger.error("Background", "Failed to save drawing", error);
      sendResponse({ success: false, error: error.message });
    });
    return true;
  }
  if (message.type === "GET_DRAWING") {
    handleGetDrawing(message.url).then((drawing) => {
      sendResponse({ drawing });
    }).catch((error) => {
      logger.error("Background", "Failed to get drawing", error);
      sendResponse({ drawing: null });
    });
    return true;
  }
  return true;
});
async function handleCreateAnnotation(annotation) {
  try {
    logger.info("Background", "Processing annotation", { id: annotation.id });
    const session = await storage.getSession();
    if (!session) {
      logger.warn("Background", "Not authenticated, saving annotation locally only");
      await annotationStorage.saveAnnotation(annotation);
      return {
        success: false,
        error: "Not authenticated. Annotation saved locally only."
      };
    }
    annotation.author = session.pubky;
    await annotationStorage.saveAnnotation(annotation);
    try {
      const postUri = await pubkyAPISDK.createAnnotationPost(
        annotation.url,
        annotation.selectedText,
        annotation.comment,
        {
          prefix: annotation.prefix || "",
          exact: annotation.exact || annotation.selectedText,
          suffix: annotation.suffix || ""
        }
      );
      annotation.postUri = postUri;
      await annotationStorage.saveAnnotation(annotation);
      logger.info("Background", "Annotation synced to Pubky", {
        id: annotation.id,
        postUri
      });
      const tabs = await chrome.tabs.query({ url: annotation.url });
      for (const tab of tabs) {
        if (tab.id) {
          chrome.tabs.sendMessage(tab.id, {
            type: "ANNOTATION_CREATED",
            annotation
          }).catch(() => {
          });
        }
      }
      return {
        success: true,
        postUri,
        author: session.pubky
      };
    } catch (pubkyError) {
      logger.warn("Background", "Failed to sync to Pubky, annotation saved locally", pubkyError);
      return {
        success: true,
        // Local save succeeded
        warning: "Annotation saved locally but not yet synced to Pubky network",
        author: session.pubky
      };
    }
  } catch (error) {
    logger.error("Background", "Failed to process annotation", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error"
    };
  }
}
async function handleGetAnnotations(url) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
  try {
    logger.info("Background", "Getting annotations for URL", { url });
    const localAnnotations = await annotationStorage.getAnnotationsForUrl(url);
    const session = await storage.getSession();
    const posts = await pubkyAPISDK.searchAnnotationsByUrl(url, session == null ? void 0 : session.pubky);
    const remoteAnnotations = [];
    for (const post of posts) {
      try {
        const content = ((_a = post.details) == null ? void 0 : _a.content) || post.content || "";
        const data = JSON.parse(content);
        if (data.type === "annotation") {
          const annotation = {
            id: ((_b = post.details) == null ? void 0 : _b.id) || post.id || "",
            url: data.url,
            selectedText: data.selectedText,
            comment: data.comment,
            prefix: ((_c = data.metadata) == null ? void 0 : _c.prefix) || "",
            exact: ((_d = data.metadata) == null ? void 0 : _d.exact) || data.selectedText,
            suffix: ((_e = data.metadata) == null ? void 0 : _e.suffix) || "",
            // Legacy support
            startPath: (_f = data.metadata) == null ? void 0 : _f.startPath,
            endPath: (_g = data.metadata) == null ? void 0 : _g.endPath,
            startOffset: (_h = data.metadata) == null ? void 0 : _h.startOffset,
            endOffset: (_i = data.metadata) == null ? void 0 : _i.endOffset,
            timestamp: ((_j = post.details) == null ? void 0 : _j.indexed_at) || Date.now(),
            author: ((_k = post.details) == null ? void 0 : _k.author) || post.author_id || "",
            postUri: ((_l = post.details) == null ? void 0 : _l.uri) || "",
            color: "rgba(163, 230, 53, 0.25)"
          };
          remoteAnnotations.push(annotation);
        }
      } catch (parseError) {
        logger.warn("Background", "Failed to parse annotation post", parseError);
      }
    }
    const allAnnotations = [...localAnnotations];
    const localIds = new Set(localAnnotations.map((a) => a.id));
    for (const remote of remoteAnnotations) {
      if (!localIds.has(remote.id)) {
        allAnnotations.push(remote);
        await annotationStorage.saveAnnotation(remote);
      }
    }
    logger.info("Background", "Annotations retrieved", {
      total: allAnnotations.length,
      local: localAnnotations.length,
      remote: remoteAnnotations.length
    });
    return allAnnotations;
  } catch (error) {
    logger.error("Background", "Failed to get annotations", error);
    return [];
  }
}
async function handleSaveDrawing(url, canvasData) {
  try {
    logger.info("Background", "Saving drawing", { url });
    const session = await storage.getSession();
    if (!session) {
      logger.warn("Background", "Not authenticated, saving drawing locally only");
    }
    const drawing = {
      id: `drawing-${Date.now()}`,
      url,
      canvasData,
      timestamp: Date.now(),
      author: (session == null ? void 0 : session.pubky) || ""
    };
    await storage.saveDrawing(drawing);
    logger.info("Background", "Drawing saved locally", { url });
    return {
      success: true,
      message: "Drawing saved locally. Will sync to Pubky when you open the extension popup."
    };
  } catch (error) {
    logger.error("Background", "Failed to save drawing", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error"
    };
  }
}
async function handleGetDrawing(url) {
  try {
    logger.info("Background", "Getting drawing for URL", { url });
    const drawing = await storage.getDrawing(url);
    if (drawing) {
      logger.info("Background", "Drawing found", { url });
      return drawing;
    } else {
      logger.debug("Background", "No drawing found for URL", { url });
      return null;
    }
  } catch (error) {
    logger.error("Background", "Failed to get drawing", error);
    return null;
  }
}
function openPubkyProfile(url) {
  logger.info("Background", "Opening Pubky profile", { url });
  const rendererUrl = chrome.runtime.getURL(`src/profile/profile-renderer.html?url=${encodeURIComponent(url)}`);
  chrome.tabs.create({
    url: rendererUrl
  });
}
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  const url = details.url;
  if (url.startsWith("pubky://") && details.frameId === 0) {
    logger.info("Background", "Intercepting pubky URL from omnibox", { url });
    openPubkyProfile(url);
  }
});
chrome.commands.onCommand.addListener((command) => {
  logger.info("Background", "Command received", { command });
  if (command === "toggle-sidepanel") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (tab == null ? void 0 : tab.windowId) {
        chrome.sidePanel.open({ windowId: tab.windowId }, () => {
          if (chrome.runtime.lastError) {
            logger.error("Background", "Failed to toggle side panel", new Error(chrome.runtime.lastError.message));
          } else {
            logger.info("Background", "Side panel opened via keyboard shortcut", {
              tabId: tab.id,
              windowId: tab.windowId
            });
          }
        });
      }
    });
  }
  if (command === "open-annotations") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (tab == null ? void 0 : tab.windowId) {
        chrome.sidePanel.open({ windowId: tab.windowId }, () => {
          if (chrome.runtime.lastError) {
            logger.error("Background", "Failed to open annotations", new Error(chrome.runtime.lastError.message));
          } else {
            setTimeout(() => {
              chrome.runtime.sendMessage({
                type: "SWITCH_TO_ANNOTATIONS"
              }).catch(() => {
              });
            }, 500);
            logger.info("Background", "Side panel opened to annotations via keyboard shortcut", {
              tabId: tab.id,
              windowId: tab.windowId
            });
          }
        });
      }
    });
  }
  if (command === "toggle-drawing") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      var _a;
      const tab = tabs[0];
      if ((tab == null ? void 0 : tab.id) && tab.url && !tab.url.startsWith("chrome://") && !tab.url.startsWith("about:") && !tab.url.startsWith("chrome-extension://")) {
        chrome.tabs.sendMessage(tab.id, {
          type: "TOGGLE_DRAWING_MODE"
        }, (response) => {
          var _a2;
          if (chrome.runtime.lastError) {
            logger.error("Background", "Failed to toggle drawing mode - content script may not be ready", new Error(chrome.runtime.lastError.message));
            (_a2 = chrome.notifications) == null ? void 0 : _a2.create({
              type: "basic",
              iconUrl: "icons/icon48.png",
              title: "Drawing Mode",
              message: "Please refresh the page to use drawing mode on this site."
            });
          } else {
            logger.info("Background", "Drawing mode toggled via keyboard shortcut", {
              tabId: tab.id,
              active: response == null ? void 0 : response.active
            });
          }
        });
      } else {
        logger.warn("Background", "Cannot use drawing mode on this page", { url: tab == null ? void 0 : tab.url });
        (_a = chrome.notifications) == null ? void 0 : _a.create({
          type: "basic",
          iconUrl: "icons/icon48.png",
          title: "Drawing Mode",
          message: "Drawing mode is not available on this page. Try a regular website."
        });
      }
    });
  }
});
self.addEventListener("error", (event) => {
  logger.error("Background", "Unhandled error", event.error);
});
self.addEventListener("unhandledrejection", (event) => {
  logger.error("Background", "Unhandled promise rejection", new Error(event.reason));
});
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "sync-pending-content") {
    logger.info("Background", "Sync alarm triggered, checking for pending content");
    try {
      const session = await storage.getSession();
      if (!session) {
        logger.debug("Background", "No session, skipping sync");
        return;
      }
      const annotations = await annotationStorage.getAllAnnotations();
      const drawings = await storage.getAllDrawings();
      let hasPendingAnnotations = false;
      for (const url in annotations) {
        for (const annotation of annotations[url]) {
          if (!annotation.postUri && annotation.author) {
            hasPendingAnnotations = true;
            break;
          }
        }
        if (hasPendingAnnotations) break;
      }
      let hasPendingDrawings = false;
      for (const url in drawings) {
        if (!drawings[url].pubkyUrl && drawings[url].author) {
          hasPendingDrawings = true;
          break;
        }
      }
      if (!hasPendingAnnotations && !hasPendingDrawings) {
        logger.debug("Background", "No pending content to sync");
        return;
      }
      logger.info("Background", "Found pending content, attempting sync", {
        pendingAnnotations: hasPendingAnnotations,
        pendingDrawings: hasPendingDrawings
      });
      logger.info("Background", "Sync needed - will sync on next popup/sidepanel open");
    } catch (error) {
      logger.error("Background", "Error during alarm sync check", error);
    }
  }
});
logger.info("Background", "Service worker ready");
//# sourceMappingURL=background.js.map
