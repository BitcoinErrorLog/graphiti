var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
import { l as logger } from "./preload-helper-B5H8K-py.js";
const _AnnotationStorage = class _AnnotationStorage {
  constructor() {
    __publicField(this, "saveLock", Promise.resolve());
  }
  /**
   * Get all annotations for a specific URL
   */
  async getAnnotationsForUrl(url) {
    try {
      const result = await chrome.storage.local.get(_AnnotationStorage.STORAGE_KEY);
      const stored = result[_AnnotationStorage.STORAGE_KEY] || {};
      return stored[url] || [];
    } catch (error) {
      logger.error("AnnotationStorage", "Failed to get annotations", error);
      return [];
    }
  }
  /**
   * Save an annotation (with mutex lock to prevent race conditions)
   */
  async saveAnnotation(annotation) {
    await this.saveLock;
    this.saveLock = this._saveAnnotation(annotation);
    return this.saveLock;
  }
  /**
   * Internal save method (called within lock)
   */
  async _saveAnnotation(annotation) {
    try {
      const result = await chrome.storage.local.get(_AnnotationStorage.STORAGE_KEY);
      const stored = result[_AnnotationStorage.STORAGE_KEY] || {};
      if (!stored[annotation.url]) {
        stored[annotation.url] = [];
      }
      const index = stored[annotation.url].findIndex((a) => a.id === annotation.id);
      if (index >= 0) {
        stored[annotation.url][index] = annotation;
      } else {
        stored[annotation.url].push(annotation);
      }
      await chrome.storage.local.set({
        [_AnnotationStorage.STORAGE_KEY]: stored
      });
      logger.info("AnnotationStorage", "Annotation saved", { id: annotation.id });
    } catch (error) {
      logger.error("AnnotationStorage", "Failed to save annotation", error);
      throw error;
    }
  }
  /**
   * Delete an annotation (with mutex lock to prevent race conditions)
   */
  async deleteAnnotation(url, annotationId) {
    await this.saveLock;
    this.saveLock = this._deleteAnnotation(url, annotationId);
    return this.saveLock;
  }
  /**
   * Internal delete method (called within lock)
   */
  async _deleteAnnotation(url, annotationId) {
    try {
      const result = await chrome.storage.local.get(_AnnotationStorage.STORAGE_KEY);
      const stored = result[_AnnotationStorage.STORAGE_KEY] || {};
      if (stored[url]) {
        stored[url] = stored[url].filter((a) => a.id !== annotationId);
        await chrome.storage.local.set({
          [_AnnotationStorage.STORAGE_KEY]: stored
        });
        logger.info("AnnotationStorage", "Annotation deleted", { id: annotationId });
      }
    } catch (error) {
      logger.error("AnnotationStorage", "Failed to delete annotation", error);
      throw error;
    }
  }
  /**
   * Get all annotations across all URLs
   */
  async getAllAnnotations() {
    try {
      const result = await chrome.storage.local.get(_AnnotationStorage.STORAGE_KEY);
      return result[_AnnotationStorage.STORAGE_KEY] || {};
    } catch (error) {
      logger.error("AnnotationStorage", "Failed to get all annotations", error);
      return {};
    }
  }
  /**
   * Clear all annotations (for debugging/testing)
   */
  async clearAllAnnotations() {
    try {
      await chrome.storage.local.remove(_AnnotationStorage.STORAGE_KEY);
      logger.info("AnnotationStorage", "All annotations cleared");
    } catch (error) {
      logger.error("AnnotationStorage", "Failed to clear annotations", error);
      throw error;
    }
  }
};
__publicField(_AnnotationStorage, "STORAGE_KEY", "pubky_annotations");
let AnnotationStorage = _AnnotationStorage;
const annotationStorage = new AnnotationStorage();
export {
  annotationStorage as a
};
//# sourceMappingURL=annotations-dRpHBGXv.js.map
