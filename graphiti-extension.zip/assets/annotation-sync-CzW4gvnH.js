import { l as logger } from "./preload-helper-B5H8K-py.js";
import { p as pubkyAPISDK } from "./pubky-api-sdk-BFuMTLWs.js";
import { a as annotationStorage } from "./annotations-dRpHBGXv.js";
class AnnotationSync {
  /**
   * Sync any unsynced annotations to Pubky
   * Call this from popup/sidepanel when they open
   */
  static async syncPendingAnnotations() {
    try {
      logger.info("AnnotationSync", "Checking for unsynced annotations");
      const allAnnotations = await annotationStorage.getAllAnnotations();
      let syncCount = 0;
      for (const url in allAnnotations) {
        for (const annotation of allAnnotations[url]) {
          if (!annotation.postUri && annotation.author) {
            try {
              logger.info("AnnotationSync", "Syncing annotation to Pubky", { id: annotation.id });
              const postUri = await pubkyAPISDK.createAnnotationPost(
                annotation.url,
                annotation.selectedText,
                annotation.comment,
                {
                  prefix: annotation.prefix || "",
                  exact: annotation.exact || annotation.selectedText,
                  suffix: annotation.suffix || ""
                }
              );
              annotation.postUri = postUri;
              await annotationStorage.saveAnnotation(annotation);
              syncCount++;
              logger.info("AnnotationSync", "Annotation synced successfully", {
                id: annotation.id,
                postUri
              });
            } catch (error) {
              logger.error("AnnotationSync", "Failed to sync annotation", error, {
                id: annotation.id
              });
            }
          }
        }
      }
      if (syncCount > 0) {
        logger.info("AnnotationSync", "Sync complete", { count: syncCount });
      }
    } catch (error) {
      logger.error("AnnotationSync", "Failed to sync annotations", error);
    }
  }
}
export {
  AnnotationSync
};
//# sourceMappingURL=annotation-sync-CzW4gvnH.js.map
