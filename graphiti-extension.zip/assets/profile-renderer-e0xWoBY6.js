var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
import { imageHandler } from "./image-handler-DBCQrSfx.js";
import { _ as __vitePreload } from "./preload-helper-B5H8K-py.js";
class ProfileRendererLogger {
  constructor() {
    __publicField(this, "logPrefix", "[ProfileRenderer]");
  }
  info(message, data) {
    console.log(`${this.logPrefix} [INFO] ${message}`, data || "");
  }
  warn(message, data) {
    console.warn(`${this.logPrefix} [WARN] ${message}`, data || "");
  }
  error(message, error) {
    console.error(`${this.logPrefix} [ERROR] ${message}`, error || "");
  }
}
const rendererLogger = new ProfileRendererLogger();
class ProfileRenderer {
  constructor() {
    __publicField(this, "loadingEl");
    __publicField(this, "errorEl");
    __publicField(this, "errorMessageEl");
    __publicField(this, "errorDetailsEl");
    __publicField(this, "contentEl");
    __publicField(this, "pubky", null);
    this.loadingEl = document.getElementById("loading");
    this.errorEl = document.getElementById("error");
    this.errorMessageEl = document.getElementById("error-message");
    this.errorDetailsEl = document.getElementById("error-details");
    this.contentEl = document.getElementById("profile-content");
    this.init();
  }
  async init() {
    try {
      await this.initializePubky();
      const pubkyURL = this.parseURL();
      if (!pubkyURL) {
        this.showError("Invalid URL", "The URL format is invalid. Expected: pubky://PUBLIC_KEY[/path]");
        return;
      }
      rendererLogger.info("Loading profile", pubkyURL);
      await this.loadContent(pubkyURL);
    } catch (error) {
      rendererLogger.error("Initialization failed", error);
      this.showError(
        "Failed to initialize",
        "An error occurred while initializing the profile renderer.",
        error instanceof Error ? error.message : String(error)
      );
    }
  }
  async initializePubky() {
    try {
      const { Client } = await __vitePreload(async () => {
        const { Client: Client2 } = await import("./index-C-6-TiBC.js");
        return { Client: Client2 };
      }, true ? [] : void 0);
      this.pubky = new Client();
      rendererLogger.info("Pubky Client initialized");
    } catch (error) {
      rendererLogger.error("Failed to initialize Pubky Client", error);
      throw new Error("Failed to initialize Pubky client");
    }
  }
  parseURL() {
    try {
      const params = new URLSearchParams(window.location.search);
      const url = params.get("url");
      if (!url) {
        return null;
      }
      rendererLogger.info("Parsing URL", { url });
      const match = url.match(/^pubky:\/\/([^\/]+)(\/.*)?$/);
      if (!match) {
        return null;
      }
      const publicKey = match[1];
      const path = match[2] || "/";
      const isRoot = path === "/";
      return {
        publicKey,
        path,
        isRoot
      };
    } catch (error) {
      rendererLogger.error("Failed to parse URL", error);
      return null;
    }
  }
  async loadContent(pubkyURL) {
    try {
      if (pubkyURL.isRoot) {
        await this.loadProfile(pubkyURL.publicKey);
      } else {
        await this.loadPathContent(pubkyURL.publicKey, pubkyURL.path);
      }
    } catch (error) {
      rendererLogger.error("Failed to load content", error);
      this.showError(
        "Content Not Found",
        "The requested profile or content could not be found.",
        error instanceof Error ? error.message : String(error)
      );
    }
  }
  async loadProfile(publicKey) {
    try {
      rendererLogger.info("Loading profile (checking profile.json first)", { publicKey });
      const profileJsonPath = `pubky://${publicKey}/pub/pubky.app/profile.json`;
      try {
        const jsonResponse = await this.pubky.fetch(profileJsonPath);
        if (jsonResponse.ok) {
          const profileText = await jsonResponse.text();
          const profileData = JSON.parse(profileText);
          rendererLogger.info("profile.json fetched successfully");
          let resolvedImageDataUrl;
          if (profileData.image) {
            resolvedImageDataUrl = await imageHandler.resolveImageURL(profileData.image, publicKey) || void 0;
          }
          const { generateProfileHTML } = await __vitePreload(async () => {
            const { generateProfileHTML: generateProfileHTML2 } = await import("./profile-generator-M-ZsaPl4.js");
            return { generateProfileHTML: generateProfileHTML2 };
          }, true ? [] : void 0);
          const html = generateProfileHTML(profileData, publicKey, resolvedImageDataUrl);
          this.showContent(html, `${profileData.name || publicKey.substring(0, 16)} - Pubky Profile`);
          rendererLogger.info("Profile rendered from profile.json");
          return;
        }
      } catch (jsonError) {
        rendererLogger.warn("profile.json not found, trying index.html fallback", jsonError);
      }
      const indexPath = `pubky://${publicKey}/pub/pubky.app/index.html`;
      try {
        const htmlResponse = await this.pubky.fetch(indexPath);
        if (htmlResponse.ok) {
          const html = await htmlResponse.text();
          this.showContent(html, `${publicKey.substring(0, 16)}... - Pubky Profile`);
          rendererLogger.info("Profile loaded from index.html");
          return;
        }
      } catch (htmlError) {
        rendererLogger.warn("index.html not found either", htmlError);
      }
      rendererLogger.warn("No profile found, generating from Nexus data");
      await this.generateMissingProfile(publicKey);
    } catch (error) {
      rendererLogger.error("Failed to load profile", error);
      throw error;
    }
  }
  async loadPathContent(publicKey, path) {
    try {
      rendererLogger.info("Loading path content", { publicKey, path });
      if (!path.startsWith("/")) {
        path = "/" + path;
      }
      const indexPath = path.endsWith("/") ? `${path}index.html` : `${path}/index.html`;
      const fullIndexPath = `pubky://${publicKey}${indexPath}`;
      try {
        rendererLogger.info("Trying to load index.html", { fullIndexPath });
        const response2 = await this.pubky.fetch(fullIndexPath);
        if (response2.ok) {
          const html = await response2.text();
          this.showContent(html, `${publicKey.substring(0, 16)}... - Pubky Content`);
          rendererLogger.info("Index.html loaded successfully");
          return;
        }
      } catch (indexError) {
        rendererLogger.info("No index.html found, trying raw file", indexError);
      }
      const fullPath = `pubky://${publicKey}${path}`;
      const response = await this.pubky.fetch(fullPath);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      const contentType = response.headers.get("content-type") || "text/plain";
      if (contentType.includes("text/html")) {
        const html = await response.text();
        this.showContent(html, `${publicKey.substring(0, 16)}... - Pubky Content`);
      } else {
        const text = await response.text();
        this.showRawContent(text, contentType, path);
      }
      rendererLogger.info("Content loaded successfully");
    } catch (error) {
      rendererLogger.error("Failed to load path content", error);
      throw error;
    }
  }
  showContent(html, title) {
    document.title = title;
    this.loadingEl.classList.add("hidden");
    this.errorEl.classList.add("hidden");
    this.contentEl.innerHTML = html;
    this.contentEl.classList.remove("hidden");
  }
  showRawContent(content, contentType, path) {
    const escapeHtml = (text) => {
      const div = document.createElement("div");
      div.textContent = text;
      return div.innerHTML;
    };
    const html = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>File: ${escapeHtml(path)}</title>
        <style>
          body {
            margin: 0;
            padding: 20px;
            font-family: 'Courier New', monospace;
            background: #1a1a2e;
            color: #e0e0e0;
          }
          .header {
            background: rgba(102, 126, 234, 0.1);
            border: 1px solid rgba(102, 126, 234, 0.3);
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 20px;
          }
          .header-title {
            font-size: 18px;
            font-weight: 600;
            color: #667eea;
            margin-bottom: 8px;
          }
          .header-info {
            font-size: 14px;
            color: rgba(224, 224, 224, 0.6);
          }
          .content {
            background: rgba(31, 31, 31, 0.8);
            border: 1px solid rgba(102, 126, 234, 0.2);
            border-radius: 8px;
            padding: 20px;
            white-space: pre-wrap;
            word-wrap: break-word;
            overflow-x: auto;
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="header-title">📄 ${escapeHtml(path)}</div>
          <div class="header-info">Content-Type: ${escapeHtml(contentType)}</div>
        </div>
        <div class="content">${escapeHtml(content)}</div>
      </body>
      </html>
    `;
    this.showContent(html, `File: ${path}`);
  }
  async generateMissingProfile(publicKey) {
    try {
      rendererLogger.info("Generating profile from available data", { publicKey });
      const nexusApiUrl = "https://nexus.pubky.app";
      const userUrl = `${nexusApiUrl}/v0/user/${publicKey}`;
      let name = publicKey.substring(0, 16) + "...";
      let bio = "";
      let image = "";
      let links = [];
      try {
        const response = await fetch(userUrl);
        if (response.ok) {
          const userData = await response.json();
          name = userData.name || name;
          bio = userData.bio || "";
          image = userData.image || "";
          if (userData.links && Array.isArray(userData.links)) {
            links = userData.links;
          }
        }
      } catch (nexusError) {
        rendererLogger.warn("Could not fetch Nexus data", nexusError);
      }
      const profileData = {
        name,
        bio,
        image,
        status: "👋 Pubky User",
        links
      };
      let resolvedImageDataUrl;
      if (image) {
        resolvedImageDataUrl = await imageHandler.resolveImageURL(image, publicKey) || void 0;
      }
      const { generateProfileHTML } = await __vitePreload(async () => {
        const { generateProfileHTML: generateProfileHTML2 } = await import("./profile-generator-M-ZsaPl4.js");
        return { generateProfileHTML: generateProfileHTML2 };
      }, true ? [] : void 0);
      const html = generateProfileHTML(profileData, publicKey, resolvedImageDataUrl);
      this.showContent(html, `${name} - Pubky Profile`);
      rendererLogger.info("Profile generated successfully from available data");
    } catch (error) {
      rendererLogger.error("Failed to generate profile", error);
      this.showError(
        "Profile Not Found",
        `This user hasn't created their Pubky profile yet. We tried to generate one from available data but couldn't.`,
        `Public Key: ${publicKey}

The user needs to sign into the Graphiti extension to create their profile.`
      );
    }
  }
  showError(title, message, details) {
    this.loadingEl.classList.add("hidden");
    this.contentEl.classList.add("hidden");
    const errorTitleEl = this.errorEl.querySelector(".error-title");
    errorTitleEl.textContent = title;
    this.errorMessageEl.textContent = message;
    if (details) {
      this.errorDetailsEl.textContent = details;
      this.errorDetailsEl.classList.remove("hidden");
    } else {
      this.errorDetailsEl.classList.add("hidden");
    }
    this.errorEl.classList.remove("hidden");
  }
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    new ProfileRenderer();
  });
} else {
  new ProfileRenderer();
}
//# sourceMappingURL=profile-renderer-e0xWoBY6.js.map
