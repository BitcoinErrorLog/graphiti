var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
const _Logger = class _Logger {
  constructor() {
    __publicField(this, "logBuffer", []);
    __publicField(this, "maxBufferSize", 1e3);
    this.loadLogs();
  }
  static getInstance() {
    if (!_Logger.instance) {
      _Logger.instance = new _Logger();
    }
    return _Logger.instance;
  }
  async loadLogs() {
    try {
      const result = await chrome.storage.local.get("debugLogs");
      if (result.debugLogs) {
        this.logBuffer = result.debugLogs;
      }
    } catch (error) {
      console.error("Failed to load logs:", error);
    }
  }
  async saveLogs() {
    try {
      await chrome.storage.local.set({ debugLogs: this.logBuffer });
    } catch (error) {
      console.error("Failed to save logs:", error);
    }
  }
  log(level, context, message, data, error) {
    const entry = {
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      level,
      context,
      message,
      data,
      error: error ? {
        name: error.name,
        message: error.message,
        stack: error.stack
      } : void 0
    };
    this.logBuffer.push(entry);
    if (this.logBuffer.length > this.maxBufferSize) {
      this.logBuffer = this.logBuffer.slice(-this.maxBufferSize);
    }
    const style = this.getConsoleStyle(level);
    console.log(
      `%c[${level}] ${context}%c ${message}`,
      style,
      "color: inherit",
      data || "",
      error || ""
    );
    this.saveLogs();
  }
  getConsoleStyle(level) {
    switch (level) {
      case "DEBUG":
        return "color: #6b7280; font-weight: bold";
      case "INFO":
        return "color: #3b82f6; font-weight: bold";
      case "WARN":
        return "color: #f59e0b; font-weight: bold";
      case "ERROR":
        return "color: #ef4444; font-weight: bold";
    }
  }
  debug(context, message, data) {
    this.log("DEBUG", context, message, data);
  }
  info(context, message, data) {
    this.log("INFO", context, message, data);
  }
  warn(context, message, data) {
    this.log("WARN", context, message, data);
  }
  error(context, message, error, data) {
    this.log("ERROR", context, message, data, error);
  }
  async getLogs() {
    return [...this.logBuffer];
  }
  async clearLogs() {
    this.logBuffer = [];
    await chrome.storage.local.remove("debugLogs");
    this.info("Logger", "Logs cleared");
  }
  async exportLogs() {
    return JSON.stringify(this.logBuffer, null, 2);
  }
};
__publicField(_Logger, "instance");
let Logger = _Logger;
const logger = Logger.getInstance();
const scriptRel = "modulepreload";
const assetsURL = function(dep) {
  return "/" + dep;
};
const seen = {};
const __vitePreload = function preload(baseModule, deps, importerUrl) {
  let promise = Promise.resolve();
  if (deps && deps.length > 0) {
    document.getElementsByTagName("link");
    const cspNonceMeta = document.querySelector(
      "meta[property=csp-nonce]"
    );
    const cspNonce = (cspNonceMeta == null ? void 0 : cspNonceMeta.nonce) || (cspNonceMeta == null ? void 0 : cspNonceMeta.getAttribute("nonce"));
    promise = Promise.allSettled(
      deps.map((dep) => {
        dep = assetsURL(dep);
        if (dep in seen) return;
        seen[dep] = true;
        const isCss = dep.endsWith(".css");
        const cssSelector = isCss ? '[rel="stylesheet"]' : "";
        if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
          return;
        }
        const link = document.createElement("link");
        link.rel = isCss ? "stylesheet" : scriptRel;
        if (!isCss) {
          link.as = "script";
        }
        link.crossOrigin = "";
        link.href = dep;
        if (cspNonce) {
          link.setAttribute("nonce", cspNonce);
        }
        document.head.appendChild(link);
        if (isCss) {
          return new Promise((res, rej) => {
            link.addEventListener("load", res);
            link.addEventListener(
              "error",
              () => rej(new Error(`Unable to preload CSS for ${dep}`))
            );
          });
        }
      })
    );
  }
  function handlePreloadError(err) {
    const e = new Event("vite:preloadError", {
      cancelable: true
    });
    e.payload = err;
    window.dispatchEvent(e);
    if (!e.defaultPrevented) {
      throw err;
    }
  }
  return promise.then((res) => {
    for (const item of res || []) {
      if (item.status !== "rejected") continue;
      handlePreloadError(item.reason);
    }
    return baseModule().catch(handlePreloadError);
  });
};
export {
  __vitePreload as _,
  logger as l
};
//# sourceMappingURL=preload-helper-B5H8K-py.js.map
