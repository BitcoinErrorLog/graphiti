const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/annotation-sync-CzW4gvnH.js","assets/preload-helper-B5H8K-py.js","assets/pubky-api-sdk-BFuMTLWs.js","assets/annotations-dRpHBGXv.js"])))=>i.map(i=>d[i]);
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
import "./image-handler-DBCQrSfx.js";
import { j as jsxRuntimeExports, g as getTagStyle, u as useSession, r as reactExports, c as client, R as React, S as SessionProvider } from "./globals-D4887NUA.js";
import { l as logger, _ as __vitePreload } from "./preload-helper-B5H8K-py.js";
import { p as pubkyAPISDK } from "./pubky-api-sdk-BFuMTLWs.js";
import "./profile-generator-M-ZsaPl4.js";
function PostCard({ post }) {
  var _a, _b, _c, _d, _e, _f, _g, _h;
  const details = post.details || {
    id: post.id || "",
    author: post.author_id || "",
    content: post.content || "",
    kind: post.kind || "short",
    uri: post.uri || "",
    indexed_at: post.indexed_at || 0,
    attachments: post.attachments || []
  };
  const getAvatarUrl = (authorId) => {
    const cleanId = authorId.replace("pubky://", "").split("/")[0];
    return `https://nexus.pubky.app/static/avatar/${cleanId}`;
  };
  const formatDate = (timestamp) => {
    const date = new Date(timestamp);
    const now = /* @__PURE__ */ new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 6e4);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);
    if (diffMins < 1) return "Now";
    if (diffMins < 60) return `${diffMins}M`;
    if (diffHours < 24) return `${diffHours}H`;
    if (diffDays < 7) return `${diffDays}D`;
    return date.toLocaleDateString();
  };
  const formatAuthorId = (authorId) => {
    if (authorId.startsWith("pubky://")) {
      authorId = authorId.replace("pubky://", "").split("/")[0];
    }
    if (authorId.length <= 12) return `PK:${authorId}`;
    return `PK:${authorId.substring(0, 4)}...${authorId.substring(authorId.length - 4)}`;
  };
  const formatPostId = (id) => {
    if (id.length <= 12) return id;
    return id.substring(0, 12).toUpperCase();
  };
  const renderContentWithLinks = (content) => {
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    const parts = content.split(urlRegex);
    return parts.map((part, i) => {
      if (part.match(urlRegex)) {
        return /* @__PURE__ */ jsxRuntimeExports.jsx(
          "a",
          {
            href: part,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "text-blue-400 hover:text-blue-300 underline break-all",
            children: part
          },
          i
        );
      }
      return /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: part }, i);
    });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-[#1F1F1F] rounded-xl p-6 hover:bg-[#252525] transition-colors border border-[#2F2F2F]", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0 flex-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: getAvatarUrl(details.author),
            alt: ((_a = post.author) == null ? void 0 : _a.name) || details.author,
            className: "w-12 h-12 rounded-full object-cover flex-shrink-0",
            onError: (e) => {
              e.currentTarget.style.display = "none";
              if (e.currentTarget.nextSibling) {
                e.currentTarget.nextSibling.style.display = "flex";
              }
            }
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: "w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold flex-shrink-0 hidden",
            children: ((_d = (_c = (_b = post.author) == null ? void 0 : _b.name) == null ? void 0 : _c[0]) == null ? void 0 : _d.toUpperCase()) || details.author.substring(0, 1).toUpperCase()
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-w-0 flex-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-baseline gap-2 flex-wrap", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold text-white text-base truncate", children: ((_e = post.author) == null ? void 0 : _e.name) || "Anonymous" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-gray-500 text-sm font-mono", children: formatAuthorId(details.author) })
        ] }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 text-gray-500 text-sm ml-2 flex-shrink-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: formatDate(details.indexed_at) })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-white text-base leading-relaxed whitespace-pre-wrap break-words", children: renderContentWithLinks(details.content) }) }),
    post.tags && post.tags.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2 mb-4", children: post.tags.slice(0, 3).map((tag, idx) => {
      const tagStyle = getTagStyle(tag.label);
      return /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          className: "px-3 py-1.5 rounded-lg text-sm font-medium transition-opacity hover:opacity-80 flex items-center gap-1.5",
          style: {
            backgroundColor: tagStyle.backgroundColor,
            color: tagStyle.color
          },
          children: [
            tag.label,
            tag.taggers_count > 1 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "opacity-75", children: tag.taggers_count })
          ]
        },
        idx
      );
    }) }),
    details.attachments && details.attachments.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2 mb-4", children: details.attachments.map((attachment, idx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      "a",
      {
        href: attachment,
        target: "_blank",
        rel: "noopener noreferrer",
        className: "block bg-[#2A2A2A] hover:bg-[#333333] border border-[#3F3F3F] rounded-lg p-3 transition-colors",
        children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-blue-400 text-sm break-all hover:underline", children: attachment })
      },
      idx
    )) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 pt-3 border-t border-[#2F2F2F]", children: [
      ((_f = post.counts) == null ? void 0 : _f.tags) ? /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "flex items-center gap-1.5 text-gray-400 hover:text-blue-400 transition-colors", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-5 h-5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm", children: post.counts.tags })
      ] }) : null,
      ((_g = post.counts) == null ? void 0 : _g.replies) ? /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "flex items-center gap-1.5 text-gray-400 hover:text-blue-400 transition-colors", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-5 h-5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm", children: post.counts.replies })
      ] }) : null,
      ((_h = post.counts) == null ? void 0 : _h.reposts) ? /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "flex items-center gap-1.5 text-gray-400 hover:text-green-400 transition-colors", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-5 h-5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm", children: post.counts.reposts })
      ] }) : null,
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "a",
        {
          href: details.uri,
          target: "_blank",
          rel: "noopener noreferrer",
          className: "text-gray-500 hover:text-gray-300 transition-colors text-xs font-mono",
          title: "View on Pubky",
          children: formatPostId(details.id)
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "text-gray-400 hover:text-gray-300 transition-colors p-1 rounded-lg hover:bg-[#2A2A2A]", children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-5 h-5", fill: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" }) }) })
    ] })
  ] });
}
function EmptyState({}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-12 px-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-24 h-24 bg-[#1F1F1F] rounded-full flex items-center justify-center mx-auto mb-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-12 h-12 text-gray-500", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" }) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-bold text-white mb-3", children: "No Posts Yet" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-400 mb-6 max-w-md mx-auto", children: "Nobody has shared anything about this page yet across the network. Be the first to tag and share it!" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-[#1F1F1F] border border-[#3F3F3F] rounded-lg p-4 text-left max-w-md mx-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-sm font-semibold text-blue-400 mb-2 flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-4 h-4", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { fillRule: "evenodd", d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z", clipRule: "evenodd" }) }),
        "How it works"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "text-xs text-gray-400 space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• When anyone tags/bookmarks a URL, it appears here" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Posts are fetched from the Pubky network in real-time" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "• Tag this page to share it with the network" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: () => {
          chrome.action.openPopup();
        },
        className: "px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold rounded-lg transition shadow-lg",
        children: "Tag This Page"
      }
    ) })
  ] });
}
function AnnotationCard({ annotation, onHighlight }) {
  const formatDate = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };
  const handleClick = () => {
    onHighlight(annotation);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: "bg-[#1F1F1F] border border-[#3F3F3F] rounded-lg p-4 hover:border-[#667eea] transition-colors cursor-pointer",
      onClick: handleClick,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-start justify-between mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-4 h-4 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" }) }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-400 truncate", children: annotation.author ? annotation.author.substring(0, 16) + "..." : "Anonymous" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500", children: formatDate(annotation.timestamp) })
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-3 bg-[#2A2A2A] border-l-2 border-yellow-500 rounded p-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500 mb-1", children: "Selected text:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-gray-300 italic line-clamp-3", children: [
            '"',
            annotation.selectedText,
            '"'
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-white whitespace-pre-wrap", children: annotation.comment }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-between text-xs text-gray-500", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { className: "w-3 h-3", fill: "currentColor", viewBox: "0 0 20 20", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M10 12a2 2 0 100-4 2 2 0 000 4z" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("path", { fillRule: "evenodd", d: "M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z", clipRule: "evenodd" })
          ] }),
          "Click to view on page"
        ] }) })
      ]
    }
  );
}
function App() {
  const { session, loading: sessionLoading, refreshSession } = useSession();
  const [panelLoading, setPanelLoading] = reactExports.useState(true);
  const [currentUrl, setCurrentUrl] = reactExports.useState("");
  const [posts, setPosts] = reactExports.useState([]);
  const [annotations, setAnnotations] = reactExports.useState([]);
  const [loadingPosts, setLoadingPosts] = reactExports.useState(false);
  const [activeTab, setActiveTab] = reactExports.useState("posts");
  reactExports.useEffect(() => {
    initializePanel();
    const handleTabUpdate = (_tabId, changeInfo, tab) => {
      if (changeInfo.url && tab.active) {
        logger.info("SidePanel", "Tab URL changed, updating feed", {
          oldUrl: currentUrl,
          newUrl: changeInfo.url
        });
        setCurrentUrl(changeInfo.url);
      }
    };
    const handleTabActivated = async (activeInfo) => {
      try {
        const tab = await chrome.tabs.get(activeInfo.tabId);
        if (tab.url && tab.url !== currentUrl) {
          logger.info("SidePanel", "Active tab changed, updating feed", {
            oldUrl: currentUrl,
            newUrl: tab.url
          });
          setCurrentUrl(tab.url);
        }
      } catch (error) {
        logger.error("SidePanel", "Failed to get tab info", error);
      }
    };
    chrome.tabs.onUpdated.addListener(handleTabUpdate);
    chrome.tabs.onActivated.addListener(handleTabActivated);
    return () => {
      chrome.tabs.onUpdated.removeListener(handleTabUpdate);
      chrome.tabs.onActivated.removeListener(handleTabActivated);
    };
  }, []);
  reactExports.useEffect(() => {
    if (currentUrl) {
      loadPosts();
      loadAnnotations();
    }
  }, [session, currentUrl]);
  reactExports.useEffect(() => {
    const handleMessage = (message) => {
      if (message.type === "SCROLL_TO_ANNOTATION") {
        setActiveTab("annotations");
      }
      if (message.type === "SWITCH_TO_ANNOTATIONS") {
        logger.info("SidePanel", "Switching to annotations tab via keyboard shortcut");
        setActiveTab("annotations");
      }
    };
    chrome.runtime.onMessage.addListener(handleMessage);
    return () => {
      chrome.runtime.onMessage.removeListener(handleMessage);
    };
  }, []);
  const initializePanel = async () => {
    try {
      logger.info("SidePanel", "Initializing side panel");
      const refreshedSession = await refreshSession();
      const activeSession = refreshedSession ?? session;
      if (activeSession) {
        try {
          const { AnnotationSync } = await __vitePreload(async () => {
            const { AnnotationSync: AnnotationSync2 } = await import("./annotation-sync-CzW4gvnH.js");
            return { AnnotationSync: AnnotationSync2 };
          }, true ? __vite__mapDeps([0,1,2,3]) : void 0);
          await AnnotationSync.syncPendingAnnotations();
        } catch (syncError) {
          logger.warn("SidePanel", "Failed to sync pending annotations", syncError);
        }
      }
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab == null ? void 0 : tab.url) {
        setCurrentUrl(tab.url);
        logger.debug("SidePanel", "Current tab URL", { url: tab.url });
      }
      setPanelLoading(false);
    } catch (error) {
      logger.error("SidePanel", "Failed to initialize", error);
      setPanelLoading(false);
    }
  };
  const loadPosts = async () => {
    try {
      setLoadingPosts(true);
      logger.info("SidePanel", "Loading posts for URL via Nexus", {
        url: currentUrl,
        signedIn: !!session,
        searchScope: "ALL posts across network"
      });
      const foundPosts = await pubkyAPISDK.searchPostsByUrl(currentUrl, session == null ? void 0 : session.pubky);
      setPosts(foundPosts || []);
      logger.info("SidePanel", "Posts loaded", { count: (foundPosts == null ? void 0 : foundPosts.length) || 0 });
    } catch (error) {
      logger.error("SidePanel", "Failed to load posts", error);
      setPosts([]);
    } finally {
      setLoadingPosts(false);
    }
  };
  const loadAnnotations = async () => {
    try {
      logger.info("SidePanel", "Loading annotations for URL", { url: currentUrl });
      chrome.runtime.sendMessage(
        {
          type: "GET_ANNOTATIONS",
          url: currentUrl
        },
        (response) => {
          if (response == null ? void 0 : response.annotations) {
            setAnnotations(response.annotations);
            logger.info("SidePanel", "Annotations loaded", { count: response.annotations.length });
          }
        }
      );
    } catch (error) {
      logger.error("SidePanel", "Failed to load annotations", error);
      setAnnotations([]);
    }
  };
  const handleRefresh = () => {
    loadPosts();
    loadAnnotations();
  };
  const handleAnnotationClick = (annotation) => {
    logger.info("SidePanel", "Annotation clicked", { id: annotation.id, url: annotation.url });
    const sendHighlightMessage = (tabId) => {
      chrome.tabs.sendMessage(tabId, {
        type: "HIGHLIGHT_ANNOTATION",
        annotationId: annotation.id
      }).catch((error) => {
        logger.warn("SidePanel", "Could not send highlight message - refresh the page", { error: error.message });
      });
    };
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const currentTab = tabs[0];
      if (!(currentTab == null ? void 0 : currentTab.id)) return;
      const normalizeUrl = (url) => url == null ? void 0 : url.split("#")[0].split("?")[0];
      const currentUrl2 = normalizeUrl(currentTab.url);
      const annotationUrl = normalizeUrl(annotation.url);
      if (currentUrl2 === annotationUrl) {
        sendHighlightMessage(currentTab.id);
      } else if (annotation.url) {
        logger.info("SidePanel", "Navigating to annotation page", { url: annotation.url });
        const tabId = currentTab.id;
        chrome.tabs.update(tabId, { url: annotation.url }, () => {
          const listener = (updatedTabId, changeInfo) => {
            if (updatedTabId === tabId && changeInfo.status === "complete") {
              chrome.tabs.onUpdated.removeListener(listener);
              setTimeout(() => {
                sendHighlightMessage(tabId);
              }, 500);
            }
          };
          chrome.tabs.onUpdated.addListener(listener);
        });
      }
    });
  };
  if (sessionLoading || panelLoading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen flex items-center justify-center bg-[#2B2B2B]", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-gray-400", children: "Loading..." })
    ] }) });
  }
  const SignInBanner = !session ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-[#1A1A1A] border-b border-[#3F3F3F] p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-5 h-5 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold text-white", children: "Not Signed In" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-400", children: "Sign in to create posts and bookmarks" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: () => chrome.action.openPopup(),
        className: "px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white text-sm font-semibold rounded-lg transition flex-shrink-0",
        children: "Sign In"
      }
    )
  ] }) }) : null;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-[#2B2B2B]", children: [
    SignInBanner,
    /* @__PURE__ */ jsxRuntimeExports.jsx("header", { className: "bg-[#1F1F1F] border-b border-[#3F3F3F] sticky top-0 z-10", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-lg font-bold text-white", children: "Graphiti Feed" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-400", children: activeTab === "posts" ? "All posts about this page" : "Annotations on this page" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: handleRefresh,
            disabled: loadingPosts,
            className: "p-2 hover:bg-[#2A2A2A] rounded-lg transition disabled:opacity-50 text-gray-400 hover:text-white",
            title: "Refresh",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              "svg",
              {
                className: `w-5 h-5 ${loadingPosts ? "animate-spin" : ""}`,
                fill: "none",
                stroke: "currentColor",
                viewBox: "0 0 24 24",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "path",
                  {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                  }
                )
              }
            )
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2 mb-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: () => setActiveTab("posts"),
            className: `flex-1 py-2 px-4 rounded-lg text-sm font-semibold transition ${activeTab === "posts" ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white" : "bg-[#2A2A2A] text-gray-400 hover:text-white"}`,
            children: [
              "Posts (",
              posts.length,
              ")"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: () => setActiveTab("annotations"),
            className: `flex-1 py-2 px-4 rounded-lg text-sm font-semibold transition ${activeTab === "annotations" ? "bg-gradient-to-r from-yellow-500 to-orange-500 text-white" : "bg-[#2A2A2A] text-gray-400 hover:text-white"}`,
            children: [
              "Annotations (",
              annotations.length,
              ")"
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-[#2A2A2A] border border-[#3F3F3F] rounded-lg p-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500 mb-1", children: "Current page:" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-300 break-all font-mono", children: currentUrl })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-4", children: activeTab === "posts" ? (
      // Posts Feed
      loadingPosts ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-12", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-gray-400", children: "Loading posts..." })
      ] }) : !posts || posts.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(EmptyState, { currentUrl }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: posts.map((post) => {
        var _a;
        return /* @__PURE__ */ jsxRuntimeExports.jsx(PostCard, { post }, ((_a = post.details) == null ? void 0 : _a.id) || post.id || Math.random().toString());
      }) })
    ) : (
      // Annotations Feed
      annotations.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-12", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center mx-auto mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-8 h-8 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-semibold text-white mb-2", children: "No Annotations Yet" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-gray-400 text-sm mb-4", children: "Select text on the page to create the first annotation" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-left max-w-md mx-auto bg-[#1F1F1F] border border-[#3F3F3F] rounded-lg p-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-400 mb-2", children: "How to annotate:" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("ol", { className: "text-xs text-gray-300 space-y-1 list-decimal list-inside", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Select any text on the page" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: 'Click "Add Annotation" button' }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Write your comment" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Your annotation will be visible to everyone!" })
          ] })
        ] })
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: annotations.map((annotation) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        AnnotationCard,
        {
          annotation,
          onHighlight: handleAnnotationClick
        },
        annotation.id
      )) })
    ) })
  ] });
}
class ErrorBoundary extends reactExports.Component {
  constructor(props) {
    super(props);
    __publicField(this, "handleRetry", () => {
      this.setState({ hasError: false, error: null });
    });
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, errorInfo) {
    logger.error("ErrorBoundary", "React error caught in sidepanel", error, {
      componentStack: errorInfo.componentStack
    });
  }
  render() {
    var _a;
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen flex flex-col items-center justify-center p-6 bg-[#2B2B2B] text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 rounded-full bg-red-500/20 flex items-center justify-center mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "svg",
          {
            className: "w-8 h-8 text-red-400",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              "path",
              {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
              }
            )
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-semibold text-white mb-2", children: "Something went wrong" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-gray-400 text-sm mb-4 max-w-xs", children: ((_a = this.state.error) == null ? void 0 : _a.message) || "An unexpected error occurred" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: this.handleRetry,
            className: "px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold rounded-lg transition",
            children: "Try Again"
          }
        )
      ] });
    }
    return this.props.children;
  }
}
client.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(React.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SessionProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(ErrorBoundary, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(App, {}) }) }) })
);
//# sourceMappingURL=sidepanel-BKypPodE.js.map
