var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
import { _ as __vitePreload, l as logger } from "./preload-helper-B5H8K-py.js";
(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) {
    return;
  }
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) {
    processPreload(link);
  }
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") {
        continue;
      }
      for (const node of mutation.addedNodes) {
        if (node.tagName === "LINK" && node.rel === "modulepreload")
          processPreload(node);
      }
    }
  }).observe(document, { childList: true, subtree: true });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials")
      fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep)
      return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
const _ImageHandler = class _ImageHandler {
  constructor() {
    __publicField(this, "client", null);
  }
  static getInstance() {
    if (!_ImageHandler.instance) {
      _ImageHandler.instance = new _ImageHandler();
    }
    return _ImageHandler.instance;
  }
  async ensureClient() {
    if (!this.client) {
      const { Client } = await __vitePreload(async () => {
        const { Client: Client2 } = await import("./index-C-6-TiBC.js");
        return { Client: Client2 };
      }, true ? [] : void 0);
      this.client = new Client();
    }
    return this.client;
  }
  /**
   * Resolve an image URL for display
   * Converts pubky:// URLs to data URLs
   */
  async resolveImageURL(imageUrl, pubkey) {
    if (!imageUrl) {
      return null;
    }
    try {
      if (imageUrl.startsWith("http://") || imageUrl.startsWith("https://")) {
        return imageUrl;
      }
      if (imageUrl.startsWith("pubky://")) {
        return await this.fetchPubkyImage(imageUrl);
      }
      if (imageUrl.startsWith("/") && pubkey) {
        const fullUrl = `pubky://${pubkey}${imageUrl}`;
        return await this.fetchPubkyImage(fullUrl);
      }
      return imageUrl;
    } catch (error) {
      logger.error("ImageHandler", "Failed to resolve image URL", error, { imageUrl });
      return null;
    }
  }
  /**
   * Fetch an image from a pubky:// URL and convert to data URL
   */
  async fetchPubkyImage(pubkyUrl) {
    try {
      logger.info("ImageHandler", "Fetching image from homeserver", { pubkyUrl });
      const client = await this.ensureClient();
      const response = await client.fetch(pubkyUrl);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      const blob = await response.blob();
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
    } catch (error) {
      logger.error("ImageHandler", "Failed to fetch pubky image", error, { pubkyUrl });
      return null;
    }
  }
  /**
   * Upload an image to the homeserver
   * @param imageData - Base64 data URL or Blob
   * @param pubkey - User's public key
   * @param filename - Optional filename (defaults to avatar.jpg)
   */
  async uploadImage(imageData, pubkey, filename = "avatar.jpg") {
    try {
      logger.info("ImageHandler", "Uploading image to homeserver", { pubkey, filename });
      const client = await this.ensureClient();
      const imagePath = `/pub/pubky.app/files/${filename}`;
      const fullUrl = `pubky://${pubkey}${imagePath}`;
      let blob;
      if (typeof imageData === "string") {
        const response = await fetch(imageData);
        blob = await response.blob();
      } else {
        blob = imageData;
      }
      const uploadResponse = await client.fetch(fullUrl, {
        method: "PUT",
        body: blob,
        credentials: "include"
      });
      if (!uploadResponse.ok) {
        throw new Error(`HTTP ${uploadResponse.status}: ${uploadResponse.statusText}`);
      }
      logger.info("ImageHandler", "Image uploaded successfully", { path: imagePath });
      return imagePath;
    } catch (error) {
      logger.error("ImageHandler", "Failed to upload image", error);
      return null;
    }
  }
};
__publicField(_ImageHandler, "instance");
let ImageHandler = _ImageHandler;
const imageHandler = ImageHandler.getInstance();
export {
  ImageHandler,
  imageHandler
};
//# sourceMappingURL=image-handler-DBCQrSfx.js.map
