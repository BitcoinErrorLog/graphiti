const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/pubky-api-sdk-BFuMTLWs.js","assets/preload-helper-B5H8K-py.js","assets/image-handler-DBCQrSfx.js"])))=>i.map(i=>d[i]);
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
import "./image-handler-DBCQrSfx.js";
import { r as reactExports, j as jsxRuntimeExports, a as authManagerSDK, g as getTagStyle, p as profileManager, u as useSession, c as client, R as React, S as SessionProvider } from "./globals-D4887NUA.js";
import { s as storage, p as pubkyAPISDK } from "./pubky-api-sdk-BFuMTLWs.js";
import { l as logger, _ as __vitePreload } from "./preload-helper-B5H8K-py.js";
import "./profile-generator-M-ZsaPl4.js";
class DrawingSync {
  /**
   * Generate a hash for a URL to use as filename
   */
  static hashUrl(url) {
    let hash = 0;
    for (let i = 0; i < url.length; i++) {
      const char = url.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString(36);
  }
  /**
   * Sync any unsynced drawings to Pubky
   * Call this from popup/sidepanel when they open
   */
  static async syncPendingDrawings() {
    try {
      logger.info("DrawingSync", "Checking for unsynced drawings");
      const allDrawings = await storage.getAllDrawings();
      let syncCount = 0;
      for (const url in allDrawings) {
        const drawing = allDrawings[url];
        if (!drawing.pubkyUrl && drawing.author) {
          try {
            logger.info("DrawingSync", "Syncing drawing to Pubky", { url });
            const urlHash = this.hashUrl(url);
            const filename = `${urlHash}.json`;
            const path = `${this.DRAWING_PATH}${filename}`;
            const drawingData = {
              url: drawing.url,
              canvasData: drawing.canvasData,
              timestamp: drawing.timestamp,
              author: drawing.author
            };
            const pubkyUrl = await pubkyAPISDK.uploadFile(
              path,
              JSON.stringify(drawingData),
              "application/json"
            );
            drawing.pubkyUrl = pubkyUrl;
            await storage.saveDrawing(drawing);
            syncCount++;
            logger.info("DrawingSync", "Drawing synced successfully", {
              url,
              pubkyUrl
            });
          } catch (error) {
            logger.error("DrawingSync", "Failed to sync drawing", error, {
              url
            });
          }
        }
      }
      if (syncCount > 0) {
        logger.info("DrawingSync", "Sync complete", { count: syncCount });
      }
    } catch (error) {
      logger.error("DrawingSync", "Failed to sync drawings", error);
    }
  }
  /**
   * Load drawings from Pubky homeserver
   * This can be used to fetch drawings from followed users
   */
  static async loadRemoteDrawings(pubkyId) {
    try {
      logger.info("DrawingSync", "Loading remote drawings", { pubkyId });
      const drawings = [];
      const files = await pubkyAPISDK.listFiles(
        pubkyId,
        this.DRAWING_PATH
      );
      for (const file of files) {
        try {
          const content = await pubkyAPISDK.getFile(
            pubkyId,
            `${this.DRAWING_PATH}${file.name}`
          );
          const data = JSON.parse(content);
          const drawing = {
            id: `${pubkyId}-${file.name}`,
            url: data.url,
            canvasData: data.canvasData,
            timestamp: data.timestamp,
            author: data.author,
            pubkyUrl: `pubky://${pubkyId}${this.DRAWING_PATH}${file.name}`
          };
          drawings.push(drawing);
        } catch (error) {
          logger.warn("DrawingSync", "Failed to load remote drawing", {
            file: file.name,
            error: error.message
          });
        }
      }
      logger.info("DrawingSync", "Remote drawings loaded", {
        count: drawings.length
      });
      return drawings;
    } catch (error) {
      logger.error("DrawingSync", "Failed to load remote drawings", error);
      return [];
    }
  }
  /**
   * Delete a drawing from Pubky homeserver
   */
  static async deleteRemoteDrawing(url) {
    try {
      const urlHash = this.hashUrl(url);
      const filename = `${urlHash}.json`;
      const path = `${this.DRAWING_PATH}${filename}`;
      await pubkyAPISDK.deleteFile(path);
      logger.info("DrawingSync", "Drawing deleted from homeserver", { url });
    } catch (error) {
      logger.error("DrawingSync", "Failed to delete remote drawing", error);
      throw error;
    }
  }
}
__publicField(DrawingSync, "DRAWING_PATH", "/pub/graphiti.dev/drawings/");
function AuthView({ onAuthSuccess }) {
  const [qrData, setQrData] = reactExports.useState(null);
  const [loading, setLoading] = reactExports.useState(false);
  const [error, setError] = reactExports.useState("");
  const handleSignIn = async () => {
    try {
      setLoading(true);
      setError("");
      logger.info("AuthView", "Starting sign-in flow with SDK");
      const qr = await authManagerSDK.generateAuthQR();
      setQrData(qr);
      authManagerSDK.awaitApproval(
        qr.authRequest,
        (session) => {
          setLoading(false);
          setQrData(null);
          onAuthSuccess(session);
        },
        (error2) => {
          setLoading(false);
          setError(error2.message || "Authentication failed");
          logger.error("AuthView", "Authentication failed", error2);
        }
      );
    } catch (error2) {
      setLoading(false);
      setError(error2.message || "Failed to generate QR code");
      logger.error("AuthView", "Failed to start sign-in", error2);
    }
  };
  const handleCancel = () => {
    authManagerSDK.stopAuthFlow();
    setQrData(null);
    setLoading(false);
    logger.info("AuthView", "Sign-in cancelled");
  };
  if (qrData) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-semibold mb-2 text-white", children: "Sign in with Pubky Ring" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-400 mb-4", children: "Scan this QR code with your Pubky Ring app to sign in" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-white p-4 rounded-lg inline-block mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "img",
        {
          src: qrData.qrDataUrl,
          alt: "QR Code",
          className: "w-64 h-64"
        }
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center mb-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "animate-spin rounded-full h-6 w-6 border-b-2 border-blue-500 mr-2" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm text-gray-400", children: "Waiting for authentication..." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: handleCancel,
          className: "px-4 py-2 bg-[#2A2A2A] hover:bg-[#333333] text-gray-300 rounded transition",
          children: "Cancel"
        }
      )
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-8", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-4xl", children: "🔗" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-bold text-white mb-2", children: "Welcome to Graphiti" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-400 max-w-xs mx-auto", children: "Tag and bookmark URLs to your Pubky homeserver. Discover what your network is sharing about the pages you visit." })
    ] }),
    error && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-4 p-3 bg-red-900/30 border border-red-700/50 rounded-lg", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-red-400", children: [
      "⚠️ ",
      error
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: handleSignIn,
        disabled: loading,
        className: "w-full px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed shadow-lg",
        children: loading ? "Generating QR Code..." : "Sign In with Pubky Ring"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-6 text-xs text-gray-500", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "You'll need the Pubky Ring mobile app to sign in." }) })
  ] });
}
function MainView({
  session,
  currentUrl,
  currentTitle,
  onSignOut,
  onBookmark,
  onPost,
  onOpenSidePanel,
  onEditProfile
}) {
  const [postContent, setPostContent] = reactExports.useState("");
  const [tagInput, setTagInput] = reactExports.useState("");
  const [existingTags, setExistingTags] = reactExports.useState([]);
  const [isBookmarked, setIsBookmarked] = reactExports.useState(false);
  const MAX_CONTENT_LENGTH = 1e3;
  reactExports.useEffect(() => {
    loadExistingData();
  }, [currentUrl]);
  const loadExistingData = async () => {
    try {
      const bookmarked = await storage.isBookmarked(currentUrl);
      setIsBookmarked(bookmarked);
      const tags = await storage.getTagsForUrl(currentUrl);
      setExistingTags(tags);
      logger.debug("MainView", "Loaded existing data", { bookmarked, tags });
    } catch (error) {
      logger.error("MainView", "Failed to load existing data", error);
    }
  };
  const handlePostSubmit = (e) => {
    e.preventDefault();
    if (!postContent.trim() && !tagInput.trim()) {
      alert("Please enter post content or tags");
      return;
    }
    const tags = tagInput.split(/[,\s]+/).map((t) => t.trim().toLowerCase()).filter((t) => t.length > 0 && t.length <= 20);
    if (tagInput.trim() && tags.length === 0) {
      alert("Please enter valid tags (max 20 characters each)");
      return;
    }
    onPost(postContent, tags);
    setPostContent("");
    setTagInput("");
    if (tags.length > 0) {
      setExistingTags((prev) => [.../* @__PURE__ */ new Set([...prev, ...tags])]);
    }
  };
  const handleBookmarkClick = async () => {
    await onBookmark();
    setIsBookmarked(!isBookmarked);
  };
  const handleDrawingToggle = async () => {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab.id) {
        logger.error("MainView", "No active tab found");
        alert("No active tab found");
        return;
      }
      if (tab.url && (tab.url.startsWith("chrome://") || tab.url.startsWith("about:") || tab.url.startsWith("chrome-extension://"))) {
        alert("Drawing mode is not available on this page. Try a regular website.");
        return;
      }
      chrome.tabs.sendMessage(tab.id, { type: "TOGGLE_DRAWING_MODE" }, (response) => {
        if (chrome.runtime.lastError) {
          logger.error("MainView", "Failed to toggle drawing mode", new Error(chrome.runtime.lastError.message));
          alert("Please refresh the page first, then try activating drawing mode again.");
        } else {
          logger.info("MainView", "Drawing mode toggled", { active: response == null ? void 0 : response.active });
          window.close();
        }
      });
    } catch (error) {
      logger.error("MainView", "Failed to toggle drawing mode", error);
      alert("Failed to activate drawing mode. Try refreshing the page.");
    }
  };
  const truncate = (str, maxLen) => {
    if (str.length <= maxLen) return str;
    return str.substring(0, maxLen) + "...";
  };
  const formatPubky = (pubky) => {
    if (pubky.length <= 16) return pubky;
    return `${pubky.substring(0, 8)}...${pubky.substring(pubky.length - 8)}`;
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-[#1F1F1F] border border-[#3F3F3F] rounded-lg p-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500", children: "Signed in as" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-mono text-sm text-white truncate", title: session.pubky, children: formatPubky(session.pubky) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: onSignOut,
            className: "px-3 py-1 text-xs bg-red-900/30 hover:bg-red-900/50 text-red-400 rounded transition ml-2 flex-shrink-0",
            children: "Sign Out"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          onClick: onEditProfile,
          className: "w-full px-3 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white text-sm font-medium rounded-lg transition flex items-center justify-center",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mr-2", children: "✏️" }),
            "Edit Profile"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-[#1F1F1F] border border-[#3F3F3F] rounded-lg p-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold text-gray-400 mb-2", children: "Current Page" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-white mb-1", children: truncate(currentTitle, 50) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500 break-all", children: truncate(currentUrl, 60) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-[#1F1F1F] border border-[#3F3F3F] rounded-lg p-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold text-gray-400 mb-3", children: "Quick Actions" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: handleBookmarkClick,
            className: `w-full px-4 py-2 rounded-lg font-medium transition flex items-center justify-center text-sm ${isBookmarked ? "bg-yellow-900/30 text-yellow-400 hover:bg-yellow-900/50 border border-yellow-700/50" : "bg-blue-900/30 text-blue-400 hover:bg-blue-900/50 border border-blue-700/50"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mr-2", children: isBookmarked ? "⭐" : "☆" }),
              isBookmarked ? "Bookmarked" : "Bookmark Page"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: handleDrawingToggle,
            className: "w-full px-4 py-2 bg-pink-900/30 text-pink-400 hover:bg-pink-900/50 border border-pink-700/50 rounded-lg font-medium transition flex items-center justify-center text-sm",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mr-2", children: "🎨" }),
              "Drawing Mode"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: onOpenSidePanel,
            className: "w-full px-4 py-2 bg-purple-900/30 text-purple-400 hover:bg-purple-900/50 border border-purple-700/50 rounded-lg font-medium transition flex items-center justify-center text-sm",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mr-2", children: "📱" }),
              "View Feed"
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-[#1F1F1F] border border-[#3F3F3F] rounded-lg p-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold text-gray-400 mb-3", children: "Create Post" }),
      existingTags.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500 mb-2", children: "Existing tags:" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: existingTags.map((tag) => {
          const tagStyle = getTagStyle(tag);
          return /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "span",
            {
              className: "px-2 py-1 text-xs rounded-lg",
              style: {
                backgroundColor: tagStyle.backgroundColor,
                color: tagStyle.color
              },
              children: [
                "#",
                tag
              ]
            },
            tag
          );
        }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handlePostSubmit, className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "textarea",
            {
              value: postContent,
              onChange: (e) => setPostContent(e.target.value.slice(0, MAX_CONTENT_LENGTH)),
              placeholder: "What's on your mind? (optional)",
              className: "w-full px-3 py-2 bg-[#2A2A2A] border border-[#3F3F3F] rounded-lg text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none",
              rows: 4,
              maxLength: MAX_CONTENT_LENGTH
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-center mt-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500", children: "URL will be added automatically" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `text-xs ${postContent.length > MAX_CONTENT_LENGTH * 0.9 ? "text-yellow-500" : "text-gray-500"}`, children: [
              postContent.length,
              "/",
              MAX_CONTENT_LENGTH
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            value: tagInput,
            onChange: (e) => setTagInput(e.target.value),
            placeholder: "Tags (comma or space separated)",
            className: "w-full px-3 py-2 bg-[#2A2A2A] border border-[#3F3F3F] rounded-lg text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500",
            maxLength: 100
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "submit",
            disabled: !postContent.trim() && !tagInput.trim(),
            className: "w-full px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed text-sm",
            children: postContent.trim() ? "Create Post" : "Tag URL"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500 mt-2", children: "Posts are published to your Pubky homeserver and tagged for discovery." })
    ] })
  ] });
}
function DebugPanel() {
  const [logs, setLogs] = reactExports.useState([]);
  const [filter, setFilter] = reactExports.useState("all");
  reactExports.useEffect(() => {
    loadLogs();
    const interval = setInterval(loadLogs, 2e3);
    return () => clearInterval(interval);
  }, []);
  const loadLogs = async () => {
    const allLogs = await logger.getLogs();
    setLogs(allLogs);
  };
  const handleClearLogs = async () => {
    if (confirm("Clear all debug logs?")) {
      await logger.clearLogs();
      setLogs([]);
    }
  };
  const handleExportLogs = async () => {
    const exported = await logger.exportLogs();
    const blob = new Blob([exported], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `graphiti-logs-${(/* @__PURE__ */ new Date()).toISOString()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };
  const filteredLogs = logs.filter((log) => {
    if (filter === "all") return true;
    return log.level === filter;
  });
  const getLogColor = (level) => {
    switch (level) {
      case "DEBUG":
        return "text-gray-600";
      case "INFO":
        return "text-blue-600";
      case "WARN":
        return "text-yellow-600";
      case "ERROR":
        return "text-red-600";
      default:
        return "text-gray-600";
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-gray-900 text-gray-100 p-4 border-b border-gray-700", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold", children: "Debug Logs" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "select",
          {
            value: filter,
            onChange: (e) => setFilter(e.target.value),
            className: "text-xs px-2 py-1 bg-gray-800 border border-gray-700 rounded",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "All" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "DEBUG", children: "Debug" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "INFO", children: "Info" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "WARN", children: "Warn" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "ERROR", children: "Error" })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: handleExportLogs,
            className: "text-xs px-2 py-1 bg-blue-600 hover:bg-blue-700 rounded",
            title: "Export logs",
            children: "💾 Export"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: handleClearLogs,
            className: "text-xs px-2 py-1 bg-red-600 hover:bg-red-700 rounded",
            title: "Clear logs",
            children: "🗑️ Clear"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-gray-800 rounded p-2 max-h-64 overflow-y-auto text-xs font-mono", children: filteredLogs.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-gray-500", children: "No logs to display" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-1", children: filteredLogs.slice(-50).map((log, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-b border-gray-700 pb-1 mb-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-gray-500 text-[10px]", children: new Date(log.timestamp).toLocaleTimeString() }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: `font-bold ${getLogColor(log.level)}`, children: [
          "[",
          log.level,
          "]"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-cyan-400", children: [
          log.context,
          ":"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex-1", children: log.message })
      ] }),
      log.data && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "ml-4 mt-1 text-gray-400 text-[10px]", children: JSON.stringify(log.data, null, 2) }),
      log.error && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ml-4 mt-1 text-red-400 text-[10px]", children: [
        "Error: ",
        log.error.message
      ] })
    ] }, idx)) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-[10px] text-gray-500 mt-2", children: [
      "Showing last 50 logs. Total: ",
      filteredLogs.length
    ] })
  ] });
}
const COMMON_EMOJIS = [
  "😊",
  "😃",
  "😄",
  "😁",
  "😆",
  "😅",
  "🤣",
  "😂",
  "🙂",
  "🙃",
  "😉",
  "😌",
  "😍",
  "🥰",
  "😘",
  "😗",
  "😙",
  "😚",
  "😋",
  "😛",
  "😝",
  "😜",
  "🤪",
  "🤨",
  "🧐",
  "🤓",
  "😎",
  "🤩",
  "🥳",
  "😏",
  "😒",
  "😞",
  "😔",
  "😟",
  "😕",
  "🙁",
  "☹️",
  "😣",
  "😖",
  "😫",
  "😩",
  "🥺",
  "😢",
  "😭",
  "😤",
  "😠",
  "😡",
  "🤬",
  "🤯",
  "😳",
  "👋",
  "🤚",
  "🖐",
  "✋",
  "🖖",
  "👌",
  "🤌",
  "🤏",
  "✌️",
  "🤞",
  "🤟",
  "🤘",
  "🤙",
  "👈",
  "👉",
  "👆",
  "👇",
  "☝️",
  "👍",
  "👎",
  "✊",
  "👊",
  "🤛",
  "🤜",
  "👏",
  "🙌",
  "👐",
  "🤲",
  "🤝",
  "🙏",
  "❤️",
  "🧡",
  "💛",
  "💚",
  "💙",
  "💜",
  "🖤",
  "🤍",
  "🤎",
  "💔",
  "❣️",
  "💕",
  "💞",
  "💓",
  "💗",
  "💖",
  "💘",
  "💝",
  "💟",
  "🔥",
  "💫",
  "⭐",
  "🌟",
  "✨",
  "⚡",
  "💥",
  "💢",
  "💦",
  "💨",
  "🎉",
  "🎊",
  "🎁",
  "🎈",
  "🎀",
  "🏆",
  "🥇",
  "🥈",
  "🥉",
  "🚀",
  "🛸",
  "🌙",
  "⭐",
  "🌈",
  "☀️",
  "⛅",
  "🌤️",
  "🌥️",
  "☁️",
  "💻",
  "📱",
  "⌨️",
  "🖥️",
  "🖱️",
  "🎮",
  "🎧",
  "🎵",
  "🎸",
  "🎹",
  "📚",
  "📖",
  "📝",
  "✏️",
  "📌",
  "📍",
  "✅",
  "❌",
  "⭕",
  "🔴"
];
function ProfileEditor() {
  const [loading, setLoading] = reactExports.useState(true);
  const [saving, setSaving] = reactExports.useState(false);
  const [message, setMessage] = reactExports.useState(null);
  const [showEmojiPicker, setShowEmojiPicker] = reactExports.useState(false);
  const [uploading, setUploading] = reactExports.useState(false);
  const [name, setName] = reactExports.useState("");
  const [bio, setBio] = reactExports.useState("");
  const [image, setImage] = reactExports.useState("");
  const [status, setStatus] = reactExports.useState("");
  const [links, setLinks] = reactExports.useState([]);
  reactExports.useEffect(() => {
    loadProfile();
  }, []);
  const loadProfile = async () => {
    try {
      setLoading(true);
      const session = await storage.getSession();
      if (!session) {
        showMessage("error", "Not authenticated");
        setLoading(false);
        return;
      }
      logger.info("ProfileEditor", "Loading profile from homeserver");
      const profileData = await profileManager.fetchProfileJSON(session.pubky);
      if (profileData) {
        setName(profileData.name || "");
        setBio(profileData.bio || "");
        setImage(profileData.image || "");
        setStatus(profileData.status || "");
        setLinks(profileData.links || []);
        logger.info("ProfileEditor", "Profile loaded from homeserver", profileData);
      } else {
        logger.info("ProfileEditor", "No profile.json found, fetching from Nexus");
        try {
          const { nexusClient } = await __vitePreload(async () => {
            const { nexusClient: nexusClient2 } = await import("./pubky-api-sdk-BFuMTLWs.js").then((n) => n.a);
            return { nexusClient: nexusClient2 };
          }, true ? __vite__mapDeps([0,1]) : void 0);
          const userData = await nexusClient.getUser(session.pubky);
          setName(userData.name || session.pubky.substring(0, 16));
          setBio(userData.bio || "");
          setImage(userData.image || "");
          setStatus("👋 Pubky User");
          setLinks(userData.links || []);
          logger.info("ProfileEditor", "Loaded defaults from Nexus");
        } catch (nexusError) {
          logger.warn("ProfileEditor", "Could not load from Nexus, using basic defaults");
          setName(session.pubky.substring(0, 16));
          setStatus("👋 Pubky User");
        }
      }
      setLoading(false);
    } catch (error) {
      logger.error("ProfileEditor", "Failed to load profile", error);
      showMessage("error", "Failed to load profile");
      setLoading(false);
    }
  };
  const showMessage = (type, text) => {
    setMessage({ type, text });
    setTimeout(() => setMessage(null), 3e3);
  };
  const handleSave = async () => {
    try {
      setSaving(true);
      setMessage(null);
      if (!name.trim()) {
        showMessage("error", "Name is required");
        return;
      }
      const session = await storage.getSession();
      if (!session) {
        showMessage("error", "Not authenticated. Please sign in first.");
        return;
      }
      const validLinks = links.filter((link) => link.title.trim() && link.url.trim());
      const profileData = {
        name: name.trim(),
        bio: bio.trim() || void 0,
        image: image.trim() || void 0,
        status: status.trim() || void 0,
        links: validLinks.length > 0 ? validLinks : void 0
      };
      logger.info("ProfileEditor", "Saving profile");
      const success = await profileManager.saveProfile(session.pubky, profileData);
      if (success) {
        logger.info("ProfileEditor", "Profile saved successfully");
        showMessage("success", "Profile saved successfully! Both profile.json and index.html updated.");
      } else {
        throw new Error("Failed to save profile");
      }
    } catch (error) {
      logger.error("ProfileEditor", "Failed to save profile", error);
      showMessage("error", error instanceof Error ? error.message : "Failed to save profile");
    } finally {
      setSaving(false);
    }
  };
  const addLink = () => {
    setLinks([...links, { title: "", url: "" }]);
  };
  const updateLink = (index, field, value) => {
    const newLinks = [...links];
    newLinks[index][field] = value;
    setLinks(newLinks);
  };
  const removeLink = (index) => {
    setLinks(links.filter((_, i) => i !== index));
  };
  const handleImageUpload = async (event) => {
    var _a;
    const file = (_a = event.target.files) == null ? void 0 : _a[0];
    if (!file) return;
    try {
      setUploading(true);
      setMessage(null);
      if (!file.type.startsWith("image/")) {
        showMessage("error", "Please select an image file");
        return;
      }
      if (file.size > 5 * 1024 * 1024) {
        showMessage("error", "Image must be smaller than 5MB");
        return;
      }
      const session = await storage.getSession();
      if (!session) {
        showMessage("error", "Not authenticated");
        return;
      }
      logger.info("ProfileEditor", "Uploading image", { size: file.size, type: file.type });
      const { imageHandler } = await __vitePreload(async () => {
        const { imageHandler: imageHandler2 } = await import("./image-handler-DBCQrSfx.js");
        return { imageHandler: imageHandler2 };
      }, true ? __vite__mapDeps([2,1]) : void 0);
      const timestamp = Date.now();
      const extension = file.name.split(".").pop() || "jpg";
      const filename = `avatar-${timestamp}.${extension}`;
      const imagePath = await imageHandler.uploadImage(file, session.pubky, filename);
      if (imagePath) {
        setImage(imagePath);
        showMessage("success", "Image uploaded successfully!");
        logger.info("ProfileEditor", "Image uploaded", { path: imagePath });
      } else {
        throw new Error("Failed to upload image");
      }
    } catch (error) {
      logger.error("ProfileEditor", "Failed to upload image", error);
      showMessage("error", "Failed to upload image. Please try again.");
    } finally {
      setUploading(false);
    }
  };
  if (loading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center py-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-gray-400", children: "Loading profile..." }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-bold text-white mb-4", children: "Edit Profile" }),
    message && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: `p-3 rounded-lg ${message.type === "success" ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}`,
        children: message.text
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-medium text-gray-300 mb-1", children: "Name *" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            value: name,
            onChange: (e) => setName(e.target.value),
            className: "w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500",
            placeholder: "Your display name"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-medium text-gray-300 mb-1", children: "Bio" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "textarea",
          {
            value: bio,
            onChange: (e) => setBio(e.target.value),
            rows: 3,
            className: "w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500",
            placeholder: "Tell us about yourself..."
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-medium text-gray-300 mb-1", children: "Avatar Image" }),
        image && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-3 flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: image,
              alt: "Avatar preview",
              className: "w-20 h-20 rounded-full object-cover border-2 border-gray-600",
              onError: (e) => {
                e.currentTarget.style.display = "none";
              }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: () => setImage(""),
              className: "text-sm text-red-400 hover:text-red-300",
              children: "Remove"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex-1 px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white text-center cursor-pointer hover:bg-gray-600 focus-within:ring-2 focus-within:ring-purple-500", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "file",
                accept: "image/*",
                onChange: handleImageUpload,
                disabled: uploading,
                className: "hidden"
              }
            ),
            uploading ? "Uploading..." : "📤 Upload Image"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: image,
              onChange: (e) => setImage(e.target.value),
              className: "flex-1 px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 text-sm",
              placeholder: "Or paste image URL"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-gray-400", children: "Upload an image or paste a URL (HTTP/HTTPS or homeserver path)" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-medium text-gray-300 mb-1", children: "Status" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => setShowEmojiPicker(!showEmojiPicker),
                className: "w-12 h-10 bg-gray-700 border border-gray-600 rounded-lg text-2xl hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-purple-500 cursor-pointer flex items-center justify-center",
                title: "Pick emoji",
                children: status && /^[\u{1F300}-\u{1F9FF}]/u.test(status) ? status.charAt(0) : "😊"
              }
            ),
            showEmojiPicker && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-full left-0 mt-2 bg-gray-800 border border-gray-600 rounded-lg p-3 shadow-xl z-50 w-80 max-h-60 overflow-y-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-8 gap-2", children: COMMON_EMOJIS.map((emoji, index) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                type: "button",
                onClick: () => {
                  const textWithoutEmoji = status.replace(/^[\u{1F300}-\u{1F9FF}\s]+/u, "").trim();
                  setStatus(`${emoji} ${textWithoutEmoji}`);
                  setShowEmojiPicker(false);
                },
                className: "text-2xl hover:bg-gray-700 rounded p-1 transition-colors",
                children: emoji
              },
              index
            )) }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: status,
              onChange: (e) => setStatus(e.target.value),
              className: "flex-1 px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500",
              placeholder: "👋 What's your status? (e.g., 🚀 Building cool stuff)"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-gray-400", children: "Click the emoji button to pick one, or type emoji and text directly" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-medium text-gray-300", children: "Links" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: addLink,
              className: "text-sm text-purple-400 hover:text-purple-300",
              children: "+ Add Link"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: links.map((link, index) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: link.title,
              onChange: (e) => updateLink(index, "title", e.target.value),
              className: "flex-1 px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500",
              placeholder: "Link title"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "url",
              value: link.url,
              onChange: (e) => updateLink(index, "url", e.target.value),
              className: "flex-1 px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500",
              placeholder: "https://..."
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: () => removeLink(index),
              className: "px-3 py-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30",
              children: "✕"
            }
          )
        ] }, index)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: handleSave,
          disabled: saving,
          className: "w-full px-4 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:from-gray-600 disabled:to-gray-700 text-white font-medium rounded-lg transition",
          children: saving ? "Saving..." : "Save Profile"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-400", children: "* Your profile will be saved as profile.json and a generated index.html on your homeserver" })
    ] })
  ] });
}
function App() {
  const { session, loading: sessionLoading, setSession, signOut, refreshSession } = useSession();
  const [uiLoading, setUiLoading] = reactExports.useState(true);
  const [currentUrl, setCurrentUrl] = reactExports.useState("");
  const [currentTitle, setCurrentTitle] = reactExports.useState("");
  const [showDebug, setShowDebug] = reactExports.useState(false);
  const [currentView, setCurrentView] = reactExports.useState("main");
  reactExports.useEffect(() => {
    initializeApp();
  }, []);
  const initializeApp = async () => {
    try {
      logger.info("App", "Initializing popup");
      const refreshedSession = await refreshSession();
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab == null ? void 0 : tab.url) {
        setCurrentUrl(tab.url);
        setCurrentTitle(tab.title || "");
        logger.debug("App", "Current tab info", { url: tab.url, title: tab.title });
      }
      const sessionForSync = refreshedSession ?? session;
      if (sessionForSync) {
        DrawingSync.syncPendingDrawings().catch((error) => {
          logger.warn("App", "Failed to sync drawings in background", error);
        });
      }
      setUiLoading(false);
    } catch (error) {
      logger.error("App", "Failed to initialize", error);
      setUiLoading(false);
    }
  };
  const handleAuthSuccess = (newSession) => {
    setSession(newSession);
    logger.info("App", "Authentication successful");
  };
  const handleSignOut = async () => {
    try {
      await signOut();
      logger.info("App", "Signed out successfully");
    } catch (error) {
      logger.error("App", "Failed to sign out", error);
    }
  };
  const handleBookmark = async () => {
    try {
      if (!session) return;
      logger.info("App", "Handling bookmark", { url: currentUrl });
      const existingBookmark = await storage.getBookmark(currentUrl);
      if (existingBookmark) {
        if (existingBookmark.postUri) {
          await pubkyAPISDK.deleteBookmark(existingBookmark.postUri);
        }
        await storage.removeBookmark(currentUrl);
        logger.info("App", "Bookmark removed from homeserver and local storage");
        alert("Bookmark removed!");
      } else {
        const { fullPath, bookmarkId, postUri } = await pubkyAPISDK.createBookmark(currentUrl);
        const bookmark = {
          url: currentUrl,
          title: currentTitle,
          timestamp: Date.now(),
          pubkyUrl: fullPath,
          bookmarkId,
          postUri
        };
        await storage.saveBookmark(bookmark);
        logger.info("App", "Bookmark created successfully", { fullPath, bookmarkId, postUri });
        alert("Bookmarked!");
      }
    } catch (error) {
      logger.error("App", "Failed to handle bookmark", error);
      alert("Failed to bookmark. Check debug logs for details.");
    }
  };
  const handlePost = async (content, tags) => {
    try {
      if (!session) return;
      logger.info("App", "Creating post with content and tags", { content: content.substring(0, 50), tags, url: currentUrl });
      const fullContent = content.trim() ? `${content.trim()}

${currentUrl}` : currentUrl;
      const postUrl = await pubkyAPISDK.createLinkPost(currentUrl, fullContent, tags);
      await storage.saveTags(currentUrl, tags);
      logger.info("App", "Post created successfully with content and tags", { postUrl, tags });
      alert(content.trim() ? "Posted!" : `Tagged with: ${tags.join(", ")}`);
    } catch (error) {
      logger.error("App", "Failed to create post", error);
      alert("Failed to create post. Check debug logs for details.");
    }
  };
  const handleOpenSidePanel = () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      var _a;
      if ((_a = tabs[0]) == null ? void 0 : _a.id) {
        chrome.sidePanel.open({ tabId: tabs[0].id });
        logger.info("App", "Side panel opened");
      }
    });
  };
  const handleEditProfile = () => {
    setCurrentView("profile");
  };
  const handleBackToMain = () => {
    setCurrentView("main");
  };
  if (sessionLoading || uiLoading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-[400px] h-[500px] flex items-center justify-center bg-[#2B2B2B]", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-gray-400", children: "Loading..." })
    ] }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-[400px] min-h-[500px] bg-[#2B2B2B]", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("header", { className: "bg-[#1F1F1F] border-b border-[#3F3F3F] p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-bold text-white", children: "Graphiti" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-400", children: "Pubky URL Tagger" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => setShowDebug(!showDebug),
          className: "px-3 py-1 text-xs bg-[#2A2A2A] hover:bg-[#333333] text-gray-300 rounded transition",
          title: "Toggle debug panel",
          children: showDebug ? "🔧 Hide" : "🔧 Debug"
        }
      )
    ] }) }),
    showDebug && /* @__PURE__ */ jsxRuntimeExports.jsx(DebugPanel, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-4", children: !session ? /* @__PURE__ */ jsxRuntimeExports.jsx(AuthView, { onAuthSuccess: handleAuthSuccess }) : currentView === "profile" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          onClick: handleBackToMain,
          className: "mb-4 px-3 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors text-sm flex items-center gap-2",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "←" }),
            " Back"
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(ProfileEditor, {})
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
      MainView,
      {
        session,
        currentUrl,
        currentTitle,
        onSignOut: handleSignOut,
        onBookmark: handleBookmark,
        onPost: handlePost,
        onOpenSidePanel: handleOpenSidePanel,
        onEditProfile: handleEditProfile
      }
    ) })
  ] });
}
class ErrorBoundary extends reactExports.Component {
  constructor(props) {
    super(props);
    __publicField(this, "handleRetry", () => {
      this.setState({ hasError: false, error: null });
    });
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, errorInfo) {
    logger.error("ErrorBoundary", "React error caught", error, {
      componentStack: errorInfo.componentStack
    });
  }
  render() {
    var _a;
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-[200px] flex flex-col items-center justify-center p-6 bg-[#2B2B2B] text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 rounded-full bg-red-500/20 flex items-center justify-center mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "svg",
          {
            className: "w-8 h-8 text-red-400",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              "path",
              {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
              }
            )
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-semibold text-white mb-2", children: "Something went wrong" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-gray-400 text-sm mb-4 max-w-xs", children: ((_a = this.state.error) == null ? void 0 : _a.message) || "An unexpected error occurred" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: this.handleRetry,
            className: "px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold rounded-lg transition",
            children: "Try Again"
          }
        )
      ] });
    }
    return this.props.children;
  }
}
client.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(React.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SessionProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(ErrorBoundary, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(App, {}) }) }) })
);
//# sourceMappingURL=popup-Bk1AAJG7.js.map
