const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/pubky-client-factory-DNjg6uKL.js","assets/logger-Cw7ugbm0.js"])))=>i.map(i=>d[i]);
var E=Object.defineProperty;var P=(c,e,t)=>e in c?E(c,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):c[e]=t;var d=(c,e,t)=>P(c,typeof e!="symbol"?e+"":e,t);import"./modulepreload-polyfill-B5Qt9EMX.js";import{_ as m}from"./logger-Cw7ugbm0.js";import{imageHandler as p}from"./image-handler-Bb5VnKE_.js";import{p as x}from"./vendor-other-OQfjKzyW.js";class b{constructor(){d(this,"logPrefix","[ProfileRenderer]")}info(e,t){console.log(`${this.logPrefix} [INFO] ${e}`,t||"")}warn(e,t){console.warn(`${this.logPrefix} [WARN] ${e}`,t||"")}error(e,t){console.error(`${this.logPrefix} [ERROR] ${e}`,t||"")}}const o=new b;class w{constructor(){d(this,"loadingEl");d(this,"errorEl");d(this,"errorMessageEl");d(this,"errorDetailsEl");d(this,"contentEl");d(this,"pubky",null);this.loadingEl=document.getElementById("loading"),this.errorEl=document.getElementById("error"),this.errorMessageEl=document.getElementById("error-message"),this.errorDetailsEl=document.getElementById("error-details"),this.contentEl=document.getElementById("profile-content"),this.init()}async init(){try{await this.initializePubky();const e=this.parseURL();if(!e){this.showError("Invalid URL","The URL format is invalid. Expected: pubky://PUBLIC_KEY[/path]");return}o.info("Loading profile",e),await this.loadContent(e)}catch(e){o.error("Initialization failed",e),this.showError("Failed to initialize","An error occurred while initializing the profile renderer.",e instanceof Error?e.message:String(e))}}async initializePubky(){try{const{getPubkyClientAsync:e}=await m(async()=>{const{getPubkyClientAsync:t}=await import("./pubky-client-factory-DNjg6uKL.js");return{getPubkyClientAsync:t}},__vite__mapDeps([0,1]));this.pubky=await e(),o.info("Pubky Client initialized via singleton")}catch(e){throw o.error("Failed to initialize Pubky Client",e),new Error("Failed to initialize Pubky client")}}parseURL(){try{const t=new URLSearchParams(window.location.search).get("url");if(!t)return null;o.info("Parsing URL",{url:t});const n=t.match(/^pubky:\/\/([^\/]+)(\/.*)?$/);if(!n)return null;const r=n[1],a=n[2]||"/";return{publicKey:r,path:a,isRoot:a==="/"}}catch(e){return o.error("Failed to parse URL",e),null}}async loadContent(e){try{e.isRoot?await this.loadProfile(e.publicKey):await this.loadPathContent(e.publicKey,e.path)}catch(t){o.error("Failed to load content",t),this.showError("Content Not Found","The requested profile or content could not be found.",t instanceof Error?t.message:String(t))}}async loadProfile(e){try{o.info("Loading profile (checking profile.json first)",{publicKey:e});const t=`pubky://${e}/pub/pubky.app/profile.json`;try{const r=await this.pubky.fetch(t);if(r.ok){const a=await r.text(),i=JSON.parse(a);o.info("profile.json fetched successfully");let l;i.image&&(l=await p.resolveImageURL(i.image,e)||void 0);const{generateProfileHTML:s}=await m(async()=>{const{generateProfileHTML:g}=await import("./profile-generator-CjceR2JW.js");return{generateProfileHTML:g}},[]),h=s(i,e,l);this.showContent(h,`${i.name||e.substring(0,16)} - Pubky Profile`),o.info("Profile rendered from profile.json");return}}catch(r){o.warn("profile.json not found, trying index.html fallback",r)}const n=`pubky://${e}/pub/pubky.app/index.html`;try{const r=await this.pubky.fetch(n);if(r.ok){const a=await r.text();this.showContent(a,`${e.substring(0,16)}... - Pubky Profile`),o.info("Profile loaded from index.html");return}}catch(r){o.warn("index.html not found either",r)}o.warn("No profile found, generating from Nexus data"),await this.generateMissingProfile(e)}catch(t){throw o.error("Failed to load profile",t),t}}async loadPathContent(e,t){try{o.info("Loading path content",{publicKey:e,path:t}),t.startsWith("/")||(t="/"+t);const n=t.endsWith("/")?`${t}index.html`:`${t}/index.html`,r=`pubky://${e}${n}`;try{o.info("Trying to load index.html",{fullIndexPath:r});const s=await this.pubky.fetch(r);if(s.ok){const h=await s.text();this.showContent(h,`${e.substring(0,16)}... - Pubky Content`),o.info("Index.html loaded successfully");return}}catch(s){o.info("No index.html found, trying raw file",s)}const a=`pubky://${e}${t}`,i=await this.pubky.fetch(a);if(!i.ok)throw new Error(`HTTP ${i.status}: ${i.statusText}`);const l=i.headers.get("content-type")||"text/plain";if(l.includes("text/html")){const s=await i.text();this.showContent(s,`${e.substring(0,16)}... - Pubky Content`)}else{const s=await i.text();this.showRawContent(s,l,t)}o.info("Content loaded successfully")}catch(n){throw o.error("Failed to load path content",n),n}}async showContent(e,t){document.title=t,this.loadingEl.classList.add("hidden"),this.errorEl.classList.add("hidden"),this.contentEl.innerHTML=x.sanitize(e),this.contentEl.classList.remove("hidden")}showRawContent(e,t,n){const r=i=>{const l=document.createElement("div");return l.textContent=i,l.innerHTML},a=`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>File: ${r(n)}</title>
        <style>
          body {
            margin: 0;
            padding: 20px;
            font-family: 'Courier New', monospace;
            background: #1a1a2e;
            color: #e0e0e0;
          }
          .header {
            background: rgba(102, 126, 234, 0.1);
            border: 1px solid rgba(102, 126, 234, 0.3);
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 20px;
          }
          .header-title {
            font-size: 18px;
            font-weight: 600;
            color: #667eea;
            margin-bottom: 8px;
          }
          .header-info {
            font-size: 14px;
            color: rgba(224, 224, 224, 0.6);
          }
          .content {
            background: rgba(31, 31, 31, 0.8);
            border: 1px solid rgba(102, 126, 234, 0.2);
            border-radius: 8px;
            padding: 20px;
            white-space: pre-wrap;
            word-wrap: break-word;
            overflow-x: auto;
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="header-title">📄 ${r(n)}</div>
          <div class="header-info">Content-Type: ${r(t)}</div>
        </div>
        <div class="content">${r(e)}</div>
      </body>
      </html>
    `;this.showContent(a,`File: ${n}`)}async generateMissingProfile(e){try{o.info("Generating profile from available data",{publicKey:e});const n=`https://nexus.pubky.app/v0/user/${e}`;let r=e.substring(0,16)+"...",a="",i="",l=[];try{const f=await fetch(n);if(f.ok){const u=await f.json();r=u.name||r,a=u.bio||"",i=u.image||"",u.links&&Array.isArray(u.links)&&(l=u.links)}}catch(f){o.warn("Could not fetch Nexus data",f)}const s={name:r,bio:a,image:i,status:"👋 Pubky User",links:l};let h;i&&(h=await p.resolveImageURL(i,e)||void 0);const{generateProfileHTML:g}=await m(async()=>{const{generateProfileHTML:f}=await import("./profile-generator-CjceR2JW.js");return{generateProfileHTML:f}},[]),y=g(s,e,h);this.showContent(y,`${r} - Pubky Profile`),o.info("Profile generated successfully from available data")}catch(t){o.error("Failed to generate profile",t),this.showError("Profile Not Found","This user hasn't created their Pubky profile yet. We tried to generate one from available data but couldn't.",`Public Key: ${e}

The user needs to sign into the Graphiti extension to create their profile.`)}}showError(e,t,n){this.loadingEl.classList.add("hidden"),this.contentEl.classList.add("hidden");const r=this.errorEl.querySelector(".error-title");r.textContent=e,this.errorMessageEl.textContent=t,n?(this.errorDetailsEl.textContent=n,this.errorDetailsEl.classList.remove("hidden")):this.errorDetailsEl.classList.add("hidden"),this.errorEl.classList.remove("hidden")}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{new w}):new w;
