var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
class ContentLogger {
  constructor() {
    __publicField(this, "logPrefix", "[Graphiti]");
  }
  info(context, message, data) {
    console.log(`${this.logPrefix} [INFO] ${context}: ${message}`, data || "");
  }
  warn(context, message, data) {
    console.warn(`${this.logPrefix} [WARN] ${context}: ${message}`, data || "");
  }
  error(context, message, error) {
    console.error(`${this.logPrefix} [ERROR] ${context}: ${message}`, error || "");
  }
  debug(context, message, data) {
    console.debug(`${this.logPrefix} [DEBUG] ${context}: ${message}`, data || "");
  }
}
const contentLogger = new ContentLogger();
var lib$3 = {};
var diffMatchPatch = { exports: {} };
(function(module) {
  var diff_match_patch = function() {
    this.Diff_Timeout = 1;
    this.Diff_EditCost = 4;
    this.Match_Threshold = 0.5;
    this.Match_Distance = 1e3;
    this.Patch_DeleteThreshold = 0.5;
    this.Patch_Margin = 4;
    this.Match_MaxBits = 32;
  };
  var DIFF_DELETE = -1;
  var DIFF_INSERT = 1;
  var DIFF_EQUAL = 0;
  diff_match_patch.Diff = function(op, text) {
    return [op, text];
  };
  diff_match_patch.prototype.diff_main = function(text1, text2, opt_checklines, opt_deadline) {
    if (typeof opt_deadline == "undefined") {
      if (this.Diff_Timeout <= 0) {
        opt_deadline = Number.MAX_VALUE;
      } else {
        opt_deadline = (/* @__PURE__ */ new Date()).getTime() + this.Diff_Timeout * 1e3;
      }
    }
    var deadline = opt_deadline;
    if (text1 == null || text2 == null) {
      throw new Error("Null input. (diff_main)");
    }
    if (text1 == text2) {
      if (text1) {
        return [new diff_match_patch.Diff(DIFF_EQUAL, text1)];
      }
      return [];
    }
    if (typeof opt_checklines == "undefined") {
      opt_checklines = true;
    }
    var checklines = opt_checklines;
    var commonlength = this.diff_commonPrefix(text1, text2);
    var commonprefix = text1.substring(0, commonlength);
    text1 = text1.substring(commonlength);
    text2 = text2.substring(commonlength);
    commonlength = this.diff_commonSuffix(text1, text2);
    var commonsuffix = text1.substring(text1.length - commonlength);
    text1 = text1.substring(0, text1.length - commonlength);
    text2 = text2.substring(0, text2.length - commonlength);
    var diffs = this.diff_compute_(text1, text2, checklines, deadline);
    if (commonprefix) {
      diffs.unshift(new diff_match_patch.Diff(DIFF_EQUAL, commonprefix));
    }
    if (commonsuffix) {
      diffs.push(new diff_match_patch.Diff(DIFF_EQUAL, commonsuffix));
    }
    this.diff_cleanupMerge(diffs);
    return diffs;
  };
  diff_match_patch.prototype.diff_compute_ = function(text1, text2, checklines, deadline) {
    var diffs;
    if (!text1) {
      return [new diff_match_patch.Diff(DIFF_INSERT, text2)];
    }
    if (!text2) {
      return [new diff_match_patch.Diff(DIFF_DELETE, text1)];
    }
    var longtext = text1.length > text2.length ? text1 : text2;
    var shorttext = text1.length > text2.length ? text2 : text1;
    var i = longtext.indexOf(shorttext);
    if (i != -1) {
      diffs = [
        new diff_match_patch.Diff(DIFF_INSERT, longtext.substring(0, i)),
        new diff_match_patch.Diff(DIFF_EQUAL, shorttext),
        new diff_match_patch.Diff(
          DIFF_INSERT,
          longtext.substring(i + shorttext.length)
        )
      ];
      if (text1.length > text2.length) {
        diffs[0][0] = diffs[2][0] = DIFF_DELETE;
      }
      return diffs;
    }
    if (shorttext.length == 1) {
      return [
        new diff_match_patch.Diff(DIFF_DELETE, text1),
        new diff_match_patch.Diff(DIFF_INSERT, text2)
      ];
    }
    var hm = this.diff_halfMatch_(text1, text2);
    if (hm) {
      var text1_a = hm[0];
      var text1_b = hm[1];
      var text2_a = hm[2];
      var text2_b = hm[3];
      var mid_common = hm[4];
      var diffs_a = this.diff_main(text1_a, text2_a, checklines, deadline);
      var diffs_b = this.diff_main(text1_b, text2_b, checklines, deadline);
      return diffs_a.concat(
        [new diff_match_patch.Diff(DIFF_EQUAL, mid_common)],
        diffs_b
      );
    }
    if (checklines && text1.length > 100 && text2.length > 100) {
      return this.diff_lineMode_(text1, text2, deadline);
    }
    return this.diff_bisect_(text1, text2, deadline);
  };
  diff_match_patch.prototype.diff_lineMode_ = function(text1, text2, deadline) {
    var a = this.diff_linesToChars_(text1, text2);
    text1 = a.chars1;
    text2 = a.chars2;
    var linearray = a.lineArray;
    var diffs = this.diff_main(text1, text2, false, deadline);
    this.diff_charsToLines_(diffs, linearray);
    this.diff_cleanupSemantic(diffs);
    diffs.push(new diff_match_patch.Diff(DIFF_EQUAL, ""));
    var pointer = 0;
    var count_delete = 0;
    var count_insert = 0;
    var text_delete = "";
    var text_insert = "";
    while (pointer < diffs.length) {
      switch (diffs[pointer][0]) {
        case DIFF_INSERT:
          count_insert++;
          text_insert += diffs[pointer][1];
          break;
        case DIFF_DELETE:
          count_delete++;
          text_delete += diffs[pointer][1];
          break;
        case DIFF_EQUAL:
          if (count_delete >= 1 && count_insert >= 1) {
            diffs.splice(
              pointer - count_delete - count_insert,
              count_delete + count_insert
            );
            pointer = pointer - count_delete - count_insert;
            var subDiff = this.diff_main(text_delete, text_insert, false, deadline);
            for (var j = subDiff.length - 1; j >= 0; j--) {
              diffs.splice(pointer, 0, subDiff[j]);
            }
            pointer = pointer + subDiff.length;
          }
          count_insert = 0;
          count_delete = 0;
          text_delete = "";
          text_insert = "";
          break;
      }
      pointer++;
    }
    diffs.pop();
    return diffs;
  };
  diff_match_patch.prototype.diff_bisect_ = function(text1, text2, deadline) {
    var text1_length = text1.length;
    var text2_length = text2.length;
    var max_d = Math.ceil((text1_length + text2_length) / 2);
    var v_offset = max_d;
    var v_length = 2 * max_d;
    var v1 = new Array(v_length);
    var v2 = new Array(v_length);
    for (var x = 0; x < v_length; x++) {
      v1[x] = -1;
      v2[x] = -1;
    }
    v1[v_offset + 1] = 0;
    v2[v_offset + 1] = 0;
    var delta = text1_length - text2_length;
    var front = delta % 2 != 0;
    var k1start = 0;
    var k1end = 0;
    var k2start = 0;
    var k2end = 0;
    for (var d = 0; d < max_d; d++) {
      if ((/* @__PURE__ */ new Date()).getTime() > deadline) {
        break;
      }
      for (var k1 = -d + k1start; k1 <= d - k1end; k1 += 2) {
        var k1_offset = v_offset + k1;
        var x1;
        if (k1 == -d || k1 != d && v1[k1_offset - 1] < v1[k1_offset + 1]) {
          x1 = v1[k1_offset + 1];
        } else {
          x1 = v1[k1_offset - 1] + 1;
        }
        var y1 = x1 - k1;
        while (x1 < text1_length && y1 < text2_length && text1.charAt(x1) == text2.charAt(y1)) {
          x1++;
          y1++;
        }
        v1[k1_offset] = x1;
        if (x1 > text1_length) {
          k1end += 2;
        } else if (y1 > text2_length) {
          k1start += 2;
        } else if (front) {
          var k2_offset = v_offset + delta - k1;
          if (k2_offset >= 0 && k2_offset < v_length && v2[k2_offset] != -1) {
            var x2 = text1_length - v2[k2_offset];
            if (x1 >= x2) {
              return this.diff_bisectSplit_(text1, text2, x1, y1, deadline);
            }
          }
        }
      }
      for (var k2 = -d + k2start; k2 <= d - k2end; k2 += 2) {
        var k2_offset = v_offset + k2;
        var x2;
        if (k2 == -d || k2 != d && v2[k2_offset - 1] < v2[k2_offset + 1]) {
          x2 = v2[k2_offset + 1];
        } else {
          x2 = v2[k2_offset - 1] + 1;
        }
        var y2 = x2 - k2;
        while (x2 < text1_length && y2 < text2_length && text1.charAt(text1_length - x2 - 1) == text2.charAt(text2_length - y2 - 1)) {
          x2++;
          y2++;
        }
        v2[k2_offset] = x2;
        if (x2 > text1_length) {
          k2end += 2;
        } else if (y2 > text2_length) {
          k2start += 2;
        } else if (!front) {
          var k1_offset = v_offset + delta - k2;
          if (k1_offset >= 0 && k1_offset < v_length && v1[k1_offset] != -1) {
            var x1 = v1[k1_offset];
            var y1 = v_offset + x1 - k1_offset;
            x2 = text1_length - x2;
            if (x1 >= x2) {
              return this.diff_bisectSplit_(text1, text2, x1, y1, deadline);
            }
          }
        }
      }
    }
    return [
      new diff_match_patch.Diff(DIFF_DELETE, text1),
      new diff_match_patch.Diff(DIFF_INSERT, text2)
    ];
  };
  diff_match_patch.prototype.diff_bisectSplit_ = function(text1, text2, x, y, deadline) {
    var text1a = text1.substring(0, x);
    var text2a = text2.substring(0, y);
    var text1b = text1.substring(x);
    var text2b = text2.substring(y);
    var diffs = this.diff_main(text1a, text2a, false, deadline);
    var diffsb = this.diff_main(text1b, text2b, false, deadline);
    return diffs.concat(diffsb);
  };
  diff_match_patch.prototype.diff_linesToChars_ = function(text1, text2) {
    var lineArray = [];
    var lineHash = {};
    lineArray[0] = "";
    function diff_linesToCharsMunge_(text) {
      var chars = "";
      var lineStart = 0;
      var lineEnd = -1;
      var lineArrayLength = lineArray.length;
      while (lineEnd < text.length - 1) {
        lineEnd = text.indexOf("\n", lineStart);
        if (lineEnd == -1) {
          lineEnd = text.length - 1;
        }
        var line = text.substring(lineStart, lineEnd + 1);
        if (lineHash.hasOwnProperty ? lineHash.hasOwnProperty(line) : lineHash[line] !== void 0) {
          chars += String.fromCharCode(lineHash[line]);
        } else {
          if (lineArrayLength == maxLines) {
            line = text.substring(lineStart);
            lineEnd = text.length;
          }
          chars += String.fromCharCode(lineArrayLength);
          lineHash[line] = lineArrayLength;
          lineArray[lineArrayLength++] = line;
        }
        lineStart = lineEnd + 1;
      }
      return chars;
    }
    var maxLines = 4e4;
    var chars1 = diff_linesToCharsMunge_(text1);
    maxLines = 65535;
    var chars2 = diff_linesToCharsMunge_(text2);
    return { chars1, chars2, lineArray };
  };
  diff_match_patch.prototype.diff_charsToLines_ = function(diffs, lineArray) {
    for (var i = 0; i < diffs.length; i++) {
      var chars = diffs[i][1];
      var text = [];
      for (var j = 0; j < chars.length; j++) {
        text[j] = lineArray[chars.charCodeAt(j)];
      }
      diffs[i][1] = text.join("");
    }
  };
  diff_match_patch.prototype.diff_commonPrefix = function(text1, text2) {
    if (!text1 || !text2 || text1.charAt(0) != text2.charAt(0)) {
      return 0;
    }
    var pointermin = 0;
    var pointermax = Math.min(text1.length, text2.length);
    var pointermid = pointermax;
    var pointerstart = 0;
    while (pointermin < pointermid) {
      if (text1.substring(pointerstart, pointermid) == text2.substring(pointerstart, pointermid)) {
        pointermin = pointermid;
        pointerstart = pointermin;
      } else {
        pointermax = pointermid;
      }
      pointermid = Math.floor((pointermax - pointermin) / 2 + pointermin);
    }
    return pointermid;
  };
  diff_match_patch.prototype.diff_commonSuffix = function(text1, text2) {
    if (!text1 || !text2 || text1.charAt(text1.length - 1) != text2.charAt(text2.length - 1)) {
      return 0;
    }
    var pointermin = 0;
    var pointermax = Math.min(text1.length, text2.length);
    var pointermid = pointermax;
    var pointerend = 0;
    while (pointermin < pointermid) {
      if (text1.substring(text1.length - pointermid, text1.length - pointerend) == text2.substring(text2.length - pointermid, text2.length - pointerend)) {
        pointermin = pointermid;
        pointerend = pointermin;
      } else {
        pointermax = pointermid;
      }
      pointermid = Math.floor((pointermax - pointermin) / 2 + pointermin);
    }
    return pointermid;
  };
  diff_match_patch.prototype.diff_commonOverlap_ = function(text1, text2) {
    var text1_length = text1.length;
    var text2_length = text2.length;
    if (text1_length == 0 || text2_length == 0) {
      return 0;
    }
    if (text1_length > text2_length) {
      text1 = text1.substring(text1_length - text2_length);
    } else if (text1_length < text2_length) {
      text2 = text2.substring(0, text1_length);
    }
    var text_length = Math.min(text1_length, text2_length);
    if (text1 == text2) {
      return text_length;
    }
    var best = 0;
    var length = 1;
    while (true) {
      var pattern = text1.substring(text_length - length);
      var found = text2.indexOf(pattern);
      if (found == -1) {
        return best;
      }
      length += found;
      if (found == 0 || text1.substring(text_length - length) == text2.substring(0, length)) {
        best = length;
        length++;
      }
    }
  };
  diff_match_patch.prototype.diff_halfMatch_ = function(text1, text2) {
    if (this.Diff_Timeout <= 0) {
      return null;
    }
    var longtext = text1.length > text2.length ? text1 : text2;
    var shorttext = text1.length > text2.length ? text2 : text1;
    if (longtext.length < 4 || shorttext.length * 2 < longtext.length) {
      return null;
    }
    var dmp = this;
    function diff_halfMatchI_(longtext2, shorttext2, i) {
      var seed = longtext2.substring(i, i + Math.floor(longtext2.length / 4));
      var j = -1;
      var best_common = "";
      var best_longtext_a, best_longtext_b, best_shorttext_a, best_shorttext_b;
      while ((j = shorttext2.indexOf(seed, j + 1)) != -1) {
        var prefixLength = dmp.diff_commonPrefix(
          longtext2.substring(i),
          shorttext2.substring(j)
        );
        var suffixLength = dmp.diff_commonSuffix(
          longtext2.substring(0, i),
          shorttext2.substring(0, j)
        );
        if (best_common.length < suffixLength + prefixLength) {
          best_common = shorttext2.substring(j - suffixLength, j) + shorttext2.substring(j, j + prefixLength);
          best_longtext_a = longtext2.substring(0, i - suffixLength);
          best_longtext_b = longtext2.substring(i + prefixLength);
          best_shorttext_a = shorttext2.substring(0, j - suffixLength);
          best_shorttext_b = shorttext2.substring(j + prefixLength);
        }
      }
      if (best_common.length * 2 >= longtext2.length) {
        return [
          best_longtext_a,
          best_longtext_b,
          best_shorttext_a,
          best_shorttext_b,
          best_common
        ];
      } else {
        return null;
      }
    }
    var hm1 = diff_halfMatchI_(
      longtext,
      shorttext,
      Math.ceil(longtext.length / 4)
    );
    var hm2 = diff_halfMatchI_(
      longtext,
      shorttext,
      Math.ceil(longtext.length / 2)
    );
    var hm;
    if (!hm1 && !hm2) {
      return null;
    } else if (!hm2) {
      hm = hm1;
    } else if (!hm1) {
      hm = hm2;
    } else {
      hm = hm1[4].length > hm2[4].length ? hm1 : hm2;
    }
    var text1_a, text1_b, text2_a, text2_b;
    if (text1.length > text2.length) {
      text1_a = hm[0];
      text1_b = hm[1];
      text2_a = hm[2];
      text2_b = hm[3];
    } else {
      text2_a = hm[0];
      text2_b = hm[1];
      text1_a = hm[2];
      text1_b = hm[3];
    }
    var mid_common = hm[4];
    return [text1_a, text1_b, text2_a, text2_b, mid_common];
  };
  diff_match_patch.prototype.diff_cleanupSemantic = function(diffs) {
    var changes = false;
    var equalities = [];
    var equalitiesLength = 0;
    var lastEquality = null;
    var pointer = 0;
    var length_insertions1 = 0;
    var length_deletions1 = 0;
    var length_insertions2 = 0;
    var length_deletions2 = 0;
    while (pointer < diffs.length) {
      if (diffs[pointer][0] == DIFF_EQUAL) {
        equalities[equalitiesLength++] = pointer;
        length_insertions1 = length_insertions2;
        length_deletions1 = length_deletions2;
        length_insertions2 = 0;
        length_deletions2 = 0;
        lastEquality = diffs[pointer][1];
      } else {
        if (diffs[pointer][0] == DIFF_INSERT) {
          length_insertions2 += diffs[pointer][1].length;
        } else {
          length_deletions2 += diffs[pointer][1].length;
        }
        if (lastEquality && lastEquality.length <= Math.max(length_insertions1, length_deletions1) && lastEquality.length <= Math.max(
          length_insertions2,
          length_deletions2
        )) {
          diffs.splice(
            equalities[equalitiesLength - 1],
            0,
            new diff_match_patch.Diff(DIFF_DELETE, lastEquality)
          );
          diffs[equalities[equalitiesLength - 1] + 1][0] = DIFF_INSERT;
          equalitiesLength--;
          equalitiesLength--;
          pointer = equalitiesLength > 0 ? equalities[equalitiesLength - 1] : -1;
          length_insertions1 = 0;
          length_deletions1 = 0;
          length_insertions2 = 0;
          length_deletions2 = 0;
          lastEquality = null;
          changes = true;
        }
      }
      pointer++;
    }
    if (changes) {
      this.diff_cleanupMerge(diffs);
    }
    this.diff_cleanupSemanticLossless(diffs);
    pointer = 1;
    while (pointer < diffs.length) {
      if (diffs[pointer - 1][0] == DIFF_DELETE && diffs[pointer][0] == DIFF_INSERT) {
        var deletion = diffs[pointer - 1][1];
        var insertion = diffs[pointer][1];
        var overlap_length1 = this.diff_commonOverlap_(deletion, insertion);
        var overlap_length2 = this.diff_commonOverlap_(insertion, deletion);
        if (overlap_length1 >= overlap_length2) {
          if (overlap_length1 >= deletion.length / 2 || overlap_length1 >= insertion.length / 2) {
            diffs.splice(pointer, 0, new diff_match_patch.Diff(
              DIFF_EQUAL,
              insertion.substring(0, overlap_length1)
            ));
            diffs[pointer - 1][1] = deletion.substring(0, deletion.length - overlap_length1);
            diffs[pointer + 1][1] = insertion.substring(overlap_length1);
            pointer++;
          }
        } else {
          if (overlap_length2 >= deletion.length / 2 || overlap_length2 >= insertion.length / 2) {
            diffs.splice(pointer, 0, new diff_match_patch.Diff(
              DIFF_EQUAL,
              deletion.substring(0, overlap_length2)
            ));
            diffs[pointer - 1][0] = DIFF_INSERT;
            diffs[pointer - 1][1] = insertion.substring(0, insertion.length - overlap_length2);
            diffs[pointer + 1][0] = DIFF_DELETE;
            diffs[pointer + 1][1] = deletion.substring(overlap_length2);
            pointer++;
          }
        }
        pointer++;
      }
      pointer++;
    }
  };
  diff_match_patch.prototype.diff_cleanupSemanticLossless = function(diffs) {
    function diff_cleanupSemanticScore_(one, two) {
      if (!one || !two) {
        return 6;
      }
      var char1 = one.charAt(one.length - 1);
      var char2 = two.charAt(0);
      var nonAlphaNumeric1 = char1.match(diff_match_patch.nonAlphaNumericRegex_);
      var nonAlphaNumeric2 = char2.match(diff_match_patch.nonAlphaNumericRegex_);
      var whitespace1 = nonAlphaNumeric1 && char1.match(diff_match_patch.whitespaceRegex_);
      var whitespace2 = nonAlphaNumeric2 && char2.match(diff_match_patch.whitespaceRegex_);
      var lineBreak1 = whitespace1 && char1.match(diff_match_patch.linebreakRegex_);
      var lineBreak2 = whitespace2 && char2.match(diff_match_patch.linebreakRegex_);
      var blankLine1 = lineBreak1 && one.match(diff_match_patch.blanklineEndRegex_);
      var blankLine2 = lineBreak2 && two.match(diff_match_patch.blanklineStartRegex_);
      if (blankLine1 || blankLine2) {
        return 5;
      } else if (lineBreak1 || lineBreak2) {
        return 4;
      } else if (nonAlphaNumeric1 && !whitespace1 && whitespace2) {
        return 3;
      } else if (whitespace1 || whitespace2) {
        return 2;
      } else if (nonAlphaNumeric1 || nonAlphaNumeric2) {
        return 1;
      }
      return 0;
    }
    var pointer = 1;
    while (pointer < diffs.length - 1) {
      if (diffs[pointer - 1][0] == DIFF_EQUAL && diffs[pointer + 1][0] == DIFF_EQUAL) {
        var equality1 = diffs[pointer - 1][1];
        var edit = diffs[pointer][1];
        var equality2 = diffs[pointer + 1][1];
        var commonOffset = this.diff_commonSuffix(equality1, edit);
        if (commonOffset) {
          var commonString = edit.substring(edit.length - commonOffset);
          equality1 = equality1.substring(0, equality1.length - commonOffset);
          edit = commonString + edit.substring(0, edit.length - commonOffset);
          equality2 = commonString + equality2;
        }
        var bestEquality1 = equality1;
        var bestEdit = edit;
        var bestEquality2 = equality2;
        var bestScore = diff_cleanupSemanticScore_(equality1, edit) + diff_cleanupSemanticScore_(edit, equality2);
        while (edit.charAt(0) === equality2.charAt(0)) {
          equality1 += edit.charAt(0);
          edit = edit.substring(1) + equality2.charAt(0);
          equality2 = equality2.substring(1);
          var score = diff_cleanupSemanticScore_(equality1, edit) + diff_cleanupSemanticScore_(edit, equality2);
          if (score >= bestScore) {
            bestScore = score;
            bestEquality1 = equality1;
            bestEdit = edit;
            bestEquality2 = equality2;
          }
        }
        if (diffs[pointer - 1][1] != bestEquality1) {
          if (bestEquality1) {
            diffs[pointer - 1][1] = bestEquality1;
          } else {
            diffs.splice(pointer - 1, 1);
            pointer--;
          }
          diffs[pointer][1] = bestEdit;
          if (bestEquality2) {
            diffs[pointer + 1][1] = bestEquality2;
          } else {
            diffs.splice(pointer + 1, 1);
            pointer--;
          }
        }
      }
      pointer++;
    }
  };
  diff_match_patch.nonAlphaNumericRegex_ = /[^a-zA-Z0-9]/;
  diff_match_patch.whitespaceRegex_ = /\s/;
  diff_match_patch.linebreakRegex_ = /[\r\n]/;
  diff_match_patch.blanklineEndRegex_ = /\n\r?\n$/;
  diff_match_patch.blanklineStartRegex_ = /^\r?\n\r?\n/;
  diff_match_patch.prototype.diff_cleanupEfficiency = function(diffs) {
    var changes = false;
    var equalities = [];
    var equalitiesLength = 0;
    var lastEquality = null;
    var pointer = 0;
    var pre_ins = false;
    var pre_del = false;
    var post_ins = false;
    var post_del = false;
    while (pointer < diffs.length) {
      if (diffs[pointer][0] == DIFF_EQUAL) {
        if (diffs[pointer][1].length < this.Diff_EditCost && (post_ins || post_del)) {
          equalities[equalitiesLength++] = pointer;
          pre_ins = post_ins;
          pre_del = post_del;
          lastEquality = diffs[pointer][1];
        } else {
          equalitiesLength = 0;
          lastEquality = null;
        }
        post_ins = post_del = false;
      } else {
        if (diffs[pointer][0] == DIFF_DELETE) {
          post_del = true;
        } else {
          post_ins = true;
        }
        if (lastEquality && (pre_ins && pre_del && post_ins && post_del || lastEquality.length < this.Diff_EditCost / 2 && pre_ins + pre_del + post_ins + post_del == 3)) {
          diffs.splice(
            equalities[equalitiesLength - 1],
            0,
            new diff_match_patch.Diff(DIFF_DELETE, lastEquality)
          );
          diffs[equalities[equalitiesLength - 1] + 1][0] = DIFF_INSERT;
          equalitiesLength--;
          lastEquality = null;
          if (pre_ins && pre_del) {
            post_ins = post_del = true;
            equalitiesLength = 0;
          } else {
            equalitiesLength--;
            pointer = equalitiesLength > 0 ? equalities[equalitiesLength - 1] : -1;
            post_ins = post_del = false;
          }
          changes = true;
        }
      }
      pointer++;
    }
    if (changes) {
      this.diff_cleanupMerge(diffs);
    }
  };
  diff_match_patch.prototype.diff_cleanupMerge = function(diffs) {
    diffs.push(new diff_match_patch.Diff(DIFF_EQUAL, ""));
    var pointer = 0;
    var count_delete = 0;
    var count_insert = 0;
    var text_delete = "";
    var text_insert = "";
    var commonlength;
    while (pointer < diffs.length) {
      switch (diffs[pointer][0]) {
        case DIFF_INSERT:
          count_insert++;
          text_insert += diffs[pointer][1];
          pointer++;
          break;
        case DIFF_DELETE:
          count_delete++;
          text_delete += diffs[pointer][1];
          pointer++;
          break;
        case DIFF_EQUAL:
          if (count_delete + count_insert > 1) {
            if (count_delete !== 0 && count_insert !== 0) {
              commonlength = this.diff_commonPrefix(text_insert, text_delete);
              if (commonlength !== 0) {
                if (pointer - count_delete - count_insert > 0 && diffs[pointer - count_delete - count_insert - 1][0] == DIFF_EQUAL) {
                  diffs[pointer - count_delete - count_insert - 1][1] += text_insert.substring(0, commonlength);
                } else {
                  diffs.splice(0, 0, new diff_match_patch.Diff(
                    DIFF_EQUAL,
                    text_insert.substring(0, commonlength)
                  ));
                  pointer++;
                }
                text_insert = text_insert.substring(commonlength);
                text_delete = text_delete.substring(commonlength);
              }
              commonlength = this.diff_commonSuffix(text_insert, text_delete);
              if (commonlength !== 0) {
                diffs[pointer][1] = text_insert.substring(text_insert.length - commonlength) + diffs[pointer][1];
                text_insert = text_insert.substring(0, text_insert.length - commonlength);
                text_delete = text_delete.substring(0, text_delete.length - commonlength);
              }
            }
            pointer -= count_delete + count_insert;
            diffs.splice(pointer, count_delete + count_insert);
            if (text_delete.length) {
              diffs.splice(
                pointer,
                0,
                new diff_match_patch.Diff(DIFF_DELETE, text_delete)
              );
              pointer++;
            }
            if (text_insert.length) {
              diffs.splice(
                pointer,
                0,
                new diff_match_patch.Diff(DIFF_INSERT, text_insert)
              );
              pointer++;
            }
            pointer++;
          } else if (pointer !== 0 && diffs[pointer - 1][0] == DIFF_EQUAL) {
            diffs[pointer - 1][1] += diffs[pointer][1];
            diffs.splice(pointer, 1);
          } else {
            pointer++;
          }
          count_insert = 0;
          count_delete = 0;
          text_delete = "";
          text_insert = "";
          break;
      }
    }
    if (diffs[diffs.length - 1][1] === "") {
      diffs.pop();
    }
    var changes = false;
    pointer = 1;
    while (pointer < diffs.length - 1) {
      if (diffs[pointer - 1][0] == DIFF_EQUAL && diffs[pointer + 1][0] == DIFF_EQUAL) {
        if (diffs[pointer][1].substring(diffs[pointer][1].length - diffs[pointer - 1][1].length) == diffs[pointer - 1][1]) {
          diffs[pointer][1] = diffs[pointer - 1][1] + diffs[pointer][1].substring(0, diffs[pointer][1].length - diffs[pointer - 1][1].length);
          diffs[pointer + 1][1] = diffs[pointer - 1][1] + diffs[pointer + 1][1];
          diffs.splice(pointer - 1, 1);
          changes = true;
        } else if (diffs[pointer][1].substring(0, diffs[pointer + 1][1].length) == diffs[pointer + 1][1]) {
          diffs[pointer - 1][1] += diffs[pointer + 1][1];
          diffs[pointer][1] = diffs[pointer][1].substring(diffs[pointer + 1][1].length) + diffs[pointer + 1][1];
          diffs.splice(pointer + 1, 1);
          changes = true;
        }
      }
      pointer++;
    }
    if (changes) {
      this.diff_cleanupMerge(diffs);
    }
  };
  diff_match_patch.prototype.diff_xIndex = function(diffs, loc) {
    var chars1 = 0;
    var chars2 = 0;
    var last_chars1 = 0;
    var last_chars2 = 0;
    var x;
    for (x = 0; x < diffs.length; x++) {
      if (diffs[x][0] !== DIFF_INSERT) {
        chars1 += diffs[x][1].length;
      }
      if (diffs[x][0] !== DIFF_DELETE) {
        chars2 += diffs[x][1].length;
      }
      if (chars1 > loc) {
        break;
      }
      last_chars1 = chars1;
      last_chars2 = chars2;
    }
    if (diffs.length != x && diffs[x][0] === DIFF_DELETE) {
      return last_chars2;
    }
    return last_chars2 + (loc - last_chars1);
  };
  diff_match_patch.prototype.diff_prettyHtml = function(diffs) {
    var html = [];
    var pattern_amp = /&/g;
    var pattern_lt = /</g;
    var pattern_gt = />/g;
    var pattern_para = /\n/g;
    for (var x = 0; x < diffs.length; x++) {
      var op = diffs[x][0];
      var data = diffs[x][1];
      var text = data.replace(pattern_amp, "&amp;").replace(pattern_lt, "&lt;").replace(pattern_gt, "&gt;").replace(pattern_para, "&para;<br>");
      switch (op) {
        case DIFF_INSERT:
          html[x] = '<ins style="background:#e6ffe6;">' + text + "</ins>";
          break;
        case DIFF_DELETE:
          html[x] = '<del style="background:#ffe6e6;">' + text + "</del>";
          break;
        case DIFF_EQUAL:
          html[x] = "<span>" + text + "</span>";
          break;
      }
    }
    return html.join("");
  };
  diff_match_patch.prototype.diff_text1 = function(diffs) {
    var text = [];
    for (var x = 0; x < diffs.length; x++) {
      if (diffs[x][0] !== DIFF_INSERT) {
        text[x] = diffs[x][1];
      }
    }
    return text.join("");
  };
  diff_match_patch.prototype.diff_text2 = function(diffs) {
    var text = [];
    for (var x = 0; x < diffs.length; x++) {
      if (diffs[x][0] !== DIFF_DELETE) {
        text[x] = diffs[x][1];
      }
    }
    return text.join("");
  };
  diff_match_patch.prototype.diff_levenshtein = function(diffs) {
    var levenshtein = 0;
    var insertions = 0;
    var deletions = 0;
    for (var x = 0; x < diffs.length; x++) {
      var op = diffs[x][0];
      var data = diffs[x][1];
      switch (op) {
        case DIFF_INSERT:
          insertions += data.length;
          break;
        case DIFF_DELETE:
          deletions += data.length;
          break;
        case DIFF_EQUAL:
          levenshtein += Math.max(insertions, deletions);
          insertions = 0;
          deletions = 0;
          break;
      }
    }
    levenshtein += Math.max(insertions, deletions);
    return levenshtein;
  };
  diff_match_patch.prototype.diff_toDelta = function(diffs) {
    var text = [];
    for (var x = 0; x < diffs.length; x++) {
      switch (diffs[x][0]) {
        case DIFF_INSERT:
          text[x] = "+" + encodeURI(diffs[x][1]);
          break;
        case DIFF_DELETE:
          text[x] = "-" + diffs[x][1].length;
          break;
        case DIFF_EQUAL:
          text[x] = "=" + diffs[x][1].length;
          break;
      }
    }
    return text.join("	").replace(/%20/g, " ");
  };
  diff_match_patch.prototype.diff_fromDelta = function(text1, delta) {
    var diffs = [];
    var diffsLength = 0;
    var pointer = 0;
    var tokens = delta.split(/\t/g);
    for (var x = 0; x < tokens.length; x++) {
      var param = tokens[x].substring(1);
      switch (tokens[x].charAt(0)) {
        case "+":
          try {
            diffs[diffsLength++] = new diff_match_patch.Diff(DIFF_INSERT, decodeURI(param));
          } catch (ex) {
            throw new Error("Illegal escape in diff_fromDelta: " + param);
          }
          break;
        case "-":
        case "=":
          var n = parseInt(param, 10);
          if (isNaN(n) || n < 0) {
            throw new Error("Invalid number in diff_fromDelta: " + param);
          }
          var text = text1.substring(pointer, pointer += n);
          if (tokens[x].charAt(0) == "=") {
            diffs[diffsLength++] = new diff_match_patch.Diff(DIFF_EQUAL, text);
          } else {
            diffs[diffsLength++] = new diff_match_patch.Diff(DIFF_DELETE, text);
          }
          break;
        default:
          if (tokens[x]) {
            throw new Error("Invalid diff operation in diff_fromDelta: " + tokens[x]);
          }
      }
    }
    if (pointer != text1.length) {
      throw new Error("Delta length (" + pointer + ") does not equal source text length (" + text1.length + ").");
    }
    return diffs;
  };
  diff_match_patch.prototype.match_main = function(text, pattern, loc) {
    if (text == null || pattern == null || loc == null) {
      throw new Error("Null input. (match_main)");
    }
    loc = Math.max(0, Math.min(loc, text.length));
    if (text == pattern) {
      return 0;
    } else if (!text.length) {
      return -1;
    } else if (text.substring(loc, loc + pattern.length) == pattern) {
      return loc;
    } else {
      return this.match_bitap_(text, pattern, loc);
    }
  };
  diff_match_patch.prototype.match_bitap_ = function(text, pattern, loc) {
    if (pattern.length > this.Match_MaxBits) {
      throw new Error("Pattern too long for this browser.");
    }
    var s = this.match_alphabet_(pattern);
    var dmp = this;
    function match_bitapScore_(e, x) {
      var accuracy = e / pattern.length;
      var proximity = Math.abs(loc - x);
      if (!dmp.Match_Distance) {
        return proximity ? 1 : accuracy;
      }
      return accuracy + proximity / dmp.Match_Distance;
    }
    var score_threshold = this.Match_Threshold;
    var best_loc = text.indexOf(pattern, loc);
    if (best_loc != -1) {
      score_threshold = Math.min(match_bitapScore_(0, best_loc), score_threshold);
      best_loc = text.lastIndexOf(pattern, loc + pattern.length);
      if (best_loc != -1) {
        score_threshold = Math.min(match_bitapScore_(0, best_loc), score_threshold);
      }
    }
    var matchmask = 1 << pattern.length - 1;
    best_loc = -1;
    var bin_min, bin_mid;
    var bin_max = pattern.length + text.length;
    var last_rd;
    for (var d = 0; d < pattern.length; d++) {
      bin_min = 0;
      bin_mid = bin_max;
      while (bin_min < bin_mid) {
        if (match_bitapScore_(d, loc + bin_mid) <= score_threshold) {
          bin_min = bin_mid;
        } else {
          bin_max = bin_mid;
        }
        bin_mid = Math.floor((bin_max - bin_min) / 2 + bin_min);
      }
      bin_max = bin_mid;
      var start = Math.max(1, loc - bin_mid + 1);
      var finish = Math.min(loc + bin_mid, text.length) + pattern.length;
      var rd = Array(finish + 2);
      rd[finish + 1] = (1 << d) - 1;
      for (var j = finish; j >= start; j--) {
        var charMatch = s[text.charAt(j - 1)];
        if (d === 0) {
          rd[j] = (rd[j + 1] << 1 | 1) & charMatch;
        } else {
          rd[j] = (rd[j + 1] << 1 | 1) & charMatch | ((last_rd[j + 1] | last_rd[j]) << 1 | 1) | last_rd[j + 1];
        }
        if (rd[j] & matchmask) {
          var score = match_bitapScore_(d, j - 1);
          if (score <= score_threshold) {
            score_threshold = score;
            best_loc = j - 1;
            if (best_loc > loc) {
              start = Math.max(1, 2 * loc - best_loc);
            } else {
              break;
            }
          }
        }
      }
      if (match_bitapScore_(d + 1, loc) > score_threshold) {
        break;
      }
      last_rd = rd;
    }
    return best_loc;
  };
  diff_match_patch.prototype.match_alphabet_ = function(pattern) {
    var s = {};
    for (var i = 0; i < pattern.length; i++) {
      s[pattern.charAt(i)] = 0;
    }
    for (var i = 0; i < pattern.length; i++) {
      s[pattern.charAt(i)] |= 1 << pattern.length - i - 1;
    }
    return s;
  };
  diff_match_patch.prototype.patch_addContext_ = function(patch, text) {
    if (text.length == 0) {
      return;
    }
    if (patch.start2 === null) {
      throw Error("patch not initialized");
    }
    var pattern = text.substring(patch.start2, patch.start2 + patch.length1);
    var padding = 0;
    while (text.indexOf(pattern) != text.lastIndexOf(pattern) && pattern.length < this.Match_MaxBits - this.Patch_Margin - this.Patch_Margin) {
      padding += this.Patch_Margin;
      pattern = text.substring(
        patch.start2 - padding,
        patch.start2 + patch.length1 + padding
      );
    }
    padding += this.Patch_Margin;
    var prefix = text.substring(patch.start2 - padding, patch.start2);
    if (prefix) {
      patch.diffs.unshift(new diff_match_patch.Diff(DIFF_EQUAL, prefix));
    }
    var suffix = text.substring(
      patch.start2 + patch.length1,
      patch.start2 + patch.length1 + padding
    );
    if (suffix) {
      patch.diffs.push(new diff_match_patch.Diff(DIFF_EQUAL, suffix));
    }
    patch.start1 -= prefix.length;
    patch.start2 -= prefix.length;
    patch.length1 += prefix.length + suffix.length;
    patch.length2 += prefix.length + suffix.length;
  };
  diff_match_patch.prototype.patch_make = function(a, opt_b, opt_c) {
    var text1, diffs;
    if (typeof a == "string" && typeof opt_b == "string" && typeof opt_c == "undefined") {
      text1 = /** @type {string} */
      a;
      diffs = this.diff_main(
        text1,
        /** @type {string} */
        opt_b,
        true
      );
      if (diffs.length > 2) {
        this.diff_cleanupSemantic(diffs);
        this.diff_cleanupEfficiency(diffs);
      }
    } else if (a && typeof a == "object" && typeof opt_b == "undefined" && typeof opt_c == "undefined") {
      diffs = /** @type {!Array.<!diff_match_patch.Diff>} */
      a;
      text1 = this.diff_text1(diffs);
    } else if (typeof a == "string" && opt_b && typeof opt_b == "object" && typeof opt_c == "undefined") {
      text1 = /** @type {string} */
      a;
      diffs = /** @type {!Array.<!diff_match_patch.Diff>} */
      opt_b;
    } else if (typeof a == "string" && typeof opt_b == "string" && opt_c && typeof opt_c == "object") {
      text1 = /** @type {string} */
      a;
      diffs = /** @type {!Array.<!diff_match_patch.Diff>} */
      opt_c;
    } else {
      throw new Error("Unknown call format to patch_make.");
    }
    if (diffs.length === 0) {
      return [];
    }
    var patches = [];
    var patch = new diff_match_patch.patch_obj();
    var patchDiffLength = 0;
    var char_count1 = 0;
    var char_count2 = 0;
    var prepatch_text = text1;
    var postpatch_text = text1;
    for (var x = 0; x < diffs.length; x++) {
      var diff_type = diffs[x][0];
      var diff_text = diffs[x][1];
      if (!patchDiffLength && diff_type !== DIFF_EQUAL) {
        patch.start1 = char_count1;
        patch.start2 = char_count2;
      }
      switch (diff_type) {
        case DIFF_INSERT:
          patch.diffs[patchDiffLength++] = diffs[x];
          patch.length2 += diff_text.length;
          postpatch_text = postpatch_text.substring(0, char_count2) + diff_text + postpatch_text.substring(char_count2);
          break;
        case DIFF_DELETE:
          patch.length1 += diff_text.length;
          patch.diffs[patchDiffLength++] = diffs[x];
          postpatch_text = postpatch_text.substring(0, char_count2) + postpatch_text.substring(char_count2 + diff_text.length);
          break;
        case DIFF_EQUAL:
          if (diff_text.length <= 2 * this.Patch_Margin && patchDiffLength && diffs.length != x + 1) {
            patch.diffs[patchDiffLength++] = diffs[x];
            patch.length1 += diff_text.length;
            patch.length2 += diff_text.length;
          } else if (diff_text.length >= 2 * this.Patch_Margin) {
            if (patchDiffLength) {
              this.patch_addContext_(patch, prepatch_text);
              patches.push(patch);
              patch = new diff_match_patch.patch_obj();
              patchDiffLength = 0;
              prepatch_text = postpatch_text;
              char_count1 = char_count2;
            }
          }
          break;
      }
      if (diff_type !== DIFF_INSERT) {
        char_count1 += diff_text.length;
      }
      if (diff_type !== DIFF_DELETE) {
        char_count2 += diff_text.length;
      }
    }
    if (patchDiffLength) {
      this.patch_addContext_(patch, prepatch_text);
      patches.push(patch);
    }
    return patches;
  };
  diff_match_patch.prototype.patch_deepCopy = function(patches) {
    var patchesCopy = [];
    for (var x = 0; x < patches.length; x++) {
      var patch = patches[x];
      var patchCopy = new diff_match_patch.patch_obj();
      patchCopy.diffs = [];
      for (var y = 0; y < patch.diffs.length; y++) {
        patchCopy.diffs[y] = new diff_match_patch.Diff(patch.diffs[y][0], patch.diffs[y][1]);
      }
      patchCopy.start1 = patch.start1;
      patchCopy.start2 = patch.start2;
      patchCopy.length1 = patch.length1;
      patchCopy.length2 = patch.length2;
      patchesCopy[x] = patchCopy;
    }
    return patchesCopy;
  };
  diff_match_patch.prototype.patch_apply = function(patches, text) {
    if (patches.length == 0) {
      return [text, []];
    }
    patches = this.patch_deepCopy(patches);
    var nullPadding = this.patch_addPadding(patches);
    text = nullPadding + text + nullPadding;
    this.patch_splitMax(patches);
    var delta = 0;
    var results = [];
    for (var x = 0; x < patches.length; x++) {
      var expected_loc = patches[x].start2 + delta;
      var text1 = this.diff_text1(patches[x].diffs);
      var start_loc;
      var end_loc = -1;
      if (text1.length > this.Match_MaxBits) {
        start_loc = this.match_main(
          text,
          text1.substring(0, this.Match_MaxBits),
          expected_loc
        );
        if (start_loc != -1) {
          end_loc = this.match_main(
            text,
            text1.substring(text1.length - this.Match_MaxBits),
            expected_loc + text1.length - this.Match_MaxBits
          );
          if (end_loc == -1 || start_loc >= end_loc) {
            start_loc = -1;
          }
        }
      } else {
        start_loc = this.match_main(text, text1, expected_loc);
      }
      if (start_loc == -1) {
        results[x] = false;
        delta -= patches[x].length2 - patches[x].length1;
      } else {
        results[x] = true;
        delta = start_loc - expected_loc;
        var text2;
        if (end_loc == -1) {
          text2 = text.substring(start_loc, start_loc + text1.length);
        } else {
          text2 = text.substring(start_loc, end_loc + this.Match_MaxBits);
        }
        if (text1 == text2) {
          text = text.substring(0, start_loc) + this.diff_text2(patches[x].diffs) + text.substring(start_loc + text1.length);
        } else {
          var diffs = this.diff_main(text1, text2, false);
          if (text1.length > this.Match_MaxBits && this.diff_levenshtein(diffs) / text1.length > this.Patch_DeleteThreshold) {
            results[x] = false;
          } else {
            this.diff_cleanupSemanticLossless(diffs);
            var index1 = 0;
            var index2;
            for (var y = 0; y < patches[x].diffs.length; y++) {
              var mod = patches[x].diffs[y];
              if (mod[0] !== DIFF_EQUAL) {
                index2 = this.diff_xIndex(diffs, index1);
              }
              if (mod[0] === DIFF_INSERT) {
                text = text.substring(0, start_loc + index2) + mod[1] + text.substring(start_loc + index2);
              } else if (mod[0] === DIFF_DELETE) {
                text = text.substring(0, start_loc + index2) + text.substring(start_loc + this.diff_xIndex(
                  diffs,
                  index1 + mod[1].length
                ));
              }
              if (mod[0] !== DIFF_DELETE) {
                index1 += mod[1].length;
              }
            }
          }
        }
      }
    }
    text = text.substring(nullPadding.length, text.length - nullPadding.length);
    return [text, results];
  };
  diff_match_patch.prototype.patch_addPadding = function(patches) {
    var paddingLength = this.Patch_Margin;
    var nullPadding = "";
    for (var x = 1; x <= paddingLength; x++) {
      nullPadding += String.fromCharCode(x);
    }
    for (var x = 0; x < patches.length; x++) {
      patches[x].start1 += paddingLength;
      patches[x].start2 += paddingLength;
    }
    var patch = patches[0];
    var diffs = patch.diffs;
    if (diffs.length == 0 || diffs[0][0] != DIFF_EQUAL) {
      diffs.unshift(new diff_match_patch.Diff(DIFF_EQUAL, nullPadding));
      patch.start1 -= paddingLength;
      patch.start2 -= paddingLength;
      patch.length1 += paddingLength;
      patch.length2 += paddingLength;
    } else if (paddingLength > diffs[0][1].length) {
      var extraLength = paddingLength - diffs[0][1].length;
      diffs[0][1] = nullPadding.substring(diffs[0][1].length) + diffs[0][1];
      patch.start1 -= extraLength;
      patch.start2 -= extraLength;
      patch.length1 += extraLength;
      patch.length2 += extraLength;
    }
    patch = patches[patches.length - 1];
    diffs = patch.diffs;
    if (diffs.length == 0 || diffs[diffs.length - 1][0] != DIFF_EQUAL) {
      diffs.push(new diff_match_patch.Diff(DIFF_EQUAL, nullPadding));
      patch.length1 += paddingLength;
      patch.length2 += paddingLength;
    } else if (paddingLength > diffs[diffs.length - 1][1].length) {
      var extraLength = paddingLength - diffs[diffs.length - 1][1].length;
      diffs[diffs.length - 1][1] += nullPadding.substring(0, extraLength);
      patch.length1 += extraLength;
      patch.length2 += extraLength;
    }
    return nullPadding;
  };
  diff_match_patch.prototype.patch_splitMax = function(patches) {
    var patch_size = this.Match_MaxBits;
    for (var x = 0; x < patches.length; x++) {
      if (patches[x].length1 <= patch_size) {
        continue;
      }
      var bigpatch = patches[x];
      patches.splice(x--, 1);
      var start1 = bigpatch.start1;
      var start2 = bigpatch.start2;
      var precontext = "";
      while (bigpatch.diffs.length !== 0) {
        var patch = new diff_match_patch.patch_obj();
        var empty = true;
        patch.start1 = start1 - precontext.length;
        patch.start2 = start2 - precontext.length;
        if (precontext !== "") {
          patch.length1 = patch.length2 = precontext.length;
          patch.diffs.push(new diff_match_patch.Diff(DIFF_EQUAL, precontext));
        }
        while (bigpatch.diffs.length !== 0 && patch.length1 < patch_size - this.Patch_Margin) {
          var diff_type = bigpatch.diffs[0][0];
          var diff_text = bigpatch.diffs[0][1];
          if (diff_type === DIFF_INSERT) {
            patch.length2 += diff_text.length;
            start2 += diff_text.length;
            patch.diffs.push(bigpatch.diffs.shift());
            empty = false;
          } else if (diff_type === DIFF_DELETE && patch.diffs.length == 1 && patch.diffs[0][0] == DIFF_EQUAL && diff_text.length > 2 * patch_size) {
            patch.length1 += diff_text.length;
            start1 += diff_text.length;
            empty = false;
            patch.diffs.push(new diff_match_patch.Diff(diff_type, diff_text));
            bigpatch.diffs.shift();
          } else {
            diff_text = diff_text.substring(
              0,
              patch_size - patch.length1 - this.Patch_Margin
            );
            patch.length1 += diff_text.length;
            start1 += diff_text.length;
            if (diff_type === DIFF_EQUAL) {
              patch.length2 += diff_text.length;
              start2 += diff_text.length;
            } else {
              empty = false;
            }
            patch.diffs.push(new diff_match_patch.Diff(diff_type, diff_text));
            if (diff_text == bigpatch.diffs[0][1]) {
              bigpatch.diffs.shift();
            } else {
              bigpatch.diffs[0][1] = bigpatch.diffs[0][1].substring(diff_text.length);
            }
          }
        }
        precontext = this.diff_text2(patch.diffs);
        precontext = precontext.substring(precontext.length - this.Patch_Margin);
        var postcontext = this.diff_text1(bigpatch.diffs).substring(0, this.Patch_Margin);
        if (postcontext !== "") {
          patch.length1 += postcontext.length;
          patch.length2 += postcontext.length;
          if (patch.diffs.length !== 0 && patch.diffs[patch.diffs.length - 1][0] === DIFF_EQUAL) {
            patch.diffs[patch.diffs.length - 1][1] += postcontext;
          } else {
            patch.diffs.push(new diff_match_patch.Diff(DIFF_EQUAL, postcontext));
          }
        }
        if (!empty) {
          patches.splice(++x, 0, patch);
        }
      }
    }
  };
  diff_match_patch.prototype.patch_toText = function(patches) {
    var text = [];
    for (var x = 0; x < patches.length; x++) {
      text[x] = patches[x];
    }
    return text.join("");
  };
  diff_match_patch.prototype.patch_fromText = function(textline) {
    var patches = [];
    if (!textline) {
      return patches;
    }
    var text = textline.split("\n");
    var textPointer = 0;
    var patchHeader = /^@@ -(\d+),?(\d*) \+(\d+),?(\d*) @@$/;
    while (textPointer < text.length) {
      var m = text[textPointer].match(patchHeader);
      if (!m) {
        throw new Error("Invalid patch string: " + text[textPointer]);
      }
      var patch = new diff_match_patch.patch_obj();
      patches.push(patch);
      patch.start1 = parseInt(m[1], 10);
      if (m[2] === "") {
        patch.start1--;
        patch.length1 = 1;
      } else if (m[2] == "0") {
        patch.length1 = 0;
      } else {
        patch.start1--;
        patch.length1 = parseInt(m[2], 10);
      }
      patch.start2 = parseInt(m[3], 10);
      if (m[4] === "") {
        patch.start2--;
        patch.length2 = 1;
      } else if (m[4] == "0") {
        patch.length2 = 0;
      } else {
        patch.start2--;
        patch.length2 = parseInt(m[4], 10);
      }
      textPointer++;
      while (textPointer < text.length) {
        var sign = text[textPointer].charAt(0);
        try {
          var line = decodeURI(text[textPointer].substring(1));
        } catch (ex) {
          throw new Error("Illegal escape in patch_fromText: " + line);
        }
        if (sign == "-") {
          patch.diffs.push(new diff_match_patch.Diff(DIFF_DELETE, line));
        } else if (sign == "+") {
          patch.diffs.push(new diff_match_patch.Diff(DIFF_INSERT, line));
        } else if (sign == " ") {
          patch.diffs.push(new diff_match_patch.Diff(DIFF_EQUAL, line));
        } else if (sign == "@") {
          break;
        } else if (sign === "") ;
        else {
          throw new Error('Invalid patch mode "' + sign + '" in: ' + line);
        }
        textPointer++;
      }
    }
    return patches;
  };
  diff_match_patch.patch_obj = function() {
    this.diffs = [];
    this.start1 = null;
    this.start2 = null;
    this.length1 = 0;
    this.length2 = 0;
  };
  diff_match_patch.patch_obj.prototype.toString = function() {
    var coords1, coords2;
    if (this.length1 === 0) {
      coords1 = this.start1 + ",0";
    } else if (this.length1 == 1) {
      coords1 = this.start1 + 1;
    } else {
      coords1 = this.start1 + 1 + "," + this.length1;
    }
    if (this.length2 === 0) {
      coords2 = this.start2 + ",0";
    } else if (this.length2 == 1) {
      coords2 = this.start2 + 1;
    } else {
      coords2 = this.start2 + 1 + "," + this.length2;
    }
    var text = ["@@ -" + coords1 + " +" + coords2 + " @@\n"];
    var op;
    for (var x = 0; x < this.diffs.length; x++) {
      switch (this.diffs[x][0]) {
        case DIFF_INSERT:
          op = "+";
          break;
        case DIFF_DELETE:
          op = "-";
          break;
        case DIFF_EQUAL:
          op = " ";
          break;
      }
      text[x + 1] = op + encodeURI(this.diffs[x][1]) + "\n";
    }
    return text.join("").replace(/%20/g, " ");
  };
  module.exports = diff_match_patch;
  module.exports["diff_match_patch"] = diff_match_patch;
  module.exports["DIFF_DELETE"] = DIFF_DELETE;
  module.exports["DIFF_INSERT"] = DIFF_INSERT;
  module.exports["DIFF_EQUAL"] = DIFF_EQUAL;
})(diffMatchPatch);
var diffMatchPatchExports = diffMatchPatch.exports;
var lib$2 = {};
var domNodeIterator = { exports: {} };
var lib$1 = {};
var polyfill$1 = {};
var adapter = {};
(function(exports) {
  exports.__esModule = true;
  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }
  exports["default"] = createNodeIterator;
  function createNodeIterator(root) {
    var whatToShow = arguments.length <= 1 || arguments[1] === void 0 ? 4294967295 : arguments[1];
    var filter = arguments.length <= 2 || arguments[2] === void 0 ? null : arguments[2];
    var doc = root.nodeType == 9 || root.ownerDocument;
    var iter = doc.createNodeIterator(root, whatToShow, filter, false);
    return new NodeIterator(iter, root, whatToShow, filter);
  }
  var NodeIterator = function() {
    function NodeIterator2(iter, root, whatToShow, filter) {
      _classCallCheck(this, NodeIterator2);
      this.root = root;
      this.whatToShow = whatToShow;
      this.filter = filter;
      this.referenceNode = root;
      this.pointerBeforeReferenceNode = true;
      this._iter = iter;
    }
    NodeIterator2.prototype.nextNode = function nextNode2() {
      var result = this._iter.nextNode();
      this.pointerBeforeReferenceNode = false;
      if (result === null) return null;
      this.referenceNode = result;
      return this.referenceNode;
    };
    NodeIterator2.prototype.previousNode = function previousNode() {
      var result = this._iter.previousNode();
      this.pointerBeforeReferenceNode = true;
      if (result === null) return null;
      this.referenceNode = result;
      return this.referenceNode;
    };
    NodeIterator2.prototype.toString = function toString() {
      return "[object NodeIterator]";
    };
    return NodeIterator2;
  }();
})(adapter);
var builtin = {};
(function(exports) {
  exports.__esModule = true;
  exports["default"] = createNodeIterator;
  function createNodeIterator(root) {
    var whatToShow = arguments.length <= 1 || arguments[1] === void 0 ? 4294967295 : arguments[1];
    var filter = arguments.length <= 2 || arguments[2] === void 0 ? null : arguments[2];
    var doc = root.ownerDocument;
    return doc.createNodeIterator.call(doc, root, whatToShow, filter);
  }
})(builtin);
var implementation$1 = {};
(function(exports) {
  exports.__esModule = true;
  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }
  exports["default"] = createNodeIterator;
  function createNodeIterator(root) {
    var whatToShow = arguments.length <= 1 || arguments[1] === void 0 ? 4294967295 : arguments[1];
    var filter = arguments.length <= 2 || arguments[2] === void 0 ? null : arguments[2];
    return new NodeIterator(root, whatToShow, filter);
  }
  var NodeIterator = function() {
    function NodeIterator2(root, whatToShow, filter) {
      _classCallCheck(this, NodeIterator2);
      this.root = root;
      this.whatToShow = whatToShow;
      this.filter = filter;
      this.referenceNode = root;
      this.pointerBeforeReferenceNode = true;
      this._filter = function(node) {
        return filter ? filter(node) === 1 : true;
      };
      this._show = function(node) {
        return whatToShow >> node.nodeType - 1 & true;
      };
    }
    NodeIterator2.prototype.nextNode = function nextNode2() {
      var before = this.pointerBeforeReferenceNode;
      this.pointerBeforeReferenceNode = false;
      var node = this.referenceNode;
      if (before && this._show(node) && this._filter(node)) return node;
      do {
        if (node.firstChild) {
          node = node.firstChild;
          continue;
        }
        do {
          if (node === this.root) return null;
          if (node.nextSibling) break;
          node = node.parentNode;
        } while (node);
        node = node.nextSibling;
      } while (!this._show(node) || !this._filter(node));
      this.referenceNode = node;
      this.pointerBeforeReferenceNode = false;
      return node;
    };
    NodeIterator2.prototype.previousNode = function previousNode() {
      var before = this.pointerBeforeReferenceNode;
      this.pointerBeforeReferenceNode = true;
      var node = this.referenceNode;
      if (!before && this._show(node) && this._filter(node)) return node;
      do {
        if (node === this.root) return null;
        if (node.previousSibling) {
          node = node.previousSibling;
          while (node.lastChild) {
            node = node.lastChild;
          }
          continue;
        }
        node = node.parentNode;
      } while (!this._show(node) || !this._filter(node));
      this.referenceNode = node;
      this.pointerBeforeReferenceNode = true;
      return node;
    };
    NodeIterator2.prototype.toString = function toString() {
      return "[object NodeIterator]";
    };
    return NodeIterator2;
  }();
})(implementation$1);
(function(exports) {
  exports.__esModule = true;
  exports["default"] = getPolyfill;
  var _adapter = adapter;
  var _adapter2 = _interopRequireDefault2(_adapter);
  var _builtin = builtin;
  var _builtin2 = _interopRequireDefault2(_builtin);
  var _implementation = implementation$1;
  var _implementation2 = _interopRequireDefault2(_implementation);
  function _interopRequireDefault2(obj) {
    return obj && obj.__esModule ? obj : { "default": obj };
  }
  function getPolyfill() {
    try {
      var doc = typeof document === "undefined" ? {} : document;
      var iter = (0, _builtin2["default"])(doc, 4294967295, null, false);
      if (iter.referenceNode === doc) return _builtin2["default"];
      return _adapter2["default"];
    } catch (_) {
      return _implementation2["default"];
    }
  }
})(polyfill$1);
var shim$1 = {};
(function(exports) {
  exports.__esModule = true;
  exports["default"] = shim2;
  var _builtin = builtin;
  var _builtin2 = _interopRequireDefault2(_builtin);
  var _polyfill = polyfill$1;
  var _polyfill2 = _interopRequireDefault2(_polyfill);
  function _interopRequireDefault2(obj) {
    return obj && obj.__esModule ? obj : { "default": obj };
  }
  function shim2() {
    var doc = typeof document === "undefined" ? {} : document;
    var polyfill2 = (0, _polyfill2["default"])();
    if (polyfill2 !== _builtin2["default"]) doc.createNodeIterator = polyfill2;
    return polyfill2;
  }
})(shim$1);
(function(exports) {
  exports.__esModule = true;
  var _polyfill = polyfill$1;
  var _polyfill2 = _interopRequireDefault2(_polyfill);
  var _implementation = implementation$1;
  var _implementation2 = _interopRequireDefault2(_implementation);
  var _shim = shim$1;
  var _shim2 = _interopRequireDefault2(_shim);
  function _interopRequireDefault2(obj) {
    return obj && obj.__esModule ? obj : { "default": obj };
  }
  var polyfill2 = (0, _polyfill2["default"])();
  polyfill2.implementation = _implementation2["default"];
  polyfill2.shim = _shim2["default"];
  exports["default"] = polyfill2;
})(lib$1);
var polyfill = polyfill$1["default"];
var implementation = implementation$1["default"];
var shim = shim$1["default"];
domNodeIterator.exports = lib$1["default"];
domNodeIterator.exports.getPolyfill = polyfill;
domNodeIterator.exports.implementation = implementation;
domNodeIterator.exports.shim = shim;
var domNodeIteratorExports = domNodeIterator.exports;
var lib = {};
var ancestors = parents;
function parents(node, filter) {
  var out = [];
  filter = filter || noop;
  do {
    out.push(node);
    node = node.parentNode;
  } while (node && node.tagName && filter(node));
  return out.slice(1);
}
function noop(n) {
  return true;
}
/*!
 * index-of <https://github.com/jonschlinkert/index-of>
 *
 * Copyright (c) 2014-2015 Jon Schlinkert.
 * Licensed under the MIT license.
 */
var indexOf = function indexOf2(arr, ele, start) {
  start = start || 0;
  var idx = -1;
  if (arr == null) return idx;
  var len = arr.length;
  var i = start < 0 ? len + start : start;
  if (i >= arr.length) {
    return -1;
  }
  while (i < len) {
    if (arr[i] === ele) {
      return i;
    }
    i++;
  }
  return -1;
};
(function(exports) {
  exports.__esModule = true;
  exports["default"] = seek;
  var _ancestors = ancestors;
  var _ancestors2 = _interopRequireDefault2(_ancestors);
  var _indexOf = indexOf;
  var _indexOf2 = _interopRequireDefault2(_indexOf);
  function _interopRequireDefault2(obj) {
    return obj && obj.__esModule ? obj : { "default": obj };
  }
  var E_SHOW = "Argument 1 of seek must use filter NodeFilter.SHOW_TEXT.";
  var E_WHERE = "Argument 2 of seek must be a number or a Text Node.";
  var SHOW_TEXT2 = 4;
  var TEXT_NODE = 3;
  function seek(iter, where) {
    if (iter.whatToShow !== SHOW_TEXT2) {
      throw new Error(E_SHOW);
    }
    var count = 0;
    var node = iter.referenceNode;
    var predicates = null;
    if (isNumber(where)) {
      predicates = {
        forward: function forward2() {
          return count < where;
        },
        backward: function backward2() {
          return count > where;
        }
      };
    } else if (isText(where)) {
      var forward = before(node, where) ? function() {
        return false;
      } : function() {
        return node !== where;
      };
      var backward = function backward2() {
        return node != where || !iter.pointerBeforeReferenceNode;
      };
      predicates = { forward, backward };
    } else {
      throw new Error(E_WHERE);
    }
    while (predicates.forward() && (node = iter.nextNode()) !== null) {
      count += node.nodeValue.length;
    }
    while (predicates.backward() && (node = iter.previousNode()) !== null) {
      count -= node.nodeValue.length;
    }
    return count;
  }
  function isNumber(n) {
    return !isNaN(parseInt(n)) && isFinite(n);
  }
  function isText(node) {
    return node.nodeType === TEXT_NODE;
  }
  function before(ref, node) {
    if (ref === node) return false;
    var common = null;
    var left = [ref].concat((0, _ancestors2["default"])(ref)).reverse();
    var right = [node].concat((0, _ancestors2["default"])(node)).reverse();
    while (left[0] === right[0]) {
      common = left.shift();
      right.shift();
    }
    left = left[0];
    right = right[0];
    var l = (0, _indexOf2["default"])(common.childNodes, left);
    var r = (0, _indexOf2["default"])(common.childNodes, right);
    return l > r;
  }
})(lib);
var domSeek = lib["default"];
var rangeToString$1 = {};
Object.defineProperty(rangeToString$1, "__esModule", {
  value: true
});
rangeToString$1.default = rangeToString;
function nextNode(node, skipChildren) {
  if (!skipChildren && node.firstChild) {
    return node.firstChild;
  }
  do {
    if (node.nextSibling) {
      return node.nextSibling;
    }
    node = node.parentNode;
  } while (node);
  return node;
}
function firstNode(range) {
  if (range.startContainer.nodeType === Node.ELEMENT_NODE) {
    var node = range.startContainer.childNodes[range.startOffset];
    return node || nextNode(
      range.startContainer,
      true
      /* skip children */
    );
  }
  return range.startContainer;
}
function firstNodeAfter(range) {
  if (range.endContainer.nodeType === Node.ELEMENT_NODE) {
    var node = range.endContainer.childNodes[range.endOffset];
    return node || nextNode(
      range.endContainer,
      true
      /* skip children */
    );
  }
  return nextNode(range.endContainer);
}
function forEachNodeInRange(range, cb) {
  var node = firstNode(range);
  var pastEnd = firstNodeAfter(range);
  while (node !== pastEnd) {
    cb(node);
    node = nextNode(node);
  }
}
function rangeToString(range) {
  var text = "";
  forEachNodeInRange(range, function(node) {
    if (node.nodeType !== Node.TEXT_NODE) {
      return;
    }
    var start = node === range.startContainer ? range.startOffset : 0;
    var end = node === range.endContainer ? range.endOffset : node.textContent.length;
    text += node.textContent.slice(start, end);
  });
  return text;
}
Object.defineProperty(lib$2, "__esModule", {
  value: true
});
lib$2.fromRange = fromRange$1;
lib$2.toRange = toRange$1;
var _domNodeIterator = domNodeIteratorExports;
var _domNodeIterator2 = _interopRequireDefault$1(_domNodeIterator);
var _domSeek = domSeek;
var _domSeek2 = _interopRequireDefault$1(_domSeek);
var _rangeToString = rangeToString$1;
var _rangeToString2 = _interopRequireDefault$1(_rangeToString);
function _interopRequireDefault$1(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
var SHOW_TEXT = 4;
function fromRange$1(root, range) {
  if (root === void 0) {
    throw new Error('missing required parameter "root"');
  }
  if (range === void 0) {
    throw new Error('missing required parameter "range"');
  }
  var document2 = root.ownerDocument;
  var prefix = document2.createRange();
  var startNode = range.startContainer;
  var startOffset = range.startOffset;
  prefix.setStart(root, 0);
  prefix.setEnd(startNode, startOffset);
  var start = (0, _rangeToString2.default)(prefix).length;
  var end = start + (0, _rangeToString2.default)(range).length;
  return {
    start,
    end
  };
}
function toRange$1(root) {
  var selector = arguments.length <= 1 || arguments[1] === void 0 ? {} : arguments[1];
  if (root === void 0) {
    throw new Error('missing required parameter "root"');
  }
  var document2 = root.ownerDocument;
  var range = document2.createRange();
  var iter = (0, _domNodeIterator2.default)(root, SHOW_TEXT);
  var start = selector.start || 0;
  var end = selector.end || start;
  var count = (0, _domSeek2.default)(iter, start);
  var remainder = start - count;
  if (iter.pointerBeforeReferenceNode) {
    range.setStart(iter.referenceNode, remainder);
  } else {
    range.setStart(iter.nextNode(), remainder);
    iter.previousNode();
  }
  var length = end - start + remainder;
  count = (0, _domSeek2.default)(iter, length);
  remainder = length - count;
  if (iter.pointerBeforeReferenceNode) {
    range.setEnd(iter.referenceNode, remainder);
  } else {
    range.setEnd(iter.nextNode(), remainder);
  }
  return range;
}
var domAnchorTextPosition = lib$2;
Object.defineProperty(lib$3, "__esModule", {
  value: true
});
lib$3.fromRange = fromRange;
lib$3.fromTextPosition = fromTextPosition;
lib$3.toRange = toRange;
lib$3.toTextPosition = toTextPosition;
var _diffMatchPatch = diffMatchPatchExports;
var _diffMatchPatch2 = _interopRequireDefault(_diffMatchPatch);
var _domAnchorTextPosition = domAnchorTextPosition;
var textPosition = _interopRequireWildcard(_domAnchorTextPosition);
function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  } else {
    var newObj = {};
    if (obj != null) {
      for (var key in obj) {
        if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key];
      }
    }
    newObj.default = obj;
    return newObj;
  }
}
function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : { default: obj };
}
var SLICE_LENGTH = 32;
var SLICE_RE = new RegExp("(.|[\r\n]){1," + String(SLICE_LENGTH) + "}", "g");
var CONTEXT_LENGTH = SLICE_LENGTH;
function fromRange(root, range) {
  if (root === void 0) {
    throw new Error('missing required parameter "root"');
  }
  if (range === void 0) {
    throw new Error('missing required parameter "range"');
  }
  var position = textPosition.fromRange(root, range);
  return fromTextPosition(root, position);
}
function fromTextPosition(root, selector) {
  if (root === void 0) {
    throw new Error('missing required parameter "root"');
  }
  if (selector === void 0) {
    throw new Error('missing required parameter "selector"');
  }
  var start = selector.start;
  if (start === void 0) {
    throw new Error('selector missing required property "start"');
  }
  if (start < 0) {
    throw new Error('property "start" must be a non-negative integer');
  }
  var end = selector.end;
  if (end === void 0) {
    throw new Error('selector missing required property "end"');
  }
  if (end < 0) {
    throw new Error('property "end" must be a non-negative integer');
  }
  var exact = root.textContent.substr(start, end - start);
  var prefixStart = Math.max(0, start - CONTEXT_LENGTH);
  var prefix = root.textContent.substr(prefixStart, start - prefixStart);
  var suffixEnd = Math.min(root.textContent.length, end + CONTEXT_LENGTH);
  var suffix = root.textContent.substr(end, suffixEnd - end);
  return { exact, prefix, suffix };
}
function toRange(root, selector) {
  var options = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
  var position = toTextPosition(root, selector, options);
  if (position === null) {
    return null;
  } else {
    return textPosition.toRange(root, position);
  }
}
function toTextPosition(root, selector) {
  var options = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
  if (root === void 0) {
    throw new Error('missing required parameter "root"');
  }
  if (selector === void 0) {
    throw new Error('missing required parameter "selector"');
  }
  var exact = selector.exact;
  if (exact === void 0) {
    throw new Error('selector missing required property "exact"');
  }
  var prefix = selector.prefix, suffix = selector.suffix;
  var hint = options.hint;
  var dmp = new _diffMatchPatch2.default();
  dmp.Match_Distance = root.textContent.length * 2;
  var slices = exact.match(SLICE_RE);
  var loc = hint === void 0 ? root.textContent.length / 2 | 0 : hint;
  var start = Number.POSITIVE_INFINITY;
  var end = Number.NEGATIVE_INFINITY;
  var result = -1;
  var havePrefix = prefix !== void 0;
  var haveSuffix = suffix !== void 0;
  var foundPrefix = false;
  if (havePrefix) {
    result = dmp.match_main(root.textContent, prefix, loc);
    if (result > -1) {
      loc = result + prefix.length;
      foundPrefix = true;
    }
  }
  if (haveSuffix && !foundPrefix) {
    result = dmp.match_main(root.textContent, suffix, loc + exact.length);
    if (result > -1) {
      loc = result - exact.length;
    }
  }
  var firstSlice = slices.shift();
  result = dmp.match_main(root.textContent, firstSlice, loc);
  if (result > -1) {
    start = result;
    loc = end = start + firstSlice.length;
  } else {
    return null;
  }
  var foldSlices = function foldSlices2(acc2, slice) {
    if (!acc2) {
      return null;
    }
    var result2 = dmp.match_main(root.textContent, slice, acc2.loc);
    if (result2 === -1) {
      return null;
    }
    acc2.loc = result2 + slice.length;
    acc2.start = Math.min(acc2.start, result2);
    acc2.end = Math.max(acc2.end, result2 + slice.length);
    return acc2;
  };
  dmp.Match_Distance = 64;
  var acc = slices.reduce(foldSlices, { start, end, loc });
  if (!acc) {
    return null;
  }
  return { start: acc.start, end: acc.end };
}
var domAnchorTextQuote = lib$3;
class AnnotationManager {
  constructor() {
    __publicField(this, "annotations", []);
    __publicField(this, "highlightClass", "pubky-highlight");
    __publicField(this, "activeHighlightClass", "pubky-highlight-active");
    __publicField(this, "currentSelection", null);
    this.init();
  }
  init() {
    contentLogger.info("ContentScript", "Initializing annotation manager");
    this.injectStyles();
    document.addEventListener("mouseup", this.handleTextSelection.bind(this));
    chrome.runtime.onMessage.addListener(this.handleMessage.bind(this));
    setTimeout(() => {
      this.loadAnnotations();
    }, 500);
    this.observeUrlChanges();
    this.observeContentChanges();
    contentLogger.info("ContentScript", "Annotation manager initialized");
  }
  observeUrlChanges() {
    let lastUrl = location.href;
    const checkUrlChange = () => {
      const currentUrl = location.href;
      if (currentUrl !== lastUrl) {
        contentLogger.info("ContentScript", "URL changed, reloading annotations", {
          from: lastUrl,
          to: currentUrl
        });
        lastUrl = currentUrl;
        this.clearAllHighlights();
        setTimeout(() => {
          this.loadAnnotations();
        }, 500);
      }
    };
    window.addEventListener("popstate", checkUrlChange);
    window.addEventListener("pushstate", checkUrlChange);
    window.addEventListener("replacestate", checkUrlChange);
    const originalPushState = history.pushState;
    const originalReplaceState = history.replaceState;
    history.pushState = function(...args) {
      originalPushState.apply(history, args);
      window.dispatchEvent(new Event("pushstate"));
    };
    history.replaceState = function(...args) {
      originalReplaceState.apply(history, args);
      window.dispatchEvent(new Event("replacestate"));
    };
  }
  observeContentChanges() {
    let contentChangeTimeout = null;
    const observer = new MutationObserver(() => {
      if (contentChangeTimeout) {
        clearTimeout(contentChangeTimeout);
      }
      contentChangeTimeout = window.setTimeout(() => {
        if (this.annotations.length > 0) {
          const visibleHighlights = document.querySelectorAll(`.${this.highlightClass}`).length;
          if (visibleHighlights < this.annotations.length) {
            contentLogger.info("ContentScript", "Content changed, re-rendering missing highlights", {
              annotations: this.annotations.length,
              visible: visibleHighlights
            });
            this.annotations.forEach((annotation) => {
              this.renderHighlight(annotation);
            });
          }
        }
      }, 1e3);
    });
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
  clearAllHighlights() {
    document.querySelectorAll(`.${this.highlightClass}`).forEach((el) => {
      const parent = el.parentNode;
      if (parent) {
        while (el.firstChild) {
          parent.insertBefore(el.firstChild, el);
        }
        parent.removeChild(el);
      }
    });
  }
  injectStyles() {
    const style = document.createElement("style");
    style.textContent = `
      .${this.highlightClass} {
        background-color: rgba(163, 230, 53, 0.25);
        cursor: pointer;
        position: relative;
        border-bottom: 2px solid rgba(132, 204, 22, 0.6);
        transition: background-color 0.2s ease;
        box-shadow: 0 0 0 1px rgba(163, 230, 53, 0.15);
      }
      
      .${this.highlightClass}:hover {
        background-color: rgba(163, 230, 53, 0.35);
        box-shadow: 0 0 0 1px rgba(163, 230, 53, 0.25);
      }
      
      .${this.activeHighlightClass} {
        background-color: rgba(163, 230, 53, 0.5);
        box-shadow: 0 0 0 2px rgba(132, 204, 22, 0.8);
      }
      
      .pubky-annotation-button {
        position: absolute;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 8px;
        padding: 10px 16px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        z-index: 10000;
        display: flex;
        align-items: center;
        gap: 8px;
        transition: box-shadow 0.2s ease, opacity 0.2s ease;
        pointer-events: auto;
      }
      
      .pubky-annotation-button:hover {
        box-shadow: 0 6px 16px rgba(102, 126, 234, 0.6);
        opacity: 0.95;
      }
      
      .pubky-annotation-button svg {
        width: 16px;
        height: 16px;
      }
      
      .pubky-annotation-modal {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: #2B2B2B;
        border: 1px solid #3F3F3F;
        border-radius: 12px;
        padding: 24px;
        width: 90%;
        max-width: 500px;
        z-index: 10001;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
      }
      
      .pubky-annotation-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.7);
        z-index: 10000;
        backdrop-filter: blur(4px);
      }
      
      .pubky-annotation-modal h3 {
        color: white;
        font-size: 18px;
        font-weight: 600;
        margin: 0 0 8px 0;
      }
      
      .pubky-annotation-modal .selected-text {
        background: #1F1F1F;
        border-left: 3px solid #667eea;
        padding: 12px;
        margin: 12px 0;
        color: #E0E0E0;
        font-style: italic;
        border-radius: 4px;
        max-height: 100px;
        overflow-y: auto;
      }
      
      .pubky-annotation-modal textarea {
        width: 100%;
        min-height: 100px;
        background: #1F1F1F;
        border: 1px solid #3F3F3F;
        border-radius: 8px;
        padding: 12px;
        color: white;
        font-size: 14px;
        font-family: inherit;
        resize: vertical;
        margin-bottom: 16px;
      }
      
      .pubky-annotation-modal textarea:focus {
        outline: none;
        border-color: #667eea;
      }
      
      .pubky-annotation-modal-buttons {
        display: flex;
        gap: 12px;
        justify-content: flex-end;
      }
      
      .pubky-annotation-modal button {
        padding: 10px 20px;
        border-radius: 8px;
        border: none;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;
      }
      
      .pubky-annotation-modal .cancel-btn {
        background: #3F3F3F;
        color: white;
      }
      
      .pubky-annotation-modal .cancel-btn:hover {
        background: #4F4F4F;
      }
      
      .pubky-annotation-modal .submit-btn {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
      }
      
      .pubky-annotation-modal .submit-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
      }
      
      .pubky-annotation-modal .submit-btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }
    `;
    document.head.appendChild(style);
  }
  handleTextSelection(event) {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed) {
      this.hideAnnotationButton();
      return;
    }
    const selectedText = selection.toString().trim();
    if (selectedText.length === 0 || selectedText.length > 1e3) {
      return;
    }
    const range = selection.getRangeAt(0);
    this.currentSelection = { range, text: selectedText };
    this.showAnnotationButton(event.pageX, event.pageY);
  }
  showAnnotationButton(x, y) {
    this.hideAnnotationButton();
    const button = document.createElement("button");
    button.className = "pubky-annotation-button";
    button.innerHTML = `
      <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z" />
      </svg>
      Add Annotation
    `;
    button.style.left = `${x - 80}px`;
    button.style.top = `${y + 10}px`;
    button.onmousedown = (e) => {
      e.stopPropagation();
      this.showAnnotationModal();
    };
    document.body.appendChild(button);
  }
  hideAnnotationButton() {
    const existing = document.querySelector(".pubky-annotation-button");
    if (existing) {
      existing.remove();
    }
  }
  showAnnotationModal() {
    if (!this.currentSelection) return;
    this.hideAnnotationButton();
    const overlay = document.createElement("div");
    overlay.className = "pubky-annotation-overlay";
    overlay.onclick = () => this.hideAnnotationModal();
    const modal = document.createElement("div");
    modal.className = "pubky-annotation-modal";
    modal.onclick = (e) => e.stopPropagation();
    modal.innerHTML = `
      <h3>Add Annotation</h3>
      <div class="selected-text">"${this.escapeHtml(this.currentSelection.text)}"</div>
      <textarea placeholder="Add your comment..." autofocus></textarea>
      <div class="pubky-annotation-modal-buttons">
        <button class="cancel-btn">Cancel</button>
        <button class="submit-btn">Post Annotation</button>
      </div>
    `;
    const textarea = modal.querySelector("textarea");
    const cancelBtn = modal.querySelector(".cancel-btn");
    const submitBtn = modal.querySelector(".submit-btn");
    cancelBtn.addEventListener("click", () => this.hideAnnotationModal());
    submitBtn.addEventListener("click", () => this.createAnnotation(textarea.value));
    document.body.appendChild(overlay);
    document.body.appendChild(modal);
    setTimeout(() => textarea.focus(), 100);
  }
  hideAnnotationModal() {
    const overlay = document.querySelector(".pubky-annotation-overlay");
    const modal = document.querySelector(".pubky-annotation-modal");
    if (overlay) overlay.remove();
    if (modal) modal.remove();
  }
  escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }
  async createAnnotation(comment) {
    if (!this.currentSelection || !comment.trim()) {
      this.hideAnnotationModal();
      return;
    }
    const submitBtn = document.querySelector(".submit-btn");
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = "Creating...";
    }
    try {
      const range = this.currentSelection.range;
      const { prefix, exact, suffix } = this.getRangePosition(range);
      const annotation = {
        id: this.generateId(),
        url: window.location.href,
        selectedText: this.currentSelection.text,
        comment: comment.trim(),
        prefix,
        exact,
        suffix,
        timestamp: Date.now(),
        author: "",
        color: "rgba(163, 230, 53, 0.25)"
      };
      this.annotations.push(annotation);
      this.renderHighlight(annotation);
      this.hideAnnotationModal();
      chrome.runtime.sendMessage(
        {
          type: "CREATE_ANNOTATION",
          annotation
        },
        (response) => {
          if (response == null ? void 0 : response.success) {
            annotation.postUri = response.postUri;
            annotation.author = response.author;
            contentLogger.info("ContentScript", "Annotation synced to Pubky", { id: annotation.id });
          } else {
            contentLogger.warn("ContentScript", "Failed to sync annotation to Pubky", response == null ? void 0 : response.error);
            console.warn("Annotation created locally but not synced to Pubky network. Make sure you are signed in.");
          }
        }
      );
    } catch (error) {
      contentLogger.error("ContentScript", "Failed to create annotation", error);
      alert("Failed to create annotation");
      this.hideAnnotationModal();
    }
    this.currentSelection = null;
  }
  getRangePosition(range) {
    try {
      const selector = domAnchorTextQuote.toTextQuote(document.body, range);
      return {
        prefix: selector.prefix || "",
        exact: selector.exact,
        suffix: selector.suffix || ""
      };
    } catch (error) {
      contentLogger.error("ContentScript", "Failed to create text quote anchor", error);
      return {
        prefix: "",
        exact: range.toString(),
        suffix: ""
      };
    }
  }
  renderHighlight(annotation) {
    var _a, _b, _c;
    try {
      contentLogger.debug("ContentScript", "Attempting to render highlight", {
        id: annotation.id,
        text: annotation.selectedText.substring(0, 30)
      });
      const existing = document.querySelector(`[data-annotation-id="${annotation.id}"]`);
      if (existing) {
        contentLogger.debug("ContentScript", "Highlight already exists", { id: annotation.id });
        return;
      }
      if (annotation.prefix !== void 0 && annotation.exact !== void 0 && annotation.suffix !== void 0) {
        try {
          let range = domAnchorTextQuote.toRange(document.body, {
            prefix: annotation.prefix,
            exact: annotation.exact,
            suffix: annotation.suffix
          });
          if (!range && annotation.exact) {
            contentLogger.debug("ContentScript", "Retrying without prefix/suffix context", { id: annotation.id });
            range = domAnchorTextQuote.toRange(document.body, {
              prefix: "",
              exact: annotation.exact,
              suffix: ""
            });
          }
          if (!range) {
            const pageText = document.body.textContent || "";
            const exactInPage = pageText.includes(annotation.exact);
            contentLogger.warn("ContentScript", "Text not found on page for annotation", {
              id: annotation.id,
              exact: (_a = annotation.exact) == null ? void 0 : _a.substring(0, 50),
              exactExistsInPageText: exactInPage,
              prefix: (_b = annotation.prefix) == null ? void 0 : _b.substring(0, 20),
              suffix: (_c = annotation.suffix) == null ? void 0 : _c.substring(0, 20)
            });
            return;
          }
          const span = document.createElement("span");
          span.className = this.highlightClass;
          span.dataset.annotationId = annotation.id;
          span.onclick = () => this.handleHighlightClick(annotation);
          try {
            range.surroundContents(span);
            contentLogger.info("ContentScript", "Highlight rendered successfully with text-quote ✓", { id: annotation.id });
            return;
          } catch (error) {
            try {
              const contents = range.extractContents();
              span.appendChild(contents);
              range.insertNode(span);
              contentLogger.info("ContentScript", "Highlight rendered with alt method ✓", { id: annotation.id });
              return;
            } catch (altError) {
              contentLogger.warn("ContentScript", "Alt highlight method also failed", { id: annotation.id });
            }
          }
        } catch (error) {
          contentLogger.warn("ContentScript", "Text-quote anchoring failed, trying legacy format", error);
        }
      }
      if (annotation.startPath && annotation.endPath && annotation.startOffset !== void 0 && annotation.endOffset !== void 0) {
        contentLogger.info("ContentScript", "Attempting legacy path-based rendering", { id: annotation.id });
        const startNode = this.getNodeByPathLegacy(annotation.startPath);
        const endNode = this.getNodeByPathLegacy(annotation.endPath);
        if (!startNode || !endNode || !document.body.contains(startNode) || !document.body.contains(endNode)) {
          contentLogger.warn("ContentScript", "Legacy format failed - nodes not found", { id: annotation.id });
          return;
        }
        const range = document.createRange();
        try {
          range.setStart(startNode, annotation.startOffset);
          range.setEnd(endNode, annotation.endOffset);
          const span = document.createElement("span");
          span.className = this.highlightClass;
          span.dataset.annotationId = annotation.id;
          span.onclick = () => this.handleHighlightClick(annotation);
          try {
            range.surroundContents(span);
            contentLogger.info("ContentScript", "Legacy highlight rendered ✓", { id: annotation.id });
            this.migrateAnnotationToTextQuote(annotation, range);
          } catch (error) {
            const contents = range.extractContents();
            span.appendChild(contents);
            range.insertNode(span);
            contentLogger.info("ContentScript", "Legacy highlight rendered with alt method ✓", { id: annotation.id });
            const newRange = document.createRange();
            newRange.selectNodeContents(span);
            this.migrateAnnotationToTextQuote(annotation, newRange);
          }
        } catch (rangeError) {
          contentLogger.error("ContentScript", "Invalid range offsets", rangeError);
        }
      } else {
        contentLogger.warn("ContentScript", "Annotation has neither new nor legacy format", { id: annotation.id });
      }
    } catch (error) {
      contentLogger.error("ContentScript", "Failed to render highlight", error);
    }
  }
  /**
   * Migrate legacy path-based annotation to text-quote format
   */
  migrateAnnotationToTextQuote(annotation, range) {
    try {
      const { prefix, exact, suffix } = this.getRangePosition(range);
      annotation.prefix = prefix;
      annotation.exact = exact;
      annotation.suffix = suffix;
      chrome.runtime.sendMessage({
        type: "CREATE_ANNOTATION",
        annotation
      });
      contentLogger.info("ContentScript", "Annotation migrated to text-quote format", { id: annotation.id });
    } catch (error) {
      contentLogger.error("ContentScript", "Failed to migrate annotation", error);
    }
  }
  /**
   * Legacy method for path-based node lookup (for migration only)
   */
  getNodeByPathLegacy(path) {
    const indices = path.split("/").map(Number);
    let current = document.body;
    for (const index of indices) {
      if (index >= current.childNodes.length) {
        return null;
      }
      current = current.childNodes[index];
    }
    return current;
  }
  handleHighlightClick(annotation) {
    contentLogger.info("ContentScript", "Highlight clicked", { id: annotation.id });
    document.querySelectorAll(`.${this.activeHighlightClass}`).forEach((el) => {
      el.classList.remove(this.activeHighlightClass);
    });
    const highlight = document.querySelector(`[data-annotation-id="${annotation.id}"]`);
    if (highlight) {
      highlight.classList.add(this.activeHighlightClass);
    }
    chrome.runtime.sendMessage({
      type: "SHOW_ANNOTATION",
      annotationId: annotation.id
    });
  }
  async loadAnnotations() {
    try {
      chrome.runtime.sendMessage(
        {
          type: "GET_ANNOTATIONS",
          url: window.location.href
        },
        (response) => {
          if (response == null ? void 0 : response.annotations) {
            this.annotations = response.annotations;
            contentLogger.info("ContentScript", "Annotations loaded", { count: this.annotations.length });
            this.annotations.forEach((annotation) => {
              this.renderHighlight(annotation);
            });
          }
        }
      );
    } catch (error) {
      contentLogger.error("ContentScript", "Failed to load annotations", error);
    }
  }
  handleMessage(message, _sender, sendResponse) {
    if (message.type === "HIGHLIGHT_ANNOTATION") {
      const annotation = this.annotations.find((a) => a.id === message.annotationId);
      if (annotation) {
        this.handleHighlightClick(annotation);
        const highlight = document.querySelector(`[data-annotation-id="${annotation.id}"]`);
        if (highlight) {
          highlight.scrollIntoView({ behavior: "smooth", block: "center" });
        }
      }
      sendResponse({ success: true });
    }
    return true;
  }
  generateId() {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}
class DrawingManager {
  constructor() {
    __publicField(this, "canvas", null);
    __publicField(this, "ctx", null);
    __publicField(this, "toolbar", null);
    __publicField(this, "isDrawing", false);
    __publicField(this, "isActive", false);
    __publicField(this, "currentColor", "#FF6B6B");
    __publicField(this, "currentThickness", 5);
    __publicField(this, "lastX", 0);
    __publicField(this, "lastY", 0);
    // Bound event handlers to prevent memory leaks
    __publicField(this, "boundStartDrawing");
    __publicField(this, "boundDraw");
    __publicField(this, "boundStopDrawing");
    __publicField(this, "COLORS", [
      "#FF6B6B",
      "#4ECDC4",
      "#45B7D1",
      "#FFA07A",
      "#98D8C8",
      "#F7DC6F",
      "#BB8FCE",
      "#FFFFFF"
    ]);
    contentLogger.info("DrawingManager", "Initializing drawing manager");
    this.boundStartDrawing = this.startDrawing.bind(this);
    this.boundDraw = this.draw.bind(this);
    this.boundStopDrawing = this.stopDrawing.bind(this);
    this.init();
  }
  init() {
    contentLogger.info("DrawingManager", "Setting up message listeners");
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      contentLogger.debug("DrawingManager", "Message received", { type: message.type });
      if (message.type === "TOGGLE_DRAWING_MODE") {
        contentLogger.info("DrawingManager", "Toggle drawing mode requested");
        this.toggleDrawing();
        sendResponse({ success: true, active: this.isActive });
        return true;
      } else if (message.type === "GET_DRAWING_STATUS") {
        sendResponse({ active: this.isActive });
        return true;
      }
      return false;
    });
    contentLogger.info("DrawingManager", "Message listeners registered");
  }
  async toggleDrawing() {
    this.isActive = !this.isActive;
    if (this.isActive) {
      contentLogger.info("DrawingManager", "Activating drawing mode");
      this.createCanvas();
      this.createToolbar();
      await this.loadDrawing();
    } else {
      contentLogger.info("DrawingManager", "Deactivating drawing mode");
      await this.saveDrawing();
      this.removeCanvas();
      this.removeToolbar();
    }
  }
  createCanvas() {
    if (this.canvas) return;
    this.canvas = document.createElement("canvas");
    this.canvas.id = "pubky-drawing-canvas";
    this.canvas.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      z-index: 999999;
      cursor: crosshair;
      pointer-events: auto;
    `;
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
    document.body.appendChild(this.canvas);
    this.ctx = this.canvas.getContext("2d");
    if (!this.ctx) {
      contentLogger.error("DrawingManager", "Failed to get canvas context");
      return;
    }
    this.ctx.strokeStyle = this.currentColor;
    this.ctx.lineWidth = this.currentThickness;
    this.ctx.lineCap = "round";
    this.canvas.addEventListener("mousedown", this.boundStartDrawing);
    this.canvas.addEventListener("mousemove", this.boundDraw);
    this.canvas.addEventListener("mouseup", this.boundStopDrawing);
    this.canvas.addEventListener("mouseleave", this.boundStopDrawing);
    contentLogger.info("DrawingManager", "Canvas created");
  }
  removeCanvas() {
    if (!this.canvas) return;
    this.canvas.removeEventListener("mousedown", this.boundStartDrawing);
    this.canvas.removeEventListener("mousemove", this.boundDraw);
    this.canvas.removeEventListener("mouseup", this.boundStopDrawing);
    this.canvas.removeEventListener("mouseleave", this.boundStopDrawing);
    this.canvas.remove();
    this.canvas = null;
    this.ctx = null;
    contentLogger.info("DrawingManager", "Canvas removed");
  }
  createToolbar() {
    if (this.toolbar) return;
    this.toolbar = document.createElement("div");
    this.toolbar.id = "pubky-drawing-toolbar";
    this.toolbar.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: rgba(17, 24, 39, 0.9);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 16px;
      padding: 16px;
      z-index: 1000000;
      width: 280px;
      color: white;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.4);
      backdrop-filter: blur(10px);
    `;
    this.toolbar.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
        <div>
          <div style="font-weight: 600; margin-bottom: 2px;">Graphiti Drawing</div>
          <div style="font-size: 12px; color: rgba(255, 255, 255, 0.6);">Alt + D to toggle</div>
        </div>
        <button id="close-drawing" style="
          background: rgba(255, 255, 255, 0.1);
          border: none;
          color: white;
          border-radius: 50%;
          width: 32px;
          height: 32px;
          cursor: pointer;
          transition: background 0.2s ease;
        ">✕</button>
      </div>
      <div style="margin-bottom: 16px;">
        <div style="font-size: 12px; margin-bottom: 8px; color: rgba(255, 255, 255, 0.8);">Colors</div>
        <div id="color-palette" style="display: flex; flex-wrap: wrap; gap: 8px;"></div>
      </div>
      <div style="margin-bottom: 16px;">
        <div style="font-size: 12px; margin-bottom: 8px; color: rgba(255, 255, 255, 0.8);">Thickness</div>
        <input type="range" id="thickness-slider" min="1" max="20" value="${this.currentThickness}" style="width: 100%;">
      </div>
      <div style="display: flex; gap: 8px;">
        <button id="clear-drawing" style="
          flex: 1;
          padding: 10px;
          background: rgba(255, 255, 255, 0.1);
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 12px;
          color: white;
          cursor: pointer;
        ">Clear</button>
        <button id="save-drawing" style="
          flex: 1;
          padding: 10px;
          background: linear-gradient(135deg, #4f46e5, #7c3aed);
          border: none;
          border-radius: 12px;
          color: white;
          cursor: pointer;
          font-weight: 600;
        ">Save</button>
      </div>
    `;
    document.body.appendChild(this.toolbar);
    const palette = this.toolbar.querySelector("#color-palette");
    if (palette) {
      this.COLORS.forEach((color) => {
        const swatch = document.createElement("button");
        swatch.style.background = color;
        swatch.style.width = "32px";
        swatch.style.height = "32px";
        swatch.style.border = color === "#FFFFFF" ? "1px solid rgba(0,0,0,0.1)" : "none";
        swatch.style.borderRadius = "50%";
        swatch.style.cursor = "pointer";
        swatch.style.outline = color === this.currentColor ? "3px solid rgba(255, 255, 255, 0.7)" : "none";
        swatch.onclick = () => this.setColor(color);
        palette.appendChild(swatch);
      });
    }
    const slider = this.toolbar.querySelector("#thickness-slider");
    if (slider) {
      slider.oninput = (e) => {
        const target = e.target;
        this.setThickness(Number(target.value));
      };
    }
    const closeButton = this.toolbar.querySelector("#close-drawing");
    if (closeButton) {
      closeButton.addEventListener("click", () => this.toggleDrawing());
    }
    const clearButton = this.toolbar.querySelector("#clear-drawing");
    if (clearButton) {
      clearButton.addEventListener("click", () => this.clearCanvas());
    }
    const saveButton = this.toolbar.querySelector("#save-drawing");
    if (saveButton) {
      saveButton.addEventListener("click", () => this.saveDrawing());
    }
    contentLogger.info("DrawingManager", "Toolbar created");
  }
  removeToolbar() {
    if (!this.toolbar) return;
    this.toolbar.remove();
    this.toolbar = null;
    contentLogger.info("DrawingManager", "Toolbar removed");
  }
  startDrawing(event) {
    if (!this.canvas) return;
    this.isDrawing = true;
    [this.lastX, this.lastY] = [event.offsetX, event.offsetY];
  }
  draw(event) {
    if (!this.isDrawing || !this.ctx || !this.canvas) return;
    this.ctx.strokeStyle = this.currentColor;
    this.ctx.lineWidth = this.currentThickness;
    this.ctx.beginPath();
    this.ctx.moveTo(this.lastX, this.lastY);
    this.ctx.lineTo(event.offsetX, event.offsetY);
    this.ctx.stroke();
    [this.lastX, this.lastY] = [event.offsetX, event.offsetY];
  }
  stopDrawing() {
    this.isDrawing = false;
  }
  setColor(color) {
    this.currentColor = color;
    contentLogger.debug("DrawingManager", "Color changed", { color });
  }
  setThickness(thickness) {
    this.currentThickness = thickness;
    contentLogger.debug("DrawingManager", "Thickness changed", { thickness });
  }
  clearCanvas() {
    if (!this.ctx || !this.canvas) return;
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    contentLogger.info("DrawingManager", "Canvas cleared");
  }
  async saveDrawing() {
    if (!this.canvas) {
      contentLogger.warn("DrawingManager", "No canvas to save");
      return;
    }
    try {
      let dataUrl = this.canvas.toDataURL("image/jpeg", 0.7);
      const sizeInKB = dataUrl.length * 3 / 4 / 1024;
      if (sizeInKB > 500) {
        contentLogger.warn("DrawingManager", "Drawing too large, compressing further", { sizeKB: sizeInKB });
        dataUrl = this.canvas.toDataURL("image/jpeg", 0.5);
        const newSizeInKB = dataUrl.length * 3 / 4 / 1024;
        if (newSizeInKB > 500) {
          const resizedDataUrl = await this.resizeAndCompress(this.canvas);
          if (resizedDataUrl) {
            dataUrl = resizedDataUrl;
          }
        }
      }
      const finalSizeInKB = dataUrl.length * 3 / 4 / 1024;
      contentLogger.info("DrawingManager", "Drawing compressed", { finalSizeInKB });
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const url = (tab == null ? void 0 : tab.url) || window.location.href;
      chrome.runtime.sendMessage(
        {
          type: "SAVE_DRAWING",
          drawing: {
            url,
            canvasData: dataUrl,
            timestamp: Date.now()
          }
        },
        (response) => {
          if (response == null ? void 0 : response.success) {
            contentLogger.info("DrawingManager", "Drawing saved successfully");
          } else {
            contentLogger.warn("DrawingManager", "Failed to save drawing", response == null ? void 0 : response.error);
          }
        }
      );
    } catch (error) {
      contentLogger.error("DrawingManager", "Failed to save drawing", error);
    }
  }
  async resizeAndCompress(canvas) {
    try {
      const tempCanvas = document.createElement("canvas");
      tempCanvas.width = canvas.width / 2;
      tempCanvas.height = canvas.height / 2;
      const tempCtx = tempCanvas.getContext("2d");
      if (!tempCtx) return null;
      tempCtx.drawImage(canvas, 0, 0, tempCanvas.width, tempCanvas.height);
      return tempCanvas.toDataURL("image/jpeg", 0.6);
    } catch (error) {
      contentLogger.error("DrawingManager", "Failed to resize canvas", error);
      return null;
    }
  }
  async loadDrawing() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const url = (tab == null ? void 0 : tab.url) || window.location.href;
      chrome.runtime.sendMessage(
        {
          type: "GET_DRAWING",
          url
        },
        (response) => {
          if ((response == null ? void 0 : response.drawing) && this.ctx && this.canvas) {
            const img = new Image();
            img.onload = () => {
              var _a;
              (_a = this.ctx) == null ? void 0 : _a.drawImage(img, 0, 0);
              contentLogger.info("DrawingManager", "Drawing loaded successfully");
            };
            img.onerror = () => {
              contentLogger.error("DrawingManager", "Failed to load drawing image");
            };
            img.src = response.drawing.canvasData;
          } else {
            contentLogger.debug("DrawingManager", "No drawing available for this URL");
          }
        }
      );
    } catch (error) {
      contentLogger.error("DrawingManager", "Failed to load drawing", error);
    }
  }
}
class PubkyURLHandler {
  constructor() {
    __publicField(this, "handleClick", (event) => {
      const target = event.target;
      if (target.classList.contains("pubky-link-button") || target.closest(".pubky-link-button")) {
        const button = target.classList.contains("pubky-link-button") ? target : target.closest(".pubky-link-button");
        const url2 = button == null ? void 0 : button.getAttribute("data-pubky-url");
        if (url2) {
          contentLogger.info("ContentScript", "Pubky URL clicked", { url: url2 });
          event.preventDefault();
          event.stopPropagation();
          chrome.runtime.sendMessage({
            type: "OPEN_PUBKY_PROFILE",
            url: url2
          });
          return;
        }
      }
      let link = null;
      if (target.tagName === "A") {
        link = target;
      } else if (target.closest("a")) {
        link = target.closest("a");
      }
      if (!link || !link.href) {
        return;
      }
      const url = link.href;
      if (url.startsWith("pubky://") || url.startsWith("pubky:")) {
        contentLogger.info("ContentScript", "Pubky URL clicked", { url });
        const normalizedUrl = url.replace(/^pubky:(?!\/\/)/, "pubky://");
        event.preventDefault();
        event.stopPropagation();
        chrome.runtime.sendMessage({
          type: "OPEN_PUBKY_PROFILE",
          url: normalizedUrl
        });
      }
    });
    this.init();
  }
  init() {
    contentLogger.info("ContentScript", "Initializing Pubky URL handler");
    this.injectStyles();
    this.linkifyPubkyURLs();
    this.observeDOMForPubkyURLs();
    document.addEventListener("click", this.handleClick, true);
    contentLogger.info("ContentScript", "Pubky URL handler initialized");
  }
  injectStyles() {
    const style = document.createElement("style");
    style.textContent = `
      .pubky-link-button {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 12px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white !important;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 600;
        text-decoration: none !important;
        cursor: pointer;
        transition: all 0.2s ease;
        box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        border: none;
        vertical-align: middle;
      }
      
      .pubky-link-button:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.5);
      }
      
      .pubky-link-button:active {
        transform: translateY(0);
      }
      
      .pubky-link-icon {
        font-size: 16px;
      }
    `;
    document.head.appendChild(style);
  }
  linkifyPubkyURLs() {
    const pubkyRegex = /\b(pubky:(?:\/\/)?[a-z0-9]+(?:\/[^\s]*)?)/gi;
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode: (node2) => {
          const parent = node2.parentElement;
          if (!parent) return NodeFilter.FILTER_REJECT;
          const tagName = parent.tagName;
          if (tagName === "SCRIPT" || tagName === "STYLE" || tagName === "NOSCRIPT") {
            return NodeFilter.FILTER_REJECT;
          }
          if (parent.classList.contains("pubky-link-button") || parent.closest(".pubky-link-button")) {
            return NodeFilter.FILTER_REJECT;
          }
          if (parent.tagName === "A" || parent.closest("a")) {
            return NodeFilter.FILTER_REJECT;
          }
          if (tagName === "BUTTON" || tagName === "INPUT" || tagName === "TEXTAREA" || tagName === "SELECT") {
            return NodeFilter.FILTER_REJECT;
          }
          if (parent.hasAttribute("data-pubky-linkified") || parent.closest("[data-pubky-linkified]")) {
            return NodeFilter.FILTER_REJECT;
          }
          if (pubkyRegex.test(node2.textContent || "")) {
            return NodeFilter.FILTER_ACCEPT;
          }
          return NodeFilter.FILTER_REJECT;
        }
      }
    );
    const textNodes = [];
    let node;
    while (node = walker.nextNode()) {
      textNodes.push(node);
    }
    textNodes.forEach((textNode) => {
      const text = textNode.textContent || "";
      const parent = textNode.parentNode;
      if (!parent) return;
      const matches = text.matchAll(pubkyRegex);
      const fragments = [];
      let lastIndex = 0;
      let hasMatches = false;
      for (const match of matches) {
        const url = match[0];
        const matchIndex = match.index || 0;
        hasMatches = true;
        if (matchIndex > lastIndex) {
          fragments.push(text.substring(lastIndex, matchIndex));
        }
        const button = document.createElement("span");
        button.className = "pubky-link-button";
        button.setAttribute("data-pubky-linkified", "true");
        const normalizedUrl = url.replace(/^pubky:(?!\/\/)/, "pubky://");
        button.setAttribute("data-pubky-url", normalizedUrl);
        button.innerHTML = `
        <span class="pubky-link-icon">🔗</span>
        <span>${url.length > 30 ? url.substring(0, 30) + "..." : url}</span>
      `;
        fragments.push(button);
        lastIndex = matchIndex + url.length;
      }
      if (!hasMatches) return;
      if (lastIndex < text.length) {
        fragments.push(text.substring(lastIndex));
      }
      const wrapper = document.createElement("span");
      wrapper.setAttribute("data-pubky-linkified", "true");
      wrapper.style.display = "contents";
      fragments.forEach((fragment) => {
        if (typeof fragment === "string") {
          wrapper.appendChild(document.createTextNode(fragment));
        } else {
          wrapper.appendChild(fragment);
        }
      });
      parent.replaceChild(wrapper, textNode);
    });
  }
  observeDOMForPubkyURLs() {
    let isProcessing = false;
    const observer = new MutationObserver((mutations) => {
      const isOurMutation = mutations.some((mutation) => {
        return Array.from(mutation.addedNodes).some((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            const element = node;
            return element.classList.contains("pubky-link-button") || element.hasAttribute("data-pubky-linkified") || element.querySelector(".pubky-link-button") !== null;
          }
          return false;
        });
      });
      if (isOurMutation) {
        return;
      }
      if (!isProcessing) {
        clearTimeout(window.pubkyLinkifyTimeout);
        window.pubkyLinkifyTimeout = setTimeout(() => {
          isProcessing = true;
          try {
            this.linkifyPubkyURLs();
          } finally {
            isProcessing = false;
          }
        }, 500);
      }
    });
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
}
const initializeContentScript = () => {
  contentLogger.info("ContentScript", "Bootstrapping managers");
  new AnnotationManager();
  new DrawingManager();
  new PubkyURLHandler();
};
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initializeContentScript);
} else {
  initializeContentScript();
}
//# sourceMappingURL=content.js.map
